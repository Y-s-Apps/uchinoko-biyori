# 第10章　景色・カメラ・ミニチュア（1）

### `dist/agility-field.js`

````javascript
import * as T from './assets/three.module.js';
import {addTunnel} from './tunnel.js';
import {A_FRAME,addAFrame} from './a-frame.js';
import {SEESAW} from './seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from './slalom.js';
// The arena has one perimeter, no road surface, lane lines, pickups or trackside rails.
export function makeAgilityField(layout){
 const root=new T.Group();root.name='agility-arena';const b=layout.bounds,point=layout.point;
 const fields={
  'first-field':{lawn:'#a5c27a',leaves:'#85ab59',roof:'#d67d55',hill:'#b1cfaa',tree:'round'},
  zigzag:{lawn:'#9cc39a',leaves:'#528d78',roof:'#478c92',hill:'#98c5bb',tree:'pine'},
  balance:{lawn:'#bec682',leaves:'#96a451',roof:'#c79748',hill:'#becc9d',tree:'round'},
  'hill-field':{lawn:'#99be80',leaves:'#679b71',roof:'#537d9e',hill:'#9dbcb3',tree:'pine'}
 };
 const field=fields[layout.courseId]??fields['first-field'];
 const mats=new Map(),material=c=>{if(!mats.has(c))mats.set(c,new T.MeshStandardMaterial({color:c,roughness:1}));return mats.get(c)};
 function mesh(geo,c,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,material(c));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 const box=(w,h,d,c,x,y,z,parent=root)=>mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent);
 const cylinder=(r,h,c,x,y,z,parent=root)=>mesh(new T.CylinderGeometry(r,r,h,9),c,x,y,z,parent);
 let seed=741;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 function instances(name,geometry,color,poses){const m=new T.InstancedMesh(geometry,material(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p.x,p.y,p.z);dummy.scale.set(p.sx??1,p.sy??1,p.sz??1);dummy.rotation.set(0,p.angle??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 const grass=new T.PlaneGeometry(400,400,90,90);grass.rotateX(-Math.PI/2);const colors=[],base=new T.Color();
 for(let i=0;i<grass.attributes.position.count;i++){const x=grass.attributes.position.getX(i),z=grass.attributes.position.getZ(i),v=.011*Math.sin(z*.29)+.008*Math.cos(x*.12);base.set(field.lawn).offsetHSL(0,0,v);colors.push(base.r,base.g,base.b)}
 grass.setAttribute('color',new T.Float32BufferAttribute(colors,3));const lawn=new T.Mesh(grass,new T.MeshStandardMaterial({vertexColors:true,roughness:1}));lawn.name='open-lawn';lawn.position.y=-.035;lawn.receiveShadow=true;root.add(lawn);
 const blade=new T.BufferGeometry();blade.setAttribute('position',new T.Float32BufferAttribute([-.07,0,0,.07,0,0,.025,.20,0,0,0,-.07,0,0,.07,-.02,.17,.02],3));blade.computeVertexNormals();
 const tufts=[];for(let i=0;i<2300;i++){const scale=.4+random()*.7;tufts.push({x:b.minX+random()*(b.maxX-b.minX),y:-.015,z:b.minZ+random()*(b.maxZ-b.minZ),sx:scale,sy:scale,sz:scale,angle:random()*Math.PI})}
 const blades=instances('grass-tufts',blade,'#91ad72',tufts);blades.material.side=T.DoubleSide;
 const posts=[],rails=[];
 const corners=[[b.minX,b.minZ],[b.maxX,b.minZ],[b.maxX,b.maxZ],[b.minX,b.maxZ]];
 for(let k=0;k<4;k++){const a=corners[k],c=corners[(k+1)%4],length=Math.hypot(c[0]-a[0],c[1]-a[1]),n=Math.ceil(length/4),angle=-Math.atan2(c[0]-a[0],a[1]-c[1]);for(let i=0;i<n;i++){
  const t=i/n,x=a[0]+(c[0]-a[0])*t,z=a[1]+(c[1]-a[1])*t;posts.push({x,y:.85,z});
  for(const y of [.65,1.25])rails.push({x:x+(c[0]-a[0])/n/2,y,z:z+(c[1]-a[1])/n/2,sz:length/n,angle});
 }}
 instances('perimeter-posts',new T.BoxGeometry(.2,1.7,.2),'#d4c4a2',posts);instances('perimeter-rails',new T.BoxGeometry(.13,.16,1),'#e5d7b8',rails);
 const trunks=[],crowns=[];
 for(let i=0;i<30;i++){const side=i%4,t=(Math.floor(i/4)+.5)/8;let x,z;if(side<2){x=side?b.maxX+7:b.minX-7;z=b.minZ+t*(b.maxZ-b.minZ)}else{x=b.minX+t*(b.maxX-b.minX);z=side===2?b.minZ-7:b.maxZ+7}trunks.push({x,y:2.2,z});crowns.push({x,y:5.2,z,sx:2.1,sy:2.5,sz:2.1});crowns.push({x:x+.8,y:6.8,z:z-.3,sx:1.7,sy:1.8,sz:1.7})}
 instances('arena-trees',new T.CylinderGeometry(.22,.3,4.4,8),'#8c7c57',trunks);const crown=field.tree==='pine'?new T.ConeGeometry(1,2.35,7):new T.IcosahedronGeometry(1,1);
 const canopy=instances('arena-canopies',crown,field.leaves,crowns);canopy.material.flatShading=true;
 // Nearby hills and a small pavilion anchor the field without narrowing it to a corridor.
 for(let i=0;i<7;i++){const a=i*Math.PI*2/7,h=mesh(new T.IcosahedronGeometry(1,1),field.hill,Math.cos(a)*135,0,Math.sin(a)*135);h.scale.set(44,(layout.courseId==='hill-field'?20:10)+i%3*3,36);h.material.flatShading=true}
 const pavilion=new T.Group();pavilion.position.set(b.maxX+9,0,10);root.add(pavilion);for(const x of [-2.7,2.7])for(const z of [-2.7,2.7])box(.22,3.4,.22,'#a2926e',x,1.7,z,pavilion);const roof=mesh(new T.ConeGeometry(4.5,1.5,4),field.roof,0,4.1,0,pavilion);roof.rotation.y=Math.PI/4;
 for(const side of [-1,1]){box(6.3,.24,.12,'#fff0cf',0,3.27,side*3.07,pavilion);box(.12,.24,6.3,'#fff0cf',side*3.07,3.27,0,pavilion)}
 const groups=new Map(),badges=new Map(),planks=new Map(),poles=new Map();
 for(const o of layout.obstacles){const p=point(o.s,o.lane*2),g=new T.Group();g.name='race-obstacle';g.userData.obstacleId=o.id;g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);groups.set(o.id,g);
  if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.12,1.1,.14,'#5c8eab',x,.55,0,g);box(.45,.08,.65,'#5c8eab',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.2,.11,.10,j%2?'#c87961':'#fff1d5',-.7+j*.2,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#e0b34f',0,1.7,0,g);for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#5c8eab',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#5c8eab',x,.04,0,g)}
  }else if(o.type==='a-frame'){
   addAFrame(g,box);
  }else if(o.type==='slalom'){
   const bands=[];poles.set(o.id,bands);
   for(let i=0;i<SLALOM.count;i++){
    const pole=new T.Group();pole.name='slalom-pole';pole.userData={obstacleId:o.id,poleIndex:i};pole.position.z=o.s-slalomPoleS(o,i);g.add(pole);
    cylinder(.075,1.9,'#f5eed8',0,.95,0,pole);const band=cylinder(.079,.55,'#548cba',0,1.35,0,pole);band.material=band.material.clone();bands.push(band);
    cylinder(.08,.30,'#548cba',0,.35,0,pole);box(.38,.045,.38,'#c9c4a7',0,.025,0,pole);
   }
  }else if(o.type==='seesaw'){
   const plank=new T.Group();plank.name='rigid-plank';plank.userData.obstacleId=o.id;plank.position.y=SEESAW.pivotHeight;plank.rotation.x=SEESAW.angle;g.add(plank);planks.set(o.id,plank);
   box(SEESAW.width,SEESAW.thickness,5.2,'#548cba',0,0,0,plank);for(const z of [-3.3,3.3])box(SEESAW.width,SEESAW.thickness,1.4,'#edcb62',0,0,z,plank);
   // Solid A-frame side supports with one axle across the board's width.
   for(const x of [-.72,.72]){for(const sign of [-1,1]){const leg=box(.12,1.05,.12,'#748889',x,.47,sign*.23,g);leg.rotation.x=sign*-.46}box(.18,.08,1.15,'#748889',x,.04,0,g)}
   const axle=cylinder(.052,1.7,'#a6b2ad',0,SEESAW.pivotHeight,0,g);axle.name='seesaw-axle';axle.rotation.z=Math.PI/2;
  }else{
   addTunnel(g,mesh);
   box(.12,.10,6,'#548cba',-1.58,.05,0,g);box(.12,.10,6,'#548cba',1.58,.05,0,g);
  }
  // Numbered freestanding boards mark the order, not a lane or collectible.
  cylinder(.045,.9,'#ad9f7d',2.7,.45,1.0,g);const badge=box(.68,.8,.10,'#f5eed8',2.7,1.12,1.0,g);badge.material=badge.material.clone();badges.set(o.id,badge);
  const digits=['bc','abged','abgcd','fgbc','afgcd','afgecd'],segments={a:[0,.27,.28,.045],g:[0,0,.28,.045],d:[0,-.27,.28,.045],f:[-.15,.14,.045,.22],b:[.15,.14,.045,.22],e:[-.15,-.14,.045,.22],c:[.15,-.14,.045,.22]};
  for(const part of digits[o.id]){const [x,y,w,h]=segments[part];box(w,h,.015,'#48684f',2.7+x,1.12+y,1.06,g)}
 }
 const target=new T.Group();target.name='next-obstacle-marker';root.add(target);
 const ring=mesh(new T.RingGeometry(1.8,1.95,48),'#e9cf76',0,.015,0,target);ring.rotation.x=-Math.PI/2;ring.material=ring.material.clone();ring.material.transparent=true;ring.material.opacity=.65;
 const finish=new T.Group(),end=point(layout.length);finish.name='finish-gate';finish.position.set(end.x,0,end.z);finish.rotation.y=-end.heading;root.add(finish);
 const start=point(0);
 for(const [parent,color] of [[finish,'#e8c86b']])for(const x of [-2.8,2.8]){cylinder(.055,1.8,'#f5eed8',x,.9,0,parent);box(.65,.43,.035,color,x+.3,1.5,0,parent);box(.32,.06,.32,'#c9c4a7',x,.03,0,parent)}
 for(const x of [-2.8,2.8]){cylinder(.055,1.3,'#f5eed8',start.x+x,.65,start.z);box(.55,.35,.035,'#83aabd',start.x+x+.25,1.05,start.z)}
 let lastKey='';
 function update(sim){
  const next=sim.nextObstacle,key=`${next?.id}:${sim.results.size}:${[...sim.slaloms.values()].map(s=>s.index).join(',')}`;if(key===lastKey)return;lastKey=key;target.visible=!!next;target.scale.setScalar(1);
  if(next){const g=groups.get(next.id);target.position.copy(g.position);target.rotation.y=g.rotation.y;if(next.type==='a-frame'){const entry=point(next.s-A_FRAME.run,next.lane*2);target.position.set(entry.x,.012,entry.z);target.scale.setScalar(.56)}if(next.type==='slalom'){const index=sim.slaloms.get(next.id).index;target.visible=index<SLALOM.count;if(target.visible){const p=point(slalomPoleS(next,index),next.lane*2+slalomSide(next,index)*SLALOM.offset);target.position.set(p.x,.012,p.z);target.scale.setScalar(.30)}}}
  for(const o of layout.obstacles)badges.get(o.id).material.color.set(sim.results.has(o.id)?(sim.results.get(o.id)?'#b6d59c':'#d9aa8d'):o.id===next?.id?'#f4d77b':'#f5eed8');
  for(const [id,bands] of poles){const state=sim.slaloms.get(id);bands.forEach((band,i)=>band.material.color.set(i<state.index?(state.passed[i]?'#8eb87c':'#ca8f75'):next?.id===id&&i===state.index?'#e5bd5c':'#548cba'))}
 }
 function animate(sim){for(const [id,plank] of planks)plank.rotation.x=sim.seesaws.get(id).angle}
 function resetTreats(){lastKey='';target.visible=false;target.scale.setScalar(1);for(const badge of badges.values())badge.material.color.set('#f5eed8');for(const plank of planks.values())plank.rotation.x=SEESAW.angle;for(const bands of poles.values())for(const band of bands)band.material.color.set('#548cba')}
 resetTreats();return {root,resetTreats,collectTreat(){},update,animate};
}
````

### `dist/beach-scene.js`

````javascript
import * as T from './assets/three.module.js';

function strip(point, inner, outer, y, from, to, step = 2) {
  const positions = [], indices = [];
  const count = Math.ceil((to - from) / step);
  for (let i = 0; i <= count; i++) {
    const s = from + (to - from) * i / count;
    const edge = point(s, -6.8 - .6 * Math.sin(s / 8) - .35 * Math.sin(s / 3));
    for (const distance of [outer, inner]) {
      positions.push(edge.x - distance, y, edge.z);
    }
    if (i < count) {
      const k = 2 * i;
      indices.push(k, k + 1, k + 2, k + 1, k + 3, k + 2);
    }
  }
  const geo = new T.BufferGeometry();
  geo.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function addBeachScenery(layout, {mesh, box, pose, instances, groupAt, ribbon}) {
  const {point, length} = layout;
  box(1100, .12, 1400, '#e7cd98', 0, -.10, -200);
  const band = (inner, outer, y, color, name) => {
    mesh(strip(point, inner, outer, y, -210, length + 220), color).name = name;
  };
  band(-1.7, 0, -.007, '#c8b994', 'wet-sand');
  band(0, 320, .008, '#469eae', 'ocean');
  band(0, 2.8, .013, '#9edbd0', 'shallows');
  band(2.8, 10, .012, '#7fbcb7', 'coastal-water');
  band(-.1, .19, .025, '#f5f1d9', 'surf-line');
  mesh(ribbon(0, 7.5, .015, -15, length + 30, point), '#eacb95').name = 'continuous-road';
  for (const patch of layout.sand) {
    const group = groupAt(patch.s, patch.lane * 2);
    group.name = 'soft-sand';
    const surface = mesh(new T.CylinderGeometry(1, 1, .025, 36), '#c9a574', 0, .018, 0, group);
    surface.scale.set(patch.halfWidth, 1, patch.halfLength);
    for (let i = -2; i <= 2; i++) {
      const ripple = mesh(new T.SphereGeometry(1, 9, 5), '#bfa077', .09 * Math.sin(i), .034, i * 1.55, group);
      ripple.scale.set(.38, .022, .085);
      ripple.rotation.y = .2 * Math.sin(i + 1);
    }
  }
  const foam = [], poles = [], flags = [], dunes = [], umbrellaPoles = [], parasols = [[], []];
  for (let s = -30; s < length + 75; s += 5.5) {
    const shore = point(s, -6.8 - .6 * Math.sin(s / 8) - .35 * Math.sin(s / 3));
    for (let j = 0; j < 3; j++) {
      foam.push([shore.x - 1.6 - j * 7.8 - 1.1 * Math.cos(s + j), .027,
        shore.z + Math.sin(s * .32 + j), .09 + .04 * j, .012, .65 + .5 * (1 + Math.sin(s)), -.35 * Math.sin(s * .1)]);
    }
  }
  for (let i = 0; i * 13 <= length + 8; i++) {
    const s = i * 13;
    for (const side of [-1, 1]) {
      poles.push(pose(s, side * 4.2, .48));
      flags.push(pose(s, side * 4.2 + .15, .83));
    }
  }
  for (let i = 0; i * 18 < length + 50; i++) {
    const s = i * 18 - 15;
    dunes.push(pose(s, 12 + 2 * Math.sin(i), -.15, 3.6 + i % 3, .9, 5));
    if (i % 3 === 1) {
      umbrellaPoles.push(pose(s, 9, 1.3));
      parasols[i % 2].push(pose(s, 9, 2.6));
    }
  }
  instances(new T.SphereGeometry(1, 9, 5), '#cce4db', foam, 'whitecaps');
  instances(new T.CylinderGeometry(.045, .055, .96, 8), '#a58562', poles, 'beach-stakes');
  instances(new T.BoxGeometry(.30, .18, .035), '#e57e5b', flags, 'course-pennants');
  instances(new T.IcosahedronGeometry(1, 1), '#d6bd8e', dunes, 'dunes');
  instances(new T.CylinderGeometry(.065,.075,2.6,8), '#9f8668', umbrellaPoles, 'parasol-poles');
  for (let i = 0; i < 2; i++) instances(new T.ConeGeometry(1.8, .65, 10), ['#d87559','#478b91'][i], parasols[i], 'parasols');
  // The headland stays out at sea as the ribbon follows the shoreline.
  const headland=groupAt(length*.63,-30);
  const island=mesh(new T.IcosahedronGeometry(1,0),'#849b88',0,.2,0,headland);
  island.scale.set(7,2.4,5);
  for(const [base,height,radius,color] of [[1.6,3.6,1.25,'#f4e5c3'],[5.2,1.0,1.12,'#c3654a'],[6.2,1.6,1.05,'#f4e5c3'],[7.8,.85,.93,'#497b86']]){
    mesh(new T.CylinderGeometry(radius*.94,radius,height,10),color,0,base+height/2,0,headland);
  }
  mesh(new T.ConeGeometry(1.28,.85,10),'#b75e45',0,9.06,0,headland);
  for (const s of [45, 164, 296, 435]) {
    const group = groupAt(s, -8);
    group.position.x -= 20 + 7 * Math.sin(s);
    group.rotation.y += .5;
    const hull = mesh(new T.SphereGeometry(1, 12, 8), '#9b6650', 0, .24, 0, group);
    hull.scale.set(.66, .38, 2.2);
    box(.07, 3.7, .07, '#927763', 0, 2, 0, group);
    const triangle = new T.Shape();
    triangle.moveTo(0, 0); triangle.lineTo(1.65, 0); triangle.lineTo(0, 3.1); triangle.closePath();
    const sail = mesh(new T.ShapeGeometry(triangle), '#fbefd6', 0, .70, .08, group);
    sail.rotation.y = Math.PI / 2;
    sail.material.side = T.DoubleSide;
  }
}

export function addDriftwood(group, mesh) {
  function timber(top, bottom, length, x, y, angle, color) {
    const piece = mesh(new T.CylinderGeometry(top, bottom, length, 12), color, x, y, 0, group);
    piece.rotation.z = angle;
    piece.castShadow = true;
    return piece;
  }
  timber(.32, .30, 1.92, 0, .34, Math.PI / 2, '#886246');
  for (const x of [-.963, .963]) timber(.26, .26, .012, x, .34, Math.PI / 2, '#d1ad77');
  timber(.087, .13, .36, .51, .56, -.9, '#8c694d');
}
````

### `dist/chase-camera.js`

````javascript
// Follow the dog's current heading, not a different point on the curved road.
// Position and target share the same lateral anchor, keeping the dog centred.
export function chaseCameraPose(point,{distance=6,height=2.8,lookAhead=10,lookHeight=1}={}){
 const forwardX=Math.sin(point.heading),forwardZ=-Math.cos(point.heading);
 return {position:{x:point.x-forwardX*distance,y:height,z:point.z-forwardZ*distance},target:{x:point.x+forwardX*lookAhead,y:lookHeight,z:point.z+forwardZ*lookAhead}};
}
````

### `dist/course-scene.js`

````javascript
import * as T from './assets/three.module.js';
import {addTunnel} from './tunnel.js';
import {addAFrame} from './a-frame.js';
import {canPlay} from './courses.js';
import {makeCompanion} from './companions.js';
import { buildAgilityCourse } from './agility-sim.js';
import {buildForestRace} from './forest-layout.js';
import {buildBeachRace} from './beach-layout.js';
import {SLALOM,slalomPoleS} from './slalom.js';
export function makeCourseScene(course,breed,coat,scarfColor){
 const root=new T.Group();root.name=`course-${course.id}`;
 const colors={park:['#a9bd87','#d5c29c'],beach:['#e0cf9b','#d2b578'],forest:['#789373','#b6a17c'],field:['#a8bf91','#c8d4b2']}[course.theme];
 const mats=new Map();const material=c=>{if(!mats.has(c))mats.set(c,new T.MeshStandardMaterial({color:c,roughness:1}));return mats.get(c)};
 function add(geo,color,pos=[0,0,0],parent=root){const m=new T.Mesh(geo,material(color));m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
 const box=(w,h,d,color,pos,parent)=>add(new T.BoxGeometry(w,h,d),color,pos,parent);
 const ball=(r,color,pos,parent)=>add(new T.SphereGeometry(r,12,8),color,pos,parent);
 const cylinder=(r,h,color,pos,parent)=>add(new T.CylinderGeometry(r,r,h,12),color,pos,parent);
 const beach=course.id==='beach'?buildBeachRace():null;
 const forest=course.id==='forest'?buildForestRace():null;
 const raceLayout=beach??forest;
 const field=canPlay('agility',course.id)?buildAgilityCourse(course.id):null;
 box(field?8:6,.25,10,colors[0],[0,-.125,0]);
 const racePoint=(t,lateral=0)=>{
  const p=raceLayout.point(t*raceLayout.length);
  const scale=forest ? .018 : .019;
  return new T.Vector3((forest ? .45 : 0)+p.x*scale+Math.cos(p.heading)*lateral,.015,3.9+p.z*scale+Math.sin(p.heading)*lateral);
 };
 const curve=raceLayout?{getPoint:racePoint,getTangent(t){const p=raceLayout.point(t*raceLayout.length);return new T.Vector3(Math.sin(p.heading),0,-Math.cos(p.heading))}}:field?{getPoint(t){const p=field.point(t*field.length);return new T.Vector3(p.x*.09,.015,p.z*.09)},getTangent(t){const p=field.point(t*field.length);return new T.Vector3(Math.sin(p.heading),0,-Math.cos(p.heading))}}:new T.CatmullRomCurve3(course.route.map(([x,z])=>new T.Vector3(x,.015,z)));
 const positions=[],indices=[];const n=100,half=course.mode==='race'?.65:.48;
 for(let i=0;i<=n;i++){const t=i/n,p=curve.getPoint(t),d=curve.getTangent(t),normal=new T.Vector3(-d.z,0,d.x);for(const side of [-1,1]){const v=p.clone().addScaledVector(normal,side*half);positions.push(v.x,v.y,v.z)}if(i<n){const k=i*2;indices.push(k,k+2,k+1,k+1,k+2,k+3)}}
 const ribbon=new T.BufferGeometry();ribbon.setAttribute('position',new T.Float32BufferAttribute(positions,3));ribbon.setIndex(indices);ribbon.computeVertexNormals();if(course.mode==='race'){const road=add(ribbon,colors[1]);road.material.side=T.DoubleSide}else ribbon.dispose();
 const equipment={blue:'#608d9e',yellow:'#d6b35a',red:'#bc7860',white:'#f7eed4'};
 const raceObstacles=raceLayout?[...raceLayout.obstacles,...(raceLayout.sand??[]).map(patch=>({...patch,type:'sand'}))].map(o=>({...o,t:o.s/raceLayout.length})):null;
 for(const obstacle of (raceObstacles??(field?field.obstacles.map(o=>({...o,t:o.s/field.length})):course.obstacles))){const g=new T.Group(),p=curve.getPoint(obstacle.t),d=curve.getTangent(obstacle.t);g.position.copy(p);g.rotation.y=Math.atan2(d.x,d.z);if(field){const fp=field.point(obstacle.s,obstacle.lane*2);g.position.set(fp.x*.09,.015,fp.z*.09);g.rotation.y=-fp.heading}if(raceLayout){g.position.copy(racePoint(obstacle.t,.43*obstacle.lane));g.rotation.y=-raceLayout.point(obstacle.s).heading;g.scale.setScalar(.47)}root.add(g);g.name=obstacle.type;
  if(obstacle.type==='hurdle'){
   for(const x of [-.53,.53]){box(.08,.66,.10,equipment.blue,[x,.33,0],g);box(.27,.05,.30,equipment.blue,[x,.025,0],g)}
   for(let j=0;j<5;j++){const bar=cylinder(.035,.2,j%2?equipment.red:equipment.white,[-.4+j*.2,.45,0],g);bar.rotation.z=Math.PI/2}
  }else if(obstacle.type==='hoop'){
   add(new T.TorusGeometry(.30,.045,8,28),equipment.yellow,[0,.57,0],g);
   for(const x of [-.43,.43]){box(.06,.76,.06,equipment.blue,[x,.38,0],g);box(.13,.034,.04,equipment.blue,[x*.86,.57,0],g);box(.23,.04,.25,equipment.blue,[x,.02,0],g)}
  }else if(obstacle.type==='tunnel'){
   addTunnel(g,(geometry,color,x,y,z,parent)=>add(geometry,color,[x,y,z],parent),.43,1.16);
  }else if(obstacle.type==='a-frame'){
   g.scale.set(.25,.22,.13);
   addAFrame(g,(w,h,d,c,x,y,z,parent)=>box(w,h,d,c,[x,y,z],parent));
  }else if(obstacle.type==='slalom'){
   for(let j=0;j<SLALOM.count;j++){const z=field?(obstacle.s-slalomPoleS(obstacle,j))*.09:-.8+j*.32;cylinder(.03,.31,equipment.white,[0,.155,z],g);cylinder(.03,.31,equipment.blue,[0,.465,z],g)}
  }else if(obstacle.type==='seesaw'){
   // A rigid straight plank: three contiguous painted segments share one transform.
   const plank=new T.Group();plank.name='rigid-plank';plank.position.y=.38;plank.rotation.x=.33;g.add(plank);
   box(.50,.10,1.12,equipment.blue,[0,0,0],plank);for(const z of [-.78,.78])box(.50,.10,.44,equipment.yellow,[0,0,z],plank);
   const support=add(new T.ConeGeometry(.32,.38,3),equipment.blue,[0,.19,0],g);support.rotation.y=Math.PI/2;
   const axle=cylinder(.043,.62,'#788d8c',[0,plank.position.y,0],g);axle.name='seesaw-axle';axle.rotation.z=Math.PI/2;
  }else if(obstacle.type==='log'){
   const log=cylinder(.15,1.05,'#92704c',[0,.16,0],g);log.rotation.z=Math.PI/2;
   for(const x of [-.53,.53]){const cap=cylinder(.128,.015,'#bea174',[x,.16,0],g);cap.rotation.z=Math.PI/2}
  }else if(obstacle.type==='sand'){const patch=add(new T.CylinderGeometry(.55,.55,.012,24), '#bea165',[0,.01,0],g);patch.scale.z=1.6}
 }
 function tree(x,z,pine=false){cylinder(.08,.7,'#8b7752',[x,.35,z]);if(pine){add(new T.ConeGeometry(.45,1.05,7),'#53775d',[x,1.1,z]);add(new T.ConeGeometry(.36,.9,7),'#62896a',[x,1.5,z])}else{ball(.44,'#89a86c',[x,.93,z]);ball(.34,'#96b574',[x+.18,1.13,z-.06]);ball(.30,'#78985c',[x-.22,.92,z+.05])}}
 if(course.theme==='beach'){
  const waterVertices=[],waterFaces=[];
  for(let i=-15;i<=115;i++){
   const p=racePoint(i/100),z=Math.max(-5,Math.min(5,p.z));
   waterVertices.push(-3,.013,z,p.x-.95,.013,z);
   if(i<115){const n=(i+15)*2;waterFaces.push(n,n+1,n+2,n+1,n+3,n+2)}
  }
  const water=new T.BufferGeometry();water.setAttribute('position',new T.Float32BufferAttribute(waterVertices,3));water.setIndex(waterFaces);water.computeVertexNormals();add(water,'#8bb9bd');
  for(let j=0;j<8;j++){const p=racePoint(j/8);box(.055,.012,.32,'#c4dcce',[p.x-1.34,.027,p.z])}
  for(const z of [-3.4,2.3]){cylinder(.07,1.05,'#a58b59',[2.1,.525,z]);for(let j=0;j<5;j++){const a=j*Math.PI*2/5;const leaf=ball(.33,'#88a17a',[2.1+Math.cos(a)*.25,1.10,z+Math.sin(a)*.25]);leaf.scale.set(1,.2,.55);leaf.rotation.y=-a}}
 }else if(course.theme==='field'){
  const fenceX=field?3.5:2.4;for(const x of [-fenceX,fenceX]){for(let j=0;j<6;j++)box(.06,.36,.06,'#f0ead3',[x,.18,-4.2+j*1.65]);box(.055,.05,8.2,'#e7e5cd',[x,.25,-.075])}for(const z of [-4.2,4.05]){box(fenceX*2,.05,.055,'#e7e5cd',[0,.25,z]);for(let x=-fenceX;x<=fenceX;x+=1.3)box(.06,.36,.06,'#f0ead3',[x,.18,z])}tree(field?3.5:2.4,-4.3);tree(field?-3.6:-2.5,3.9);
 }else{for(const [x,z]of [[-2.1,-3.7],[2.2,-3.2],[-2.4,-.9],[2.1,.4],[-2.1,2.5],[2.5,3.5]])tree(x,z,course.theme==='forest')}
 // Space the tiny biscuits apart so both routes and the arch over each log are legible.
 const previewTreats=[];
 if(raceLayout){
  for(let s=10;s<raceLayout.length-7;s+=14){
   if(raceLayout.obstacles.some(log=>Math.abs(log.s-s)<=17))continue;
   const treat=beach?.treats.find(t=>t.s>=s);
   previewTreats.push({t:(treat?.s??s)/raceLayout.length,lane:treat?.lane??0});
  }
  for(const log of raceLayout.obstacles){
   for(const ds of [-7,0,7]){
    previewTreats.push({t:(log.s+ds)/raceLayout.length,lane:log.lane,height:ds===0?.47:.32,air:true});
    if(beach)previewTreats.push({t:(log.s+ds)/raceLayout.length,lane:log.snackLane});
   }
  }
 }else if(course.mode==='race'){
  for(let j=1;j<35;j++){const t=j/36;if(course.obstacles.every(o=>Math.abs(o.t-t)>=(o.type==='tunnel'?.09:.065)))previewTreats.push({t,lane:0})}
 }
 for(const {t,lane,height=.16,air=false} of previewTreats){
  const p=raceLayout?racePoint(t,lane*.43):curve.getPoint(t);
  const b=new T.Group();b.position.set(p.x,height,p.z);b.name='treat';root.add(b);
  if(air)b.scale.setScalar(.64);
  box(.15,.055,.06,'#d1a24f',[0,0,0],b);
  for(const x of [-.075,.075])for(const z of [-.027,.027])ball(.035,'#d1a24f',[x,0,z],b);
  b.userData.pathT=t;
 }
 // Finish gate is separate from the obstacles.
 const finish=new T.Group();finish.position.copy(curve.getPoint(1));finish.position.y=0;
 if(field)finish.rotation.y=-field.point(field.length).heading;
 root.add(finish);
 for(const x of [-.65,.65])box(.055,.95,.055,'#6c8678',[x,.475,0],finish);
 for(let j=0;j<8;j++)box(.16,.16,.025,j%2?'#f6f1dc':'#628272',[-.56+j*.16,.9,0],finish);
 const dog=makeCompanion(breed,coat,scarfColor);dog.scale.setScalar(.38);const start=curve.getPoint(0);dog.position.set(start.x,0,start.z);dog.rotation.y=Math.PI;root.add(dog);
 root.userData.courseId=course.id;return root;
}
````

### `dist/forest-scene.js`

````javascript
import * as T from './assets/three.module.js';

export function addForestScenery(layout, {mesh, box, instances, pose, ribbon}) {
  const end = layout.length + 35;
  box(1000, .16, 1300, '#93a978', 0, -.12, -230);
  mesh(ribbon(0, 8.8, .005, -20, end, layout.point), '#b7ad79').name = 'trail-verge';
  mesh(ribbon(0, 7.5, .016, -20, end, layout.point), '#d1af80').name = 'continuous-road';

  let seed = 41383;
  const random = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const trunks = [], lowBoughs = [], highBoughs = [], birches = [], birchLeaves = [], bark = [];
  const rocks = [], moss = [], ferns = [], leafLitter = [], waymarks = [], blazes = [];
  for (let s = -10; s < end; s += 4.3) {
    for (const side of [-1, 1]) {
      const station = s + random() * 3;
      const gap = Math.sin(s * .065) > .6 ? 3 : 0;
      const offset = side * (7.6 + gap + random() * 5);
      const size = .78 + random() * .58;
      if (random() < .28) {
        birches.push(pose(station, offset, size * 2.1, size, size, size));
        for (let j = 0; j < 3; j++) bark.push(pose(station, offset, size * (.9 + j * .9), size, size, size));
        birchLeaves.push(pose(station, offset, size * 4.4, 1.6 * size, 2.1 * size, 1.6 * size));
      } else {
        trunks.push(pose(station, offset, size * 1.6, size, size, size));
        lowBoughs.push(pose(station, offset, size * 3.35, size, size, size));
        highBoughs.push(pose(station, offset, size * 4.95, size, size, size));
      }
      const verge = side * (4.8 + random() * 1.6);
      if (random() < .35) {
        rocks.push(pose(s, verge, .16, .46, .32, .57));
        moss.push(pose(s, verge, .30, .38, .24, .45));
      } else {
        const stem = pose(s, verge, .22, .38, .47, .38);
        ferns.push(stem);
      }
      leafLitter.push(pose(s + random(), side * (3.2 + random() * .85), .027, .10, .007, .19));
    }
  }
  for (let s = 0; s < end; s += 17) {
    const side = Math.floor(s / 17) % 2 ? -1 : 1;
    waymarks.push(pose(s, side * 4.55, .49));
    blazes.push(pose(s, side * 4.55, .73));
  }
  const ridge=[];
  for(let s=24;s<end;s+=55){
    for(const side of [-1,1])ridge.push(pose(s,side*33,1,13,7+3*Math.sin(s),18));
  }
  instances(new T.IcosahedronGeometry(1,0),'#819e91',ridge,'forest-ridge');
  instances(new T.CylinderGeometry(.18,.29,3.2,8),'#79644c',trunks,'fir-trunks');
  instances(new T.ConeGeometry(1.85,3.7,8),'#355e51',lowBoughs,'fir-boughs');
  instances(new T.ConeGeometry(1.35,3.25,8),'#63865f',highBoughs,'fir-tops');
  instances(new T.CylinderGeometry(.14,.20,4.2,8),'#ded8ba',birches,'birch-trunks');
  instances(new T.CylinderGeometry(.19,.20,.085,8),'#817b67',bark,'birch-bark');
  instances(new T.IcosahedronGeometry(1,1),'#9cb668',birchLeaves,'birch-leaves');
  instances(new T.IcosahedronGeometry(1,0),'#8b8876',rocks,'verge-rocks');
  instances(new T.IcosahedronGeometry(1,0),'#83905e',moss,'rock-moss');
  instances(new T.ConeGeometry(1,1,5),'#668451',ferns,'forest-floor');
  instances(new T.IcosahedronGeometry(1,0),'#a98853',leafLitter,'fallen-leaves');
  instances(new T.BoxGeometry(.17,.98,.17),'#8a785e',waymarks,'waymarks');
  instances(new T.BoxGeometry(.177,.16,.177),'#eabd76',blazes,'trail-blazes');
}

export function addForestLog(group, mesh) {
  const trunk = mesh(new T.CylinderGeometry(.32,.34,1.95,12), '#74583f', 0,.34,0,group);
  trunk.rotation.z = Math.PI / 2;
  trunk.castShadow = true;
  for (const sign of [-1,1]) {
    const x = sign * .978;
    const cut = mesh(new T.CylinderGeometry(.294,.294,.012,16),'#cdab74',x,.34,0,group);
    cut.rotation.z = Math.PI / 2;
    const ring = mesh(new T.TorusGeometry(.18,.015,5,18),'#a48255',x + sign * .011,.34,0,group);
    ring.rotation.y = Math.PI / 2;
  }
}
````

### `dist/park-art.js`

````javascript
import * as T from './assets/three.module.js';

function randomSequence(seed) {
  return () => ((seed = (1664525 * seed + 1013904223) >>> 0) / 4294967296);
}

// The park shares the simulation's centre line. Dressing stays beyond the running surface.
export function dressPark({root, routePoint, end, ribbon, mesh, box, groupAt, instances, pose}) {
  const random=randomSequence(1071);
  box(1300,.15,1300,'#9bc95f',0,-.12,-180);
  mesh(ribbon(0,7.65,.015,-15,end,routePoint),'#edc285').name='continuous-road';
  const flecks=[],grass=[],flowers=[],flowerHearts=[],shrubs=[],deep=[],trunks=[],limbs=[],canopy=[],tops=[],posts=[],rails=[];
  const bankColors=['#bedc77','#a4cc65','#c4df81','#99c461'];
  const verts=[],colors=[];
  // Broad, irregular polygons at the trail edge instead of painted lane lines.
  for(const side of [-1,1]){
    let previous;
    for(let s=-15;s<=end+3;s+=2.8) {
      const width=3.77+random()*.28,outer=5.6+random()*1.2;
      const row=[routePoint(s,width*side),routePoint(s,outer*side)];
      if(previous){
        const color=new T.Color(bankColors[Math.floor(random()*bankColors.length)]);
        for(const v of [previous[0],previous[1],row[0],previous[1],row[1],row[0]]){
          verts.push(v.x,.024,v.z);color.toArray(colors,colors.length);
        }
      }
      previous=row;
    }
  }
  const banks=new T.BufferGeometry();banks.setAttribute('position',new T.Float32BufferAttribute(verts,3));
  banks.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  const verge=new T.Mesh(banks,new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide}));root.add(verge);
  for(let s=-10;s<end;s+=1.3){
    const side=random()<.5?-1:1;
    flecks.push(pose(s,side*(2.44+random()*1.24),.027,.08+random()*.24,.009,.06+random()*.18));
    const lateral=side*(4.1+random()*2.05);
    const g=pose(s,lateral,.13,.10,.26+random()*.22,.15);grass.push(g);
    if(random()>.28)continue;
    for (let j=0;j<3;j++){
      const p=pose(s+random()*.6,lateral+random()*.4,.19+random()*.13,.12,.055,.12);
      flowerHearts.push([p[0],p[1]+.033,p[2],.057,.038,.057]);
      for(let petal=0;petal<5;petal++){const a=petal*2*Math.PI/5;flowers.push([p[0]+Math.cos(a)*.069,p[1],p[2]+Math.sin(a)*.069,.07,.032,.07])}
    }
  }
  instances(new T.DodecahedronGeometry(1,0),'#d8ab76',flecks,'path-grit');
  instances(new T.ConeGeometry(1,1,3),'#75a34c',grass,'grass-tips');
  const bloom=new T.IcosahedronGeometry(1,0);
  instances(bloom,'#fff4d8',flowers,'daisies');instances(bloom,'#efaf31',flowerHearts,'daisy-centres');
  for(const side of [-1,1]){
    // Split rails into short runs with open views between groups of trees.
    for(let s=-11;s<end;s+=3.1){
      if((Math.floor((s+12)/21)+(side+1))%4===2)continue;
      const a=routePoint(s,side*5.72),b=routePoint(s+3.1,side*5.72);
      posts.push(pose(s,side*5.72,.56));
      for(const y of [.46,.89])rails.push([(a.x+b.x)/2,y,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.08,-Math.atan2(b.x-a.x,a.z-b.z)]);
    }
    for(let s=-12+(side+1)*2.9;s<end;s+=9+random()*6) {
      const offset=side*(6.8+random()*3.6),h=2.45+random()*1.35;
      trunks.push(pose(s,offset,h*.48,1,h,1));
      const p=pose(s,offset,h*.89,1,.95,1);limbs.push(p);
      const turn=random()*6,spread=1.65+random()*.91;
      canopy.push([...pose(s,offset,h+.56,spread,1.66+random(),spread*.91).slice(0,6),turn]);
      tops.push([...pose(s+.42,offset-side*.71,h+1.58,spread*.76,1.24+random()*.5,spread*.7).slice(0,6),turn+.71]);
    }
    for(let s=-9;s<end;s+=5+random()*7) {
      const d=6.2+random()*4,scale=.7+random()*.8;
      shrubs.push(pose(s,side*d,scale*.55,scale*1.13,scale,scale*.91));
      deep.push(pose(s+1,side*(d+.65),scale*.44,scale*1.12,scale*.74,scale));
    }
  }
  const faceted = new T.IcosahedronGeometry(1,1);
  function foliage(geom,color,poses,name) {
    const batch=instances(geom,color,poses,name);
    batch.material.flatShading=true;
    for(let i=0;i<poses.length;i++){
      const tone=.80+random()*.20;batch.setColorAt(i,new T.Color().setRGB(tone,Math.min(1,tone+.03),tone*.94));
    }
    return batch;
  }
  foliage(faceted,'#70ae51',canopy,'tree-crowns');foliage(faceted,'#a3ca59',tops,'sunlit-canopies');
  foliage(new T.DodecahedronGeometry(1,0),'#81af4a',shrubs,'shrubs');foliage(faceted,'#589b55',deep,'hedges');
  instances(new T.CylinderGeometry(.22,.34,1,7),'#966745',trunks,'tree-trunks');
  const branch=new T.CylinderGeometry(.10,.18,1.45,6);branch.rotateZ(.53);branch.translate(-.29,0,0);
  instances(branch,'#a5744d',limbs,'tree-branches');
  instances(new T.CylinderGeometry(.099,.111,1.17,5),'#aa7450',posts,'fence-posts');
  instances(new T.BoxGeometry(.085,.13,1),'#bc895d',rails,'fence-rails');
  const treeShadows=trunks.map(p=>[p[0]+.75,.007,p[2]-.37,2.43,1,1.44,p[6]]);
  const shadowPatch=new T.CircleGeometry(1,9);shadowPatch.rotateX(-Math.PI/2);
  instances(shadowPatch,'#8db55f',treeShadows,'tree-shadows');
  const hills=[], clouds=[];
  for(let s=-30;s<end+60;s+=25)for(const side of [-1,1]){
    const d=44+random()*26;
    hills.push(pose(s,side*d,-2,11+random()*13,5+random()*8,15+random()*13));
    if(random()<.5){
      const lateral=side*(13+random()*23),h=12+random()*8;
      for(const [dx,dy,z,w,t] of [[-2,0,-.1,2.1,.82],[0,.67,0,2.35,1.45],[2.1,.12,.3,1.8,.96]]){
        clouds.push(pose(s+z,lateral+dx,h+dy,w,t,1.85));
      }
    }
  }
  // A hill beside one straight can cross another after the course folds back.
  // Its full footprint must clear every stretch, including the chase camera on bends.
  const centreLine=[];
  for(let s=-20;s<=end+5;s+=2)centreLine.push(routePoint(s,0));
  const distantHills=hills.filter(([x,,z,rx,,rz])=>{
    const clearance=Math.max(rx,rz)+16;
    return centreLine.every(p=>(p.x-x)**2+(p.z-z)**2>clearance**2);
  });
  foliage(new T.IcosahedronGeometry(1,0),'#83b69b',distantHills,'far-hills');
  instances(new T.IcosahedronGeometry(1,1),'#fff8df',clouds,'clouds');
  for(const s of [45,162,322]){
    const pavilion=groupAt(s,-11);pavilion.name='park-pavilion';
    mesh(new T.CylinderGeometry(2.3,2.46,.27,8),'#d5b68a',0,.13,0,pavilion);
    for(let j=0;j<8;j++){
      const a=Math.PI*j/4;
      mesh(new T.CylinderGeometry(.083,.10,2.65,6),'#f4e4be',Math.cos(a)*1.9,1.56,Math.sin(a)*1.9,pavilion);
    }
    mesh(new T.ConeGeometry(2.9,1.55,8),'#cf6c50',0,3.65,0,pavilion);
    mesh(new T.CylinderGeometry(2.9,2.81,.15,8),'#8f5542',0,2.88,0,pavilion);
    mesh(new T.SphereGeometry(.16,8,6),'#f3be66',0,4.48,0,pavilion);
  }
}

export function parkLog(group,mesh) {
  const bark=mesh(new T.CylinderGeometry(.365,.345,1.76,11),'#925d38',0,.39,0,group);
  bark.castShadow=true;bark.rotation.z=Math.PI/2;bark.rotation.y=.09;
  for(const side of [-1,1]){
    const x=side*.88,z=-side*.079;
    const end=mesh(new T.CylinderGeometry(.303,.303,.02,11),'#e2ab70',x,.39,z,group);end.rotation.copy(bark.rotation);
    const ring=mesh(new T.TorusGeometry(.195,.014,4,12),'#b57a46',x+side*.017,.39,z,group);ring.rotation.y=Math.PI/2+.09;
  }
  for(const x of [-.51,.32]){
    const seam=mesh(new T.CylinderGeometry(.027,.033,.42,6),'#b7814e',x,.50,.32-x*.09,group);
    seam.rotation.z=Math.PI/2-.08;seam.rotation.y=.09;
  }
  const knot=mesh(new T.CylinderGeometry(.089,.125,.22,7),'#99643c',-.41,.67,-.06,group);knot.rotation.z=.54;
  mesh(new T.DodecahedronGeometry(1,0),'#8ca54b',.42,.699,-.04,group).scale.set(.25,.078,.139);
}
````

### `dist/park-biscuit.js`

````javascript
import * as T from './assets/three.module.js';

// The same paw stamp appears on the baked face and in the compact HUD.
const pad=[[0,-.15,.30,.216],[-.35,.15,.106,.16],[-.13,.35,.115,.166],[.14,.35,.115,.166],[.35,.15,.106,.16]];
// Short, broad waist and notched ends form one continuous, baked bone.
const bone=new T.Shape();
bone.moveTo(-.92,0);
bone.bezierCurveTo(-1.24,-.33,-1.05,-.64,-.76,-.58);
bone.bezierCurveTo(-.53,-.55,-.56,-.34,-.31,-.315);
bone.bezierCurveTo(-.09,-.29,.11,-.30,.32,-.32);
bone.bezierCurveTo(.55,-.34,.55,-.56,.77,-.585);
bone.bezierCurveTo(1.08,-.635,1.23,-.29,.92,0);
bone.bezierCurveTo(1.20,.31,1.06,.61,.78,.57);
bone.bezierCurveTo(.53,.55,.56,.33,.31,.315);
bone.bezierCurveTo(.10,.295,-.11,.295,-.31,.315);
bone.bezierCurveTo(-.57,.33,-.54,.565,-.78,.58);
bone.bezierCurveTo(-1.08,.615,-1.21,.29,-.92,0);
const outline=bone.getPoints(6);
if(outline.at(-1).equals(outline[0]))outline.pop();
const stamps=pad.map(([x,y,rx,ry])=>Array.from({length:16},(_,i)=>{
  const a=-i*Math.PI/8;
  return new T.Vector2((x+rx*Math.cos(a))*.56,(y+ry*Math.sin(a))*.56);
}));
const svgPath=loop=>loop.map(({x,y},i)=>(i?'L':'M')+x.toFixed(3)+' '+(-y).toFixed(3)).join(' ')+'Z';
export const biscuitIcon='<svg viewBox="-1.19 -.71 2.38 1.42" aria-hidden="true"><path d="'+svgPath(outline)+'" fill="#efc384" stroke="#99633d" stroke-width=".11"/><path d="'+stamps.map(svgPath).join('')+'" fill="#91572f"/></svg>';

export function parkBiscuitGeometry(){
  const positions=[],colors=[],indices=[];
  const addLoop=(loop,depth,color,scale=1,center=new T.Vector2())=>{
    const start=positions.length/3,tint=new T.Color(color);
    for(const v of loop){
      positions.push((center.x+(v.x-center.x)*scale)*.327,(center.y+(v.y-center.y)*scale)*.327,depth);
      colors.push(tint.r,tint.g,tint.b);
    }
    return start;
  };
  function stitch(lower,upper,count){
    for(let i=0;i<count;i++){
      const j=(i+1)%count;
      indices.push(lower+i,lower+j,upper+j,lower+i,upper+j,upper+i);
    }
  }
  const back=addLoop(outline,-.052,'#b97a42',.94);
  const crust=addLoop(outline,-.034,'#c78749');
  const edge=addLoop(outline,.031,'#d89a54');
  const top=addLoop(outline,.053,'#f1c080',.95);
  stitch(back,crust,outline.length);stitch(crust,edge,outline.length);stitch(edge,top,outline.length);
  for(const face of T.ShapeUtils.triangulateShape(outline,[]))indices.push(...face.reverse().map(i=>i+back));
  // Triangulate the top around five actual shallow impressions.
  const outerFace=outline.map(v=>v.clone().multiplyScalar(.95));
  for(const stamp of stamps)addLoop(stamp,.053,'#d5a16a');
  for(const face of T.ShapeUtils.triangulateShape(outerFace,stamps))indices.push(...face.map(i=>i+top));
  let lip=top+outline.length;
  stamps.forEach((stamp,i)=>{
    const center=new T.Vector2(pad[i][0],pad[i][1]).multiplyScalar(.56);
    const bottom=addLoop(stamp,.038,'#956537',.80,center);
    stitch(bottom,lip,stamp.length);
    for(const tri of T.ShapeUtils.triangulateShape(stamp,[]))indices.push(...tri.map(j=>bottom+j));
    lip+=stamp.length;
  });
  const geo=new T.BufferGeometry();
  geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));
  geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  geo.setIndex(indices);geo.computeVertexNormals();
  geo.rotateZ(.22);geo.rotateX(-.38);
  return geo;
}
````

### `dist/park-camera.js`

````javascript
import {MathUtils} from './assets/three.module.js';
import {chaseCameraPose} from './chase-camera.js';
import {routePoint} from './race-route.js';
import {parkExitOffset} from './tunnel.js';
import {RACE} from './race-sim.js';

// Prior lane samples only set how long the close view lasts. The camera and
// its target always share the runner's current lateral position and heading.
export function makeParkCamera(obstacles) {
  const gates = obstacles.filter(o => o.type === 'tunnel');
  const trail = [];
  function lateralAt(s) {
    const i = trail.findIndex(sample => sample.s >= s);
    if (i < 0) return trail.at(-1).x;
    if (i === 0) return trail[0].x;
    const a = trail[i - 1], b = trail[i];
    return MathUtils.lerp(a.x, b.x, (s - a.s) / (b.s - a.s));
  }
  return (runner, normalDistance, normalHeight) => {
    const {s, x} = runner;
    if (trail.length && s < trail.at(-1).s) trail.length = 0;
    if (!trail.length || s - trail.at(-1).s >= .10) trail.push({s, x});
    while (trail.length > 2 && trail[1].s < s - 10) trail.shift();
    const anchor = routePoint(s, x);
    const gate = gates.find(o => s > o.s - 22 && s < o.s + 24);
    if (!gate) return chaseCameraPose(anchor, {distance:normalDistance, height:normalHeight});
    const past = s - gate.s;
    const approach = MathUtils.smoothstep(past, -22, -7);
    const exit = 1 - MathUtils.smoothstep(past, 12, 24);
    const earlierX = lateralAt(s - normalDistance);
    const lane = gate.lane * RACE.lanewidth;
    const proximity = Math.min(Math.abs(x - lane), Math.abs(earlierX - lane));
    const through = approach * exit * (1 - MathUtils.smoothstep(proximity, .85, 1.85));
    const distance = MathUtils.lerp(normalDistance, 4.85, through);
    const height = MathUtils.lerp(normalHeight, 1.26, through);
    const lookHeight = MathUtils.lerp(1, .77, through);
    // At the exit a sideways runner may carry the camera across the solid
    // sleeve. Clear the lip along the chase axis before crossing the side wall.
    const lateral = Math.abs(x - lane);
    const crossesWall = MathUtils.smoothstep(lateral, .48, .98)
      * (1 - MathUtils.smoothstep(lateral, 1.85, 2));
    const beyondLip = past - parkExitOffset - .18;
    if (beyondLip > 0 && beyondLip < distance && crossesWall > 0) {
      const clearance = crossesWall * MathUtils.smoothstep(beyondLip, 0, .66);
      const safeDistance = MathUtils.lerp(distance, beyondLip, clearance);
      const ratio = safeDistance / distance;
      const safeLook = height + (lookHeight - height) * (safeDistance + 10) / (distance + 10);
      const pose = chaseCameraPose(anchor, {distance:safeDistance, height, lookHeight:safeLook});
      pose.zoom = ratio;
      return pose;
    }
    return chaseCameraPose(anchor, {distance, height, lookHeight});
  };
}
````

### `dist/race-track.js`

````javascript
import * as T from './assets/three.module.js';
import {dressPark,parkLog} from './park-art.js';
import {parkBiscuitGeometry} from './park-biscuit.js';
import {addTunnel,addParkTunnel} from './tunnel.js';
import {routePoint as parkPoint} from './race-route.js';
import {addForestScenery,addForestLog} from './forest-scene.js';
import {addBeachScenery,addDriftwood} from './beach-scene.js';
import {RACE} from './race-sim.js';
const mat=color=>new T.MeshStandardMaterial({color,roughness:1});

// One continuous ribbon keeps every lane connected through the 90-degree bends.
export function roadRibbon(lateral,width,y,from=-15,to=510,point=parkPoint){
 const vertices=[],indices=[],steps=Math.ceil(to-from);
 for(let i=0;i<=steps;i++){
  const s=from+(to-from)*i/steps;
  for(const side of [-1,1]){const p=point(s,lateral+side*width/2);vertices.push(p.x,y,p.z)}
  if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2)}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function makeRaceTrack(layout){
 const root=new T.Group();root.name=(layout.theme||'park')+'-race-track';const routePoint=layout.point||parkPoint,length=layout.length||RACE.length,end=length+30,field=layout.theme==='field';
 function mesh(geo,color,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,mat(color));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,c,x,y,z,parent=root){return mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent)}
 function groupAt(s,lateral=0){const p=routePoint(s,lateral),g=new T.Group();g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);return g}
 function pose(s,lateral,y,sx=1,sy=1,sz=1){const p=routePoint(s,lateral);return [p.x,y,p.z,sx,sy,sz,-p.heading]}
 function instances(geo,color,poses,name){const m=new T.InstancedMesh(geo,mat(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p[0],p[1],p[2]);dummy.scale.set(p[3]??1,p[4]??1,p[5]??1);dummy.rotation.set(0,p[6]??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 if(layout.theme==='beach'){
  addBeachScenery(layout,{mesh,box,pose,instances,groupAt,ribbon:roadRibbon});
 }else if(layout.theme==='forest'){
  addForestScenery(layout,{mesh,box,pose,instances,ribbon:roadRibbon});
 }else if(layout.theme==='park'){
  dressPark({root,routePoint,end,ribbon:roadRibbon,mesh,box,groupAt,instances,pose});
 }else{
  box(800,.12,800,'#9fb681',50,-.12,-200);
  mesh(roadRibbon(0,7.6,.015,-15,end,routePoint),field?'#b4c49a':'#cfbc95').name='continuous-road';
  for(const x of [-3.7,3.7])mesh(roadRibbon(x,.08,.025,-15,end,routePoint),'#e6d7b6');
  const lines=[];for(let s=-12;s<end;s+=5)for(const x of [-1,1])lines.push(pose(s,x,.025));
  instances(new T.BoxGeometry(.035,.015,1.5),'#e3d5b5',lines,'lane-markings');
  const trunks=[],crowns=[],caps=[],posts=[],rails=[];
  for(let s=-12;s<end;s+=4)for(const side of [-1,1])posts.push(pose(s,side*4.4,.6));
  for(let s=-12;s<end;s+=2)for(const side of [-1,1]){
   const a=routePoint(s,side*4.4),b=routePoint(s+2,side*4.4);
   rails.push([(a.x+b.x)/2,.75,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.04,-Math.atan2(b.x-a.x,a.z-b.z)]);
  }
  for(let s=-10;s<end;s+=11)for(const side of [-1,1]){
   const lateral=side*(7+(Math.abs(s)%4)*.6);
   trunks.push(pose(s,lateral,1));crowns.push(pose(s,lateral,2.5,1.3,1.5,1.3));caps.push(pose(s+.4,lateral+.45,3.2,1,1.2,1));
  }
  instances(new T.CylinderGeometry(.13,.17,2,7),'#8e7c54',trunks,'tree-trunks');
  instances(new T.SphereGeometry(1,10,7),'#79985f',crowns,'tree-crowns');
  instances(new T.SphereGeometry(1,10,7),'#8caa6a',caps,'tree-caps');
  instances(new T.BoxGeometry(.10,1.2,.10),'#d7c6a2',posts,'fence-posts');
  instances(new T.BoxGeometry(.07,.12,1),'#d7c6a2',rails,'fence-rails');
 }
 for(const t of layout.turns){
  for(const lead of [23,6]){
   const side=t.direction==='right'?-1:1,g=groupAt(t.start-lead,side*4.7);g.name='turn-sign';g.userData.turnId=t.id;
   box(.12,2.2,.12,'#778566',0,1.1,0,g);box(2.5,1.2,.12,'#315b49',0,2.2,0,g);
   const shape=new T.Shape();[[-.8,.14],[.12,.14],[.12,.43],[.8,0],[.12,-.43],[.12,-.14],[-.8,-.14]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
   const arrow=mesh(new T.ShapeGeometry(shape),'#f5df9f',0,2.2,.071,g);arrow.material.side=T.DoubleSide;if(t.direction==='left')arrow.scale.x=-1;
  }
 }
 for(const o of layout.obstacles){
  const g=groupAt(o.s,o.lane*RACE.lanewidth);g.name='race-obstacle';g.userData.obstacleId=o.id;
  if(o.type==='log'){
   if(layout.theme==='forest')addForestLog(g,mesh);else addDriftwood(g,mesh);
  }else if(o.type==='hurdle'&&layout.theme==='park'&&o.id%4===0){
   parkLog(g,mesh);
  }else if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.10,1.1,.12,'#72929b',x,.55,0,g);box(.42,.08,.6,'#72929b',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.20,.11,.10,j%2?'#c78465':'#f6edda',-.70+j*.20,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#d6b35a',0,1.7,0,g);
   for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#72929b',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#72929b',x,.04,0,g)}
  }else{
   if(layout.theme==='park')addParkTunnel(g,mesh);
   else {
    addTunnel(g,mesh);
    for(const side of [-1,1])box(.12,.10,6,'#6a97a2',side*1.58,.05,0,g);
   }
  }
 }
 const biscuit=parkBiscuitGeometry().scale(.76,.76,.76);
 const biscuitMaterial=new T.MeshStandardMaterial({vertexColors:true,roughness:.93});
 const treatMesh=new T.InstancedMesh(biscuit,biscuitMaterial,layout.treats.length);treatMesh.name='treat-trail';treatMesh.visible=layout.treats.length>0;root.add(treatMesh);
 function resetTreats(){const dummy=new T.Object3D();for(const t of layout.treats){const p=routePoint(t.s,t.lane*RACE.lanewidth);dummy.position.set(p.x,t.y,p.z);dummy.rotation.set(0,-p.heading,0);dummy.updateMatrix();treatMesh.setMatrixAt(t.id,dummy.matrix)}treatMesh.instanceMatrix.needsUpdate=true;if(layout.treats.length)treatMesh.computeBoundingSphere()}
 function collectTreat(id){treatMesh.setMatrixAt(id,new T.Matrix4().makeScale(0,0,0));treatMesh.instanceMatrix.needsUpdate=true}
 resetTreats();
 const finish=groupAt(length);finish.name='finish-gate';
 for(const x of [-3.6,3.6])box(.18,4,.18,'#607e6c',x,2,0,finish);
 for(let j=0;j<16;j++)for(let row=0;row<2;row++)box(.45,.35,.06,(j+row)%2?'#f6efda':'#486f59',-3.375+j*.45,3.3+row*.35,0,finish);
 const tiles=[];for(let j=0;j<16;j++)for(let k=0;k<2;k++)if((j+k)%2===0)tiles.push(pose(length-k*.5,-3.75+j*.5,.03));
 instances(new T.BoxGeometry(.5,.012,.5),'#f6f0dc',tiles,'finish-tiles');
 return {root,treatMesh,resetTreats,collectTreat};
}
````

### `dist/tunnel.js`

````javascript
import {parkTunnelRadius,parkTunnelLength,parkTunnelCenterZ} from './park-tunnel-profile.js';
import * as T from './assets/three.module.js';

export {parkExitOffset} from './park-tunnel-profile.js';

// One open-ended fabric arch under the hoops, also used by the course miniature.
export function addTunnel(parent, mesh, radius = 1.58, length = 6) {
  const fabric = new T.CylinderGeometry(radius, radius, length, 32, 1, true, Math.PI / 2, Math.PI);
  fabric.rotateX(Math.PI / 2);
  const wall = mesh(fabric, '#5686aa', 0, 0, 0, parent);
  wall.material.side = T.DoubleSide;
  wall.name = 'tunnel-fabric';
  const intervals = 8;
  for (let i = 0; i <= intervals; i++) {
    const end = i === 0 || i === intervals;
    const rib = mesh(new T.TorusGeometry(radius, radius * (end ? .068 : .032), 8, 32, Math.PI),
      end ? '#91b7c3' : '#729cba', 0, 0, length * (i / intervals - .5), parent);
    rib.name = end ? 'tunnel-rim' : 'tunnel-rib';
  }
}



// Both rims meet the ground. The park uses the original blue canvas sleeve
// with just enough headroom for a low camera following the smaller runner.
export function addParkTunnel(parent, mesh) {
  const radius = parkTunnelRadius, length = parkTunnelLength;
  const tunnel = new T.Group();
  tunnel.name = 'park-tunnel';
  tunnel.scale.y = 1.10;
  // Leave room past the exit rim for the first lateral step after the scored gate.
  tunnel.position.z = parkTunnelCenterZ;
  parent.add(tunnel);
  addTunnel(tunnel, mesh, radius, length);
  for (const side of [-1, 1]) {
    mesh(new T.BoxGeometry(.12, .08, length), '#75969c', side * radius, .04, 0, tunnel);
  }
}
````

