# 第10章　開発用比較画面と旧実装（2）

### `dist/review/v21/race-game.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeShiba,poseShiba} from '../../shiba.js';
import {makeDog} from '../../dog-model.js';
import {footingFor,poseLegs} from '../../dog-gait.js';
import {breeds} from '../../breeds.js';
import {RACE,RaceSimulation,gestureAction} from '../../race-sim.js';
import {routePoint,cornerAt} from '../../race-route.js';
import {AgilitySimulation,AGILITY} from '../../agility-sim.js';
import {courses,nextPlayableCourse} from '../../courses.js';
import {makeRaceTrack} from './race-track.js';
import {makeAgilityField} from '../../agility-field.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {helpContent} from '../../help-content.js';
import {A_FRAME,aFrameCameraLift} from '../../a-frame.js';
import {SEESAW} from '../../seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from '../../slalom.js';
import {finishRecord,formatTime as seconds} from '../../course-records.js';
const boneIcon='<svg viewBox="0 0 32 18" aria-hidden="true"><path d="M7 5C3-2-4 7 3 9c-7 2 0 11 4 4h18c4 7 11-2 4-4 7-2 0-11-4-4Z" fill="currentColor"/></svg>';
function faultText(event,sim){
 if(event.reason==='off-line')return sim.layout.obstacles.find(o=>o.id===event.id)?.type==='hoop'?'輪っかの横を通過':'ハードルの横を通過';
 if(event.reason==='slalom'){
  const firstMiss=sim.slaloms.get(event.id).passed.indexOf(false);
  return firstMiss>=0?`ポール${firstMiss+1}本目をミス`:'ポールの通過ミス';
 }
 const labels={'jump-low':'ジャンプが届かず','tunnel-entry':'トンネルの入口を外れた','tunnel-exit':'トンネルの出口を外れた',
  'board-entry':'シーソーに乗れず','board-stop':'停止位置を通過','ramp-entry':'坂の入口を外れた','ramp-jump':'坂の入口でジャンプ'};
 return labels[event.reason]??'ミス';
}
export function mountRace({container,breed,coat,onExit,onNextCourse,mode='race',courseId=mode==='agility'?'first-field':'park'}){
 const agility=mode==='agility',beach=mode==='race'&&courseId==='beach',forest=mode==='race'&&courseId==='forest',sim=agility?new AgilitySimulation(courseId):new RaceSimulation(courseId),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const park=courseId==='park';
 const allowShortFlick=beach||courseId==='hill-field';
 const point=sim.layout.point||routePoint,length=sim.layout.length||RACE.length,obstacleCount=sim.layout.obstacles.length,courseName=courses.find(course=>course.id===courseId)?.name||(agility?'はじめての広場':'公園');
 let renderer,scene,camera,light,dogs=[],track,frameId,last=0,uiTime=0,disposed=false,pointer=null,messageTimer,helpReturn=null;
 let countdownLabel='',turnLabel='',cameraOffset=6;
 const rivals=agility?'':sim.cpus.map((_,i)=>`<i class="rival-marker" style="--row:${i}" aria-hidden="true"></i>`).join('');
 const playerMarker=agility?'':'<i class="player-marker" aria-hidden="true"></i>';
 container.hidden=false;container.dataset.mode=mode;container.dataset.course=courseId;container.className='race-root';container.setAttribute('aria-label',courseName);
 container.innerHTML=`<canvas id="raceCanvas" tabindex="0" aria-label="${agility?'アジリティ。左右スワイプで移動、上でジャンプ、下で停止、タップで再開。':courseName+'レース。左右スワイプで移動と右左折、上でジャンプ、下でブレーキ、ゲージ満タン時にタップでダッシュ。'}"></canvas>
 <div class="race-hud"><div class="race-top"><div class="race-rank"><strong id="raceRank">${agility?'0':'1'}</strong><span>${agility?`/ ${obstacleCount} クリア`:`位 / ${sim.cpus.length+1}匹`}</span></div><div class="race-treats">${agility?'<span class="fault-label">ミス</span>':boneIcon}<span id="raceTreats">0</span></div><button id="pauseRace" aria-label="一時停止">Ⅱ</button></div><div class="race-progress" role="progressbar" aria-label="コースの進み具合" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="raceProgressFill"></div>${rivals}${playerMarker}</div><div class="race-course-label"><span>${courseName}</span><span id="raceClock">00:00.0</span></div></div>
 <div id="raceTurnCue" class="race-turn-cue" role="status" hidden></div><div id="raceCount" class="race-count" aria-live="polite"></div><div id="raceFeedback" class="race-feedback" role="status"></div>
 ${agility?`<div class="agility-bottom"><div class="agility-steps" aria-label="障害物の結果">${sim.layout.obstacles.map((o,i)=>`<span data-step="${o.id}" aria-label="障害物${i+1} 未通過">${i+1}</span>`).join('')}</div><div id="agilityStopped" class="agility-stopped" role="status" hidden>停止中 <span>タップで再開</span></div></div>`:`<div class="race-bottom"><div class="race-gauge-label"><span>${boneIcon}<b id="raceDashHint">ダッシュ</b></span><strong id="raceGaugeCount">0 / 20</strong></div><div id="raceGauge" class="race-gauge" role="meter" aria-label="ダッシュゲージ" aria-valuemin="0" aria-valuemax="20" aria-valuenow="0"><div id="raceGaugeFill"></div></div></div>`}
 <div id="raceOverlay" class="race-overlay" role="dialog" aria-modal="true" aria-label="ゲームのメニュー"></div>`;
 const canvas=container.querySelector('#raceCanvas'),overlay=container.querySelector('#raceOverlay'),q=id=>container.querySelector('#'+id);
 const rivalMarkers=container.querySelectorAll('.rival-marker'),playerPin=container.querySelector('.player-marker');
 function setup(){
  renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const skyColor=forest?'#c1cfb0':beach?'#b5dce4':agility?'#bad7e3':'#9ed9ee';
  scene=new T.Scene();scene.background=new T.Color(skyColor);scene.fog=new T.Fog(skyColor,park?32:agility||beach?85:42,park?107:agility||beach?175:110);camera=new T.PerspectiveCamera(60,1,.1,180);
  scene.add(new T.HemisphereLight('#fff8e8','#8d9f75',2.5));light=new T.DirectionalLight('#fff0d7',2.7);light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:45});light.shadow.bias=-.0003;light.shadow.normalBias=.03;scene.add(light,light.target);
  if(park){
   renderer.toneMappingExposure=1.04;
   const dome=new T.Mesh(new T.SphereGeometry(134,24,12),new T.ShaderMaterial({
    side:T.BackSide,depthWrite:false,
    vertexShader:'varying float altitude; void main(){altitude=position.y/134.;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying float altitude; void main(){vec3 sky=mix(vec3(.73,.91,.89),vec3(.26,.67,.88),smoothstep(-.035,.34,altitude));gl_FragColor=vec4(sky,1.);}'
   }));
   dome.name='park-sky';dome.renderOrder=-10;scene.add(dome);
  }
  track=agility?makeAgilityField(sim.layout):makeRaceTrack(sim.layout);scene.add(track.root);
  const roster=agility?[breed]:[breed,...breeds.filter(b=>b.id!==breed.id).slice(0,sim.cpus.length)];
  dogs=roster.map((b,i)=>{const fur=i===0?coat:park?({corgi:2,poodle:1,dachshund:1}[b.id]??0):0;const dog=park&&b.id==='shiba'?makeShiba(fur):makeDog(b,fur);dog.scale.setScalar(park&&b.id==='shiba'?.94:.76);dog.rotation.y=Math.PI;dog.traverse(o=>{if(o.isMesh)o.castShadow=i===0});scene.add(dog);const shadow=new T.Mesh(new T.CircleGeometry(.8,24),new T.MeshStandardMaterial({color:'#536848',transparent:true,opacity:.15}));shadow.rotation.x=-Math.PI/2;scene.add(shadow);return {dog,shadow}});
  camera.position.set(0,2.8,6);resize();
 }
 function resize(){if(!renderer)return;const r=container.getBoundingClientRect();if(r.width<1||r.height<1)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.fov=r.width>r.height?54:60;camera.updateProjectionMatrix()}
 function message(text){clearTimeout(messageTimer);q('raceFeedback').textContent=text;messageTimer=setTimeout(()=>q('raceFeedback')&&(q('raceFeedback').textContent=''),1300)}
 function ready(){
  helpReturn=null;q('pauseRace').hidden=true;overlay.hidden=false;
  overlay.innerHTML=`<div class="race-modal race-ready"><span class="race-overline">${agility?'アジリティ':'レース'}</span><h2>${courseName}</h2><div class="start-summary"><span>${breed.name}</span><span>${agility?`${obstacleCount}つの障害物`:`${sim.cpus.length+1}匹で競走`}</span></div><button id="startRun" class="primary">走る <span>→</span></button><div class="race-menu-links"><button id="readyHelp" class="race-secondary">遊び方</button><button id="readyExit" class="race-secondary">コース選択</button></div></div>`;
  q('startRun').onclick=begin;q('readyExit').onclick=onExit;q('readyHelp').onclick=()=>showHelp(ready);q('startRun').focus({preventScroll:true});
 }
 function showHelp(returnTo){
  helpReturn=returnTo;overlay.hidden=false;overlay.innerHTML=`<div class="race-modal game-help"><div class="help-heading"><h2>遊び方</h2><button id="closeGameHelp" class="close" aria-label="遊び方を閉じる">×</button></div>${helpContent(mode,'game',courseId)}</div>`;
  q('closeGameHelp').onclick=closeHelp;q('closeGameHelp').focus({preventScroll:true});
 }
 function closeHelp(){const back=helpReturn;helpReturn=null;back?.()}
 function begin(){pointer=null;helpReturn=null;overlay.hidden=true;q('pauseRace').hidden=false;sim.start();updateHUD();canvas.focus({preventScroll:true})}
 function pause(){
  if(window.parkReview)return;
  pointer=null;sim.pause();if(sim.status!=='paused')return;helpReturn=null;overlay.hidden=false;
  overlay.innerHTML='<div class="race-modal"><h2>一時停止</h2><button id="resumeRun" class="primary">続ける <span>→</span></button><button id="restartRun" class="race-secondary">最初から</button><div class="race-menu-links"><button id="pauseHelp" class="race-secondary">遊び方</button><button id="pauseExit" class="race-secondary">コース選択</button></div></div>';
  q('resumeRun').onclick=()=>{overlay.hidden=true;sim.resume();last=performance.now();updateHUD();canvas.focus({preventScroll:true})};q('restartRun').onclick=restart;q('pauseExit').onclick=onExit;q('pauseHelp').onclick=()=>showHelp(pause);q('resumeRun').focus({preventScroll:true});updateHUD();
 }
 function restart(){sim.reset();track.resetTreats();camera.position.set(0,2.8,6);cameraOffset=6;last=performance.now();q('raceFeedback').textContent='';begin()}
 function result(){
  const r=sim.result,record=finishRecord(courseId,agility?r.total:r.time);
  const recordLabel=record.temporary?'今回のベスト':'自己ベスト';
  const recordRow=`<div class="result-record" data-record-state="${record.state}">
   <span class="record-pair">${recordLabel} <strong>${seconds(record.best)}</strong></span>
   <span class="record-delta">${record.label}</span></div>`;
  q('pauseRace').hidden=true;overlay.hidden=false;
  const stats=agility?`<div><span>走行タイム</span><strong>${seconds(r.time)}</strong></div><div><span>ペナルティ</span><strong>+${r.penalty}秒</strong></div><div><span>クリア</span><strong>${r.cleared} / ${obstacleCount}</strong></div><div><span>ミス</span><strong>${r.faults}回</strong></div>`:`<div><span>タイム</span><strong>${seconds(r.time)}</strong></div><div><span>おやつ</span><strong>${r.treats}個</strong></div><div><span>ダッシュ</span><strong>${r.dashes}回</strong></div><div><span>障害物のミス</span><strong>${r.hits}回</strong></div>`;
  const next=onNextCourse&&nextPlayableCourse(mode,courseId);
  const nextButton=next?`<button id="nextCourseRun" class="primary result-next" aria-label="次のコース「${next.name}」へ">${next.shortName}へ <span aria-hidden="true">→</span></button>`:'';
  overlay.innerHTML=`<div class="race-modal race-result"><span class="race-overline">${courseName}</span>${agility?`<div class="result-score">${r.total.toFixed(2)}<span>秒</span></div>`:`<div class="result-rank">${r.rank}<span>位 / ${sim.cpus.length+1}匹</span></div>`}<h2>${agility?(r.faults===0?'ノーミスで完走！':'完走！'):(r.rank===1?'いちばんでゴール！':'完走！')}</h2><div class="race-stats">${stats}</div>${agility?'':`<p class="race-turn-result">曲がり損ね ${r.turnMisses}回</p>`}${recordRow}<div class="result-actions"><button id="retryRun" class="primary">もう一度 <span aria-hidden="true">↻</span></button>${nextButton}</div><button id="resultExit" class="race-secondary">コース選択</button></div>`;
  if(next)q('nextCourseRun').onclick=()=>{if(!disposed)onNextCourse(next.id)};
  q('retryRun').onclick=restart;q('resultExit').onclick=onExit;q('retryRun').focus({preventScroll:true});
 }
 function updateHUD(){
  q('raceRank').textContent=agility?sim.cleared:sim.rank;q('raceTreats').textContent=agility?sim.faults:sim.treatCount;
  const progress=Math.min(100,sim.player.s/length*100);q('raceProgressFill').style.width=progress+'%';container.querySelector('.race-progress').setAttribute('aria-valuenow',Math.round(progress));q('raceClock').textContent=`${String(Math.floor(sim.time/60)).padStart(2,'0')}:${(sim.time%60).toFixed(1).padStart(4,'0')}`;
  if(agility){
   track?.update(sim);
   for(const o of sim.layout.obstacles){const el=container.querySelector(`[data-step="${o.id}"]`),done=sim.results.has(o.id),clear=sim.results.get(o.id);el.dataset.state=done?(clear?'clear':'miss'):'pending';el.textContent=done?(clear?'✓':'−'):o.id+1;el.setAttribute('aria-label',`障害物${o.id+1} ${done?(clear?'クリア':'ミス'):'未通過'}`)}
   q('agilityStopped').hidden=!(sim.stopped&&sim.status==='running'&&!sim.activeSeesaw);updateObstacleCue();
  }else{
   playerPin.style.left=progress+'%';
   sim.cpus.forEach((dog,i)=>{rivalMarkers[i].style.left=Math.max(0,Math.min(100,dog.s/length*100))+'%'});
   const boost=sim.player.boost>0,ready=sim.gauge===RACE.gaugeMax&&!boost;
   q('raceGaugeCount').textContent=boost?`${sim.player.boost.toFixed(1)}秒`:`${sim.gauge} / 20`;
   q('raceGaugeFill').style.width=sim.gauge/RACE.gaugeMax*100+'%';q('raceGauge').setAttribute('aria-valuenow',sim.gauge);
   container.classList.toggle('dash-ready',ready);container.classList.toggle('boosting',boost);q('raceDashHint').textContent=boost?'ダッシュ中':ready?'タップでダッシュ':'ダッシュ';updateTurnCue();
  }
  const label=sim.status==='countdown'?String(Math.ceil(sim.countdown)):'';if(label!==countdownLabel){countdownLabel=label;q('raceCount').textContent=label}
 }
 function updateTurnCue(){
  const cue=sim.status==='running'?sim.turnCue:null,el=q('raceTurnCue');el.hidden=!cue;container.classList.toggle('turn-visible',!!cue);if(!cue){turnLabel='';return}
  const right=cue.direction==='right',direction=right?'右':'左';
  const state=cue.waiting?'waiting':cue.armed?'armed':cue.active?'active':'ahead';
  const label=cue.waiting?`${direction}へスワイプ`:cue.armed?(sim.player.s>=cue.start?`${direction}カーブ`:`${direction}折 OK`):cue.active?`${direction}へスワイプ`:`この先 ${direction}カーブ`;
  const key=`${cue.id}:${state}:${label}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=state;
  el.innerHTML=`<strong aria-hidden="true">${right?'↱':'↰'}</strong><span><small>${cue.id+1} / ${sim.layout.turns.length}</small><b>${label}</b></span>${cue.armed?'<span class="turn-check" aria-hidden="true">✓</span>':''}`;
 }
 function updateObstacleCue(){
  const o=sim.status==='running'?sim.nextObstacle:null,el=q('raceTurnCue');el.hidden=!o;container.classList.toggle('turn-visible',!!o);if(!o){turnLabel='';return}
  const names={'a-frame':'Aフレーム',hurdle:'ハードル',hoop:'輪っか',tunnel:'トンネル',seesaw:'シーソー',slalom:'スラローム'},lane=o.lane<0?'左':o.lane>0?'右':'中央';
  const aligned=Math.abs(sim.player.x-o.lane*2)<(o.type==='seesaw'?.48:o.type==='a-frame'?A_FRAME.entryTolerance:.72),near=(o.type==='slalom'?slalomPoleS(o,0):o.type==='a-frame'?o.s-A_FRAME.run:o.s)-sim.player.s<8,board=sim.activeSeesaw,slalom=sim.activeSlalom;
  let icon=!aligned?(o.lane*2<sim.player.x?'←':'→'):o.type==='tunnel'?'∩':['seesaw','slalom','a-frame'].includes(o.type)?'◇':near?'↑':'◇',label=names[o.type],detail=`${o.id+1} / ${obstacleCount} · ${lane}`;
  if(o.type==='a-frame'){
   if(sim.rampPass){icon='◇';label=sim.rampPass.onBoard?'坂を駆け抜けよう':'坂の横を通過中'}
   else if(near&&aligned){icon='◇';label='黄色い入口へ'}
  }
  if(board){const phase=board.state.phase;label=phase==='hold'||phase==='tipping'?'板が下がるまで待つ':phase==='ready'?'タップで再開':sim.stopped?'タップで再開':phase==='exit'?'そのまま進もう':sim.player.s-o.s>=SEESAW.stopFrom?'下スワイプで停止':'中央へ進もう';icon=phase==='hold'||phase==='tipping'?'…':phase==='ready'||sim.stopped?'●':phase==='exit'?'✓':sim.player.s-o.s>=SEESAW.stopFrom?'↓':'◇'}
  if(slalom){const index=slalom.state.index,done=index>=SLALOM.count,right=slalomSide(o,index)>0;icon=done?'✓':right?'→':'←';label=done?'出口へ':right?'右を通る':'左を通る';detail=`${o.id+1} / ${obstacleCount} · ポール ${Math.min(index+1,SLALOM.count)} / ${SLALOM.count}`}
  const key=`${o.id}:${icon}:${label}:${detail}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=near?'active':'ahead';
  el.innerHTML=`<strong aria-hidden="true">${icon}</strong><span><small>${detail}</small><b>${label}</b></span>`;
 }
 function frame(t){
  if(disposed)return;
  const dt=window.parkReview?.stepSeconds??(last?Math.max(0,Math.min(.2,(t-last)/1000)):0);last=t;
  // Keep ordinary slow frames on the game clock without skipping whole obstacles.
  const steps=Math.max(1,Math.ceil(dt/.05));
  for(let step=0;step<steps;step++)sim.step(dt/steps);
  track.animate?.(sim);
  for(const e of sim.drainEvents()){
   if(e.type==='treat')track.collectTreat(e.id);if(e.type==='hit')message('減速');if(e.type==='dash')message('ダッシュ！');if(e.type==='go')message('スタート！');
   if(e.type==='turn-wrong')message(e.direction==='right'?'右へ':'左へ');if(e.type==='turn-missed')message('ストップ');
   if(e.type==='obstacle-clear')message('クリア！');if(e.type==='obstacle-miss')message(`${faultText(e,sim)}　+${AGILITY.penalty}秒`);if(e.type==='finish')result();
   if(e.type==='seesaw-recover')message('止まり損ね');
  }
  const footing=footingFor(sim,agility);
  [sim.player,...sim.cpus].forEach((a,i)=>{
   if(sim.status==='paused')return;
   const {dog,shadow}=dogs[i],held=i===0&&(agility?sim.stopped:sim.waitingTurn!==null),run=sim.status==='running'&&a.finishTime===null&&!held,p=point(a.s,a.x),corner=agility?null:cornerAt(a.s,0,0,sim.layout.turns);
   dog.position.set(p.x,a.y+(run&&!reduced&&!a.surfaceY?Math.abs(Math.cos(a.phase*1.85))*.025:0),p.z);dog.rotation.order='YXZ';dog.rotation.x=a.pitch||0;dog.rotation.y=Math.PI-p.heading;
   dog.rotation.z=run&&!reduced?((agility?sim.targetX:a.lane*RACE.lanewidth)-a.x)*.07+(corner?(corner.direction==='right'?.08:-.08):0):0;
   poseLegs(dog,a.phase,run,a.jumpElapsed!==null,footing);
   if(dog.userData.expression)poseShiba(dog,t/1000,run,reduced);else dog.userData.tail.rotation.y=reduced?0:Math.sin(t*.006+i)*.15;shadow.position.set(p.x,.035,p.z);shadow.scale.setScalar(a.jumpElapsed!==null?.7:1);shadow.visible=!a.surfaceY;
  });
  const p=sim.player,nearTunnel=sim.layout.obstacles.some(o=>o.type==='tunnel'&&o.s-p.s<9&&o.s-p.s>-6&&Math.abs(p.x-o.lane*RACE.lanewidth)<.8);
  const surface=p.surfaceY||0,onRamp=sim.rampPass?.onBoard;
  const lift=onRamp?aFrameCameraLift(surface):surface;
  const height=surface?2.8+lift:camera.position.y+((nearTunnel?1.15:2.8+(reduced?0:p.y*.18))-camera.position.y)*(1-Math.exp(-dt*6));
  const follow=park?Math.min(8.65,Math.max(6,3.58/camera.aspect)):6;
  cameraOffset+=((nearTunnel?4:follow)-cameraOffset)*(1-Math.exp(-dt*5));
  const anchor=point(p.s,p.x),pose=chaseCameraPose(anchor,{distance:cameraOffset,height,lookHeight:nearTunnel?.65:1+lift*(onRamp ? .65 : 1)});
  camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);
  if(park)scene.getObjectByName('park-sky').position.copy(camera.position);
  light.position.set(anchor.x-7,12,anchor.z+6);light.target.position.set(anchor.x,0,anchor.z);
  uiTime+=dt;
  if(uiTime>.08||sim.status==='countdown'){updateHUD();uiTime=0}
  else if(beach&&sim.status==='running')updateTurnCue();
  if(!window.parkReview?.skipDraw)renderer.render(scene,camera);frameId=requestAnimationFrame(frame);
 }
 function pointerDown(e){
  if(!e.isPrimary||sim.status!=='running'||pointer)return;
  pointer={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),used:false,tapEligible:true};
  canvas.setPointerCapture(e.pointerId);
 }
 function readPointer(e,isRelease){
  if(!pointer||pointer.id!==e.pointerId||pointer.used)return;
  const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
  if(Math.hypot(dx,dy)>=12)pointer.tapEligible=false;
  const action=gestureAction(dx,dy,performance.now()-pointer.time,allowShortFlick);
  if(!action||(action==='dash'&&(!isRelease||!pointer.tapEligible)))return;
  pointer.used=true;
  sim.input(action);
 }
 function pointerMove(e){readPointer(e,false)}
 function cancelPointer(e){if(pointer?.id===e.pointerId)pointer=null}
 function pointerUp(e){readPointer(e,true);cancelPointer(e)}
 function key(e){if(e.target?.tagName==='BUTTON')return;const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',ArrowDown:'brake',' ':'dash'};if(e.key==='Escape'){e.preventDefault();pause()}else if(map[e.key]){e.preventDefault();if(!e.repeat)sim.input(map[e.key])}}
 function visibility(){if(document.hidden)pause()}
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'&&helpReturn){e.preventDefault();closeHelp();return}if(e.key!=='Tab'||overlay.hidden)return;const buttons=[...overlay.querySelectorAll('button')],first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',cancelPointer);canvas.addEventListener('lostpointercapture',cancelPointer);canvas.addEventListener('keydown',key);q('pauseRace').onclick=pause;document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',pause);window.addEventListener('resize',resize);
 const observer=new ResizeObserver(resize);observer.observe(container);
 try{setup();ready();frameId=requestAnimationFrame(frame)}catch(e){console.error('Race rendering unavailable',e);overlay.hidden=false;overlay.innerHTML='<div class="race-modal"><h2>3D表示を開始できませんでした</h2><button id="errorExit" class="primary">コース選択</button></div>';q('errorExit').onclick=onExit;q('pauseRace').hidden=true;q('errorExit').focus({preventScroll:true})}
 return {mode,courseId,pause,dispose(){disposed=true;cancelAnimationFrame(frameId);clearTimeout(messageTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',pause);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());light?.dispose();renderer?.dispose();renderer?.forceContextLoss();container.innerHTML='';container.hidden=true}};
}
````

### `dist/review/v21/race-track.js`

````javascript
import * as T from '../../assets/three.module.js';
import {dressPark,parkLog} from './park-art.js';
import {addTunnel} from '../../tunnel.js';
import {routePoint as parkPoint} from '../../race-route.js';
import {addForestScenery,addForestLog} from '../../forest-scene.js';
import {addBeachScenery,addDriftwood} from '../../beach-scene.js';
import {RACE} from '../../race-sim.js';
const mat=color=>new T.MeshStandardMaterial({color,roughness:1});

// One continuous ribbon keeps every lane connected through the 90-degree bends.
export function roadRibbon(lateral,width,y,from=-15,to=510,point=parkPoint){
 const vertices=[],indices=[],steps=Math.ceil(to-from);
 for(let i=0;i<=steps;i++){
  const s=from+(to-from)*i/steps;
  for(const side of [-1,1]){const p=point(s,lateral+side*width/2);vertices.push(p.x,y,p.z)}
  if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2)}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function makeRaceTrack(layout){
 const root=new T.Group();root.name=(layout.theme||'park')+'-race-track';const routePoint=layout.point||parkPoint,length=layout.length||RACE.length,end=length+30,field=layout.theme==='field';
 function mesh(geo,color,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,mat(color));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,c,x,y,z,parent=root){return mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent)}
 function groupAt(s,lateral=0){const p=routePoint(s,lateral),g=new T.Group();g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);return g}
 function pose(s,lateral,y,sx=1,sy=1,sz=1){const p=routePoint(s,lateral);return [p.x,y,p.z,sx,sy,sz,-p.heading]}
 function instances(geo,color,poses,name){const m=new T.InstancedMesh(geo,mat(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p[0],p[1],p[2]);dummy.scale.set(p[3]??1,p[4]??1,p[5]??1);dummy.rotation.set(0,p[6]??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 if(layout.theme==='beach'){
  addBeachScenery(layout,{mesh,box,pose,instances,groupAt,ribbon:roadRibbon});
 }else if(layout.theme==='forest'){
  addForestScenery(layout,{mesh,box,pose,instances,ribbon:roadRibbon});
 }else if(layout.theme==='park'){
  dressPark({root,routePoint,end,ribbon:roadRibbon,mesh,box,groupAt,instances,pose});
 }else{
  box(800,.12,800,'#9fb681',50,-.12,-200);
  mesh(roadRibbon(0,7.6,.015,-15,end,routePoint),field?'#b4c49a':'#cfbc95').name='continuous-road';
  for(const x of [-3.7,3.7])mesh(roadRibbon(x,.08,.025,-15,end,routePoint),'#e6d7b6');
  const lines=[];for(let s=-12;s<end;s+=5)for(const x of [-1,1])lines.push(pose(s,x,.025));
  instances(new T.BoxGeometry(.035,.015,1.5),'#e3d5b5',lines,'lane-markings');
  const trunks=[],crowns=[],caps=[],posts=[],rails=[];
  for(let s=-12;s<end;s+=4)for(const side of [-1,1])posts.push(pose(s,side*4.4,.6));
  for(let s=-12;s<end;s+=2)for(const side of [-1,1]){
   const a=routePoint(s,side*4.4),b=routePoint(s+2,side*4.4);
   rails.push([(a.x+b.x)/2,.75,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.04,-Math.atan2(b.x-a.x,a.z-b.z)]);
  }
  for(let s=-10;s<end;s+=11)for(const side of [-1,1]){
   const lateral=side*(7+(Math.abs(s)%4)*.6);
   trunks.push(pose(s,lateral,1));crowns.push(pose(s,lateral,2.5,1.3,1.5,1.3));caps.push(pose(s+.4,lateral+.45,3.2,1,1.2,1));
  }
  instances(new T.CylinderGeometry(.13,.17,2,7),'#8e7c54',trunks,'tree-trunks');
  instances(new T.SphereGeometry(1,10,7),'#79985f',crowns,'tree-crowns');
  instances(new T.SphereGeometry(1,10,7),'#8caa6a',caps,'tree-caps');
  instances(new T.BoxGeometry(.10,1.2,.10),'#d7c6a2',posts,'fence-posts');
  instances(new T.BoxGeometry(.07,.12,1),'#d7c6a2',rails,'fence-rails');
 }
 for(const t of layout.turns){
  for(const lead of [23,6]){
   const side=t.direction==='right'?-1:1,g=groupAt(t.start-lead,side*4.7);g.name='turn-sign';g.userData.turnId=t.id;
   box(.12,2.2,.12,'#778566',0,1.1,0,g);box(2.5,1.2,.12,'#315b49',0,2.2,0,g);
   const shape=new T.Shape();[[-.8,.14],[.12,.14],[.12,.43],[.8,0],[.12,-.43],[.12,-.14],[-.8,-.14]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
   const arrow=mesh(new T.ShapeGeometry(shape),'#f5df9f',0,2.2,.071,g);arrow.material.side=T.DoubleSide;if(t.direction==='left')arrow.scale.x=-1;
  }
 }
 for(const o of layout.obstacles){
  const g=groupAt(o.s,o.lane*RACE.lanewidth);g.name='race-obstacle';g.userData.obstacleId=o.id;
  if(o.type==='log'){
   if(layout.theme==='forest')addForestLog(g,mesh);else addDriftwood(g,mesh);
  }else if(o.type==='hurdle'&&layout.theme==='park'&&o.id%4===0){
   parkLog(g,mesh);
  }else if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.10,1.1,.12,'#72929b',x,.55,0,g);box(.42,.08,.6,'#72929b',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.20,.11,.10,j%2?'#c78465':'#f6edda',-.70+j*.20,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#d6b35a',0,1.7,0,g);
   for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#72929b',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#72929b',x,.04,0,g)}
  }else{
   addTunnel(g,mesh);
   box(.12,.10,6,'#6a97a2',-1.58,.05,0,g);box(.12,.10,6,'#6a97a2',1.58,.05,0,g);
  }
 }
 const biscuit=boneGeometry();if(layout.theme==='park'){biscuit.scale(1.24,1.24,1.24);biscuit.rotateZ(.15);biscuit.rotateX(.65)}
 const treatMesh=new T.InstancedMesh(biscuit,mat(layout.theme==='park'?'#f3a127':'#dca644'),layout.treats.length);treatMesh.name='treat-trail';treatMesh.visible=layout.treats.length>0;root.add(treatMesh);
 function resetTreats(){const dummy=new T.Object3D();for(const t of layout.treats){const p=routePoint(t.s,t.lane*RACE.lanewidth);dummy.position.set(p.x,t.y,p.z);dummy.rotation.set(0,-p.heading,0);dummy.updateMatrix();treatMesh.setMatrixAt(t.id,dummy.matrix)}treatMesh.instanceMatrix.needsUpdate=true;if(layout.treats.length)treatMesh.computeBoundingSphere()}
 function collectTreat(id){treatMesh.setMatrixAt(id,new T.Matrix4().makeScale(0,0,0));treatMesh.instanceMatrix.needsUpdate=true}
 resetTreats();
 const finish=groupAt(length);finish.name='finish-gate';
 for(const x of [-3.6,3.6])box(.18,4,.18,'#607e6c',x,2,0,finish);
 for(let j=0;j<16;j++)for(let row=0;row<2;row++)box(.45,.35,.06,(j+row)%2?'#f6efda':'#486f59',-3.375+j*.45,3.3+row*.35,0,finish);
 const tiles=[];for(let j=0;j<16;j++)for(let k=0;k<2;k++)if((j+k)%2===0)tiles.push(pose(length-k*.5,-3.75+j*.5,.03));
 instances(new T.BoxGeometry(.5,.012,.5),'#f6f0dc',tiles,'finish-tiles');
 return {root,treatMesh,resetTreats,collectTreat};
}
function boneGeometry(){
 const items=[new T.BoxGeometry(.30,.12,.14)];
 for(const x of [-.15,.15])for(const z of [-.07,.07]){const g=new T.SphereGeometry(.095,8,6);g.translate(x,0,z);items.push(g)}
 const pos=[],norm=[];for(const g of items){const n=g.index?g.toNonIndexed():g;pos.push(...n.attributes.position.array);norm.push(...n.attributes.normal.array);n.dispose();g.dispose()}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(norm,3));return g;
}
````

### `dist/review/v22.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-game.js":"./v22/race-game.js","../race-sim.js":"./v26/race-sim.js","../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v22/race-game.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeShiba,poseShiba} from '../../shiba.js';
import {makeDog} from '../../dog-model.js';
import {footingFor,poseLegs} from '../../dog-gait.js';
import {breeds} from '../../breeds.js';
import {RACE,RaceSimulation,gestureAction} from '../../race-sim.js';
import {routePoint,cornerAt} from '../../race-route.js';
import {AgilitySimulation,AGILITY} from '../../agility-sim.js';
import {courses,nextPlayableCourse} from '../../courses.js';
import {biscuitIcon} from '../../park-biscuit.js';
import {makeRaceTrack} from './race-track.js';
import {makeAgilityField} from '../../agility-field.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {helpContent} from '../../help-content.js';
import {A_FRAME,aFrameCameraLift} from '../../a-frame.js';
import {SEESAW} from '../../seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from '../../slalom.js';
import {finishRecord,formatTime as seconds} from '../../course-records.js';
const boneIcon='<svg viewBox="0 0 32 18" aria-hidden="true"><path d="M7 5C3-2-4 7 3 9c-7 2 0 11 4 4h18c4 7 11-2 4-4 7-2 0-11-4-4Z" fill="currentColor"/></svg>';
function faultText(event,sim){
 if(event.reason==='off-line')return sim.layout.obstacles.find(o=>o.id===event.id)?.type==='hoop'?'輪っかの横を通過':'ハードルの横を通過';
 if(event.reason==='slalom'){
  const firstMiss=sim.slaloms.get(event.id).passed.indexOf(false);
  return firstMiss>=0?`ポール${firstMiss+1}本目をミス`:'ポールの通過ミス';
 }
 const labels={'jump-low':'ジャンプが届かず','tunnel-entry':'トンネルの入口を外れた','tunnel-exit':'トンネルの出口を外れた',
  'board-entry':'シーソーに乗れず','board-stop':'停止位置を通過','ramp-entry':'坂の入口を外れた','ramp-jump':'坂の入口でジャンプ'};
 return labels[event.reason]??'ミス';
}
export function mountRace({container,breed,coat,onExit,onNextCourse,mode='race',courseId=mode==='agility'?'first-field':'park'}){
 const agility=mode==='agility',beach=mode==='race'&&courseId==='beach',forest=mode==='race'&&courseId==='forest',sim=agility?new AgilitySimulation(courseId):new RaceSimulation(courseId),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const park=courseId==='park';
 const treatIcon=park?biscuitIcon:boneIcon;
 const allowShortFlick=beach||courseId==='hill-field';
 const point=sim.layout.point||routePoint,length=sim.layout.length||RACE.length,obstacleCount=sim.layout.obstacles.length,courseName=courses.find(course=>course.id===courseId)?.name||(agility?'はじめての広場':'公園');
 let renderer,scene,camera,light,dogs=[],track,frameId,last=0,uiTime=0,disposed=false,pointer=null,messageTimer,helpReturn=null;
 let countdownLabel='',turnLabel='',cameraOffset=6;
 const rivals=agility?'':sim.cpus.map((_,i)=>`<i class="rival-marker" style="--row:${i}" aria-hidden="true"></i>`).join('');
 const playerMarker=agility?'':'<i class="player-marker" aria-hidden="true"></i>';
 container.hidden=false;container.dataset.mode=mode;container.dataset.course=courseId;container.className='race-root';container.setAttribute('aria-label',courseName);
 container.innerHTML=`<canvas id="raceCanvas" tabindex="0" aria-label="${agility?'アジリティ。左右スワイプで移動、上でジャンプ、下で停止、タップで再開。':courseName+'レース。左右スワイプで移動と右左折、上でジャンプ、下でブレーキ、ゲージ満タン時にタップでダッシュ。'}"></canvas>
 <div class="race-hud"><div class="race-top"><div class="race-rank"><strong id="raceRank">${agility?'0':'1'}</strong><span>${agility?`/ ${obstacleCount} クリア`:`位 / ${sim.cpus.length+1}匹`}</span></div><div class="race-treats">${agility?'<span class="fault-label">ミス</span>':treatIcon}<span id="raceTreats">0</span></div><button id="pauseRace" aria-label="一時停止">Ⅱ</button></div><div class="race-progress" role="progressbar" aria-label="コースの進み具合" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="raceProgressFill"></div>${rivals}${playerMarker}</div><div class="race-course-label"><span>${courseName}</span><span id="raceClock">00:00.0</span></div></div>
 <div id="raceTurnCue" class="race-turn-cue" role="status" hidden></div><div id="raceCount" class="race-count" aria-live="polite"></div><div id="raceFeedback" class="race-feedback" role="status"></div>
 ${agility?`<div class="agility-bottom"><div class="agility-steps" aria-label="障害物の結果">${sim.layout.obstacles.map((o,i)=>`<span data-step="${o.id}" aria-label="障害物${i+1} 未通過">${i+1}</span>`).join('')}</div><div id="agilityStopped" class="agility-stopped" role="status" hidden>停止中 <span>タップで再開</span></div></div>`:`<div class="race-bottom"><div class="race-gauge-label"><span>${treatIcon}<b id="raceDashHint">ダッシュ</b></span><strong id="raceGaugeCount">0 / 20</strong></div><div id="raceGauge" class="race-gauge" role="meter" aria-label="ダッシュゲージ" aria-valuemin="0" aria-valuemax="20" aria-valuenow="0"><div id="raceGaugeFill"></div></div></div>`}
 <div id="raceOverlay" class="race-overlay" role="dialog" aria-modal="true" aria-label="ゲームのメニュー"></div>`;
 const canvas=container.querySelector('#raceCanvas'),overlay=container.querySelector('#raceOverlay'),q=id=>container.querySelector('#'+id);
 const rivalMarkers=container.querySelectorAll('.rival-marker'),playerPin=container.querySelector('.player-marker');
 function setup(){
  renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const skyColor=forest?'#c1cfb0':beach?'#b5dce4':agility?'#bad7e3':'#9ed9ee';
  scene=new T.Scene();scene.background=new T.Color(skyColor);scene.fog=new T.Fog(skyColor,park?32:agility||beach?85:42,park?107:agility||beach?175:110);camera=new T.PerspectiveCamera(60,1,.1,180);
  scene.add(new T.HemisphereLight('#fff8e8','#8d9f75',2.5));light=new T.DirectionalLight('#fff0d7',2.7);light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:45});light.shadow.bias=-.0003;light.shadow.normalBias=.03;scene.add(light,light.target);
  if(park){
   renderer.toneMappingExposure=1.04;
   const dome=new T.Mesh(new T.SphereGeometry(134,24,12),new T.ShaderMaterial({
    side:T.BackSide,depthWrite:false,
    vertexShader:'varying float altitude; void main(){altitude=position.y/134.;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying float altitude; void main(){vec3 sky=mix(vec3(.73,.91,.89),vec3(.26,.67,.88),smoothstep(-.035,.34,altitude));gl_FragColor=vec4(sky,1.);}'
   }));
   dome.name='park-sky';dome.renderOrder=-10;scene.add(dome);
  }
  track=agility?makeAgilityField(sim.layout):makeRaceTrack(sim.layout);scene.add(track.root);
  const roster=agility?[breed]:[breed,...breeds.filter(b=>b.id!==breed.id).slice(0,sim.cpus.length)];
  dogs=roster.map((b,i)=>{const fur=i===0?coat:park?({corgi:2,poodle:1,dachshund:1}[b.id]??0):0;const dog=park&&b.id==='shiba'?makeShiba(fur):makeDog(b,fur);dog.scale.setScalar(park&&b.id==='shiba'?.94:.76);dog.rotation.y=Math.PI;dog.traverse(o=>{if(o.isMesh)o.castShadow=i===0});scene.add(dog);const shadow=new T.Mesh(new T.CircleGeometry(.8,24),new T.MeshStandardMaterial({color:'#536848',transparent:true,opacity:.15}));shadow.rotation.x=-Math.PI/2;scene.add(shadow);return {dog,shadow}});
  camera.position.set(0,2.8,6);resize();
 }
 function resize(){if(!renderer)return;const r=container.getBoundingClientRect();if(r.width<1||r.height<1)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.fov=r.width>r.height?54:60;camera.updateProjectionMatrix()}
 function message(text){clearTimeout(messageTimer);q('raceFeedback').textContent=text;messageTimer=setTimeout(()=>q('raceFeedback')&&(q('raceFeedback').textContent=''),1300)}
 function ready(){
  helpReturn=null;q('pauseRace').hidden=true;overlay.hidden=false;
  overlay.innerHTML=`<div class="race-modal race-ready"><span class="race-overline">${agility?'アジリティ':'レース'}</span><h2>${courseName}</h2><div class="start-summary"><span>${breed.name}</span><span>${agility?`${obstacleCount}つの障害物`:`${sim.cpus.length+1}匹で競走`}</span></div><button id="startRun" class="primary">走る <span>→</span></button><div class="race-menu-links"><button id="readyHelp" class="race-secondary">遊び方</button><button id="readyExit" class="race-secondary">コース選択</button></div></div>`;
  q('startRun').onclick=begin;q('readyExit').onclick=onExit;q('readyHelp').onclick=()=>showHelp(ready);q('startRun').focus({preventScroll:true});
 }
 function showHelp(returnTo){
  helpReturn=returnTo;overlay.hidden=false;overlay.innerHTML=`<div class="race-modal game-help"><div class="help-heading"><h2>遊び方</h2><button id="closeGameHelp" class="close" aria-label="遊び方を閉じる">×</button></div>${helpContent(mode,'game',courseId)}</div>`;
  q('closeGameHelp').onclick=closeHelp;q('closeGameHelp').focus({preventScroll:true});
 }
 function closeHelp(){const back=helpReturn;helpReturn=null;back?.()}
 function begin(){pointer=null;helpReturn=null;overlay.hidden=true;q('pauseRace').hidden=false;sim.start();updateHUD();canvas.focus({preventScroll:true})}
 function pause(){
  if(window.parkReview)return;
  pointer=null;sim.pause();if(sim.status!=='paused')return;helpReturn=null;overlay.hidden=false;
  overlay.innerHTML='<div class="race-modal"><h2>一時停止</h2><button id="resumeRun" class="primary">続ける <span>→</span></button><button id="restartRun" class="race-secondary">最初から</button><div class="race-menu-links"><button id="pauseHelp" class="race-secondary">遊び方</button><button id="pauseExit" class="race-secondary">コース選択</button></div></div>';
  q('resumeRun').onclick=()=>{overlay.hidden=true;sim.resume();last=performance.now();updateHUD();canvas.focus({preventScroll:true})};q('restartRun').onclick=restart;q('pauseExit').onclick=onExit;q('pauseHelp').onclick=()=>showHelp(pause);q('resumeRun').focus({preventScroll:true});updateHUD();
 }
 function restart(){sim.reset();track.resetTreats();camera.position.set(0,2.8,6);cameraOffset=6;last=performance.now();q('raceFeedback').textContent='';begin()}
 function result(){
  const r=sim.result,record=finishRecord(courseId,agility?r.total:r.time);
  const recordLabel=record.temporary?'今回のベスト':'自己ベスト';
  const recordRow=`<div class="result-record" data-record-state="${record.state}">
   <span class="record-pair">${recordLabel} <strong>${seconds(record.best)}</strong></span>
   <span class="record-delta">${record.label}</span></div>`;
  q('pauseRace').hidden=true;overlay.hidden=false;
  const stats=agility?`<div><span>走行タイム</span><strong>${seconds(r.time)}</strong></div><div><span>ペナルティ</span><strong>+${r.penalty}秒</strong></div><div><span>クリア</span><strong>${r.cleared} / ${obstacleCount}</strong></div><div><span>ミス</span><strong>${r.faults}回</strong></div>`:`<div><span>タイム</span><strong>${seconds(r.time)}</strong></div><div><span>おやつ</span><strong>${r.treats}個</strong></div><div><span>ダッシュ</span><strong>${r.dashes}回</strong></div><div><span>障害物のミス</span><strong>${r.hits}回</strong></div>`;
  const next=onNextCourse&&nextPlayableCourse(mode,courseId);
  const nextButton=next?`<button id="nextCourseRun" class="primary result-next" aria-label="次のコース「${next.name}」へ">${next.shortName}へ <span aria-hidden="true">→</span></button>`:'';
  overlay.innerHTML=`<div class="race-modal race-result"><span class="race-overline">${courseName}</span>${agility?`<div class="result-score">${r.total.toFixed(2)}<span>秒</span></div>`:`<div class="result-rank">${r.rank}<span>位 / ${sim.cpus.length+1}匹</span></div>`}<h2>${agility?(r.faults===0?'ノーミスで完走！':'完走！'):(r.rank===1?'いちばんでゴール！':'完走！')}</h2><div class="race-stats">${stats}</div>${agility?'':`<p class="race-turn-result">曲がり損ね ${r.turnMisses}回</p>`}${recordRow}<div class="result-actions"><button id="retryRun" class="primary">もう一度 <span aria-hidden="true">↻</span></button>${nextButton}</div><button id="resultExit" class="race-secondary">コース選択</button></div>`;
  if(next)q('nextCourseRun').onclick=()=>{if(!disposed)onNextCourse(next.id)};
  q('retryRun').onclick=restart;q('resultExit').onclick=onExit;q('retryRun').focus({preventScroll:true});
 }
 function updateHUD(){
  q('raceRank').textContent=agility?sim.cleared:sim.rank;q('raceTreats').textContent=agility?sim.faults:sim.treatCount;
  const progress=Math.min(100,sim.player.s/length*100);q('raceProgressFill').style.width=progress+'%';container.querySelector('.race-progress').setAttribute('aria-valuenow',Math.round(progress));q('raceClock').textContent=`${String(Math.floor(sim.time/60)).padStart(2,'0')}:${(sim.time%60).toFixed(1).padStart(4,'0')}`;
  if(agility){
   track?.update(sim);
   for(const o of sim.layout.obstacles){const el=container.querySelector(`[data-step="${o.id}"]`),done=sim.results.has(o.id),clear=sim.results.get(o.id);el.dataset.state=done?(clear?'clear':'miss'):'pending';el.textContent=done?(clear?'✓':'−'):o.id+1;el.setAttribute('aria-label',`障害物${o.id+1} ${done?(clear?'クリア':'ミス'):'未通過'}`)}
   q('agilityStopped').hidden=!(sim.stopped&&sim.status==='running'&&!sim.activeSeesaw);updateObstacleCue();
  }else{
   playerPin.style.left=progress+'%';
   sim.cpus.forEach((dog,i)=>{rivalMarkers[i].style.left=Math.max(0,Math.min(100,dog.s/length*100))+'%'});
   const boost=sim.player.boost>0,ready=sim.gauge===RACE.gaugeMax&&!boost;
   q('raceGaugeCount').textContent=boost?`${sim.player.boost.toFixed(1)}秒`:`${sim.gauge} / 20`;
   q('raceGaugeFill').style.width=sim.gauge/RACE.gaugeMax*100+'%';q('raceGauge').setAttribute('aria-valuenow',sim.gauge);
   container.classList.toggle('dash-ready',ready);container.classList.toggle('boosting',boost);q('raceDashHint').textContent=boost?'ダッシュ中':ready?'タップでダッシュ':'ダッシュ';updateTurnCue();
  }
  const label=sim.status==='countdown'?String(Math.ceil(sim.countdown)):'';if(label!==countdownLabel){countdownLabel=label;q('raceCount').textContent=label}
 }
 function updateTurnCue(){
  const cue=sim.status==='running'?sim.turnCue:null,el=q('raceTurnCue');el.hidden=!cue;container.classList.toggle('turn-visible',!!cue);if(!cue){turnLabel='';return}
  const right=cue.direction==='right',direction=right?'右':'左';
  const state=cue.waiting?'waiting':cue.armed?'armed':cue.active?'active':'ahead';
  const label=cue.waiting?`${direction}へスワイプ`:cue.armed?(sim.player.s>=cue.start?`${direction}カーブ`:`${direction}折 OK`):cue.active?`${direction}へスワイプ`:`この先 ${direction}カーブ`;
  const key=`${cue.id}:${state}:${label}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=state;
  el.innerHTML=`<strong aria-hidden="true">${right?'↱':'↰'}</strong><span><small>${cue.id+1} / ${sim.layout.turns.length}</small><b>${label}</b></span>${cue.armed?'<span class="turn-check" aria-hidden="true">✓</span>':''}`;
 }
 function updateObstacleCue(){
  const o=sim.status==='running'?sim.nextObstacle:null,el=q('raceTurnCue');el.hidden=!o;container.classList.toggle('turn-visible',!!o);if(!o){turnLabel='';return}
  const names={'a-frame':'Aフレーム',hurdle:'ハードル',hoop:'輪っか',tunnel:'トンネル',seesaw:'シーソー',slalom:'スラローム'},lane=o.lane<0?'左':o.lane>0?'右':'中央';
  const aligned=Math.abs(sim.player.x-o.lane*2)<(o.type==='seesaw'?.48:o.type==='a-frame'?A_FRAME.entryTolerance:.72),near=(o.type==='slalom'?slalomPoleS(o,0):o.type==='a-frame'?o.s-A_FRAME.run:o.s)-sim.player.s<8,board=sim.activeSeesaw,slalom=sim.activeSlalom;
  let icon=!aligned?(o.lane*2<sim.player.x?'←':'→'):o.type==='tunnel'?'∩':['seesaw','slalom','a-frame'].includes(o.type)?'◇':near?'↑':'◇',label=names[o.type],detail=`${o.id+1} / ${obstacleCount} · ${lane}`;
  if(o.type==='a-frame'){
   if(sim.rampPass){icon='◇';label=sim.rampPass.onBoard?'坂を駆け抜けよう':'坂の横を通過中'}
   else if(near&&aligned){icon='◇';label='黄色い入口へ'}
  }
  if(board){const phase=board.state.phase;label=phase==='hold'||phase==='tipping'?'板が下がるまで待つ':phase==='ready'?'タップで再開':sim.stopped?'タップで再開':phase==='exit'?'そのまま進もう':sim.player.s-o.s>=SEESAW.stopFrom?'下スワイプで停止':'中央へ進もう';icon=phase==='hold'||phase==='tipping'?'…':phase==='ready'||sim.stopped?'●':phase==='exit'?'✓':sim.player.s-o.s>=SEESAW.stopFrom?'↓':'◇'}
  if(slalom){const index=slalom.state.index,done=index>=SLALOM.count,right=slalomSide(o,index)>0;icon=done?'✓':right?'→':'←';label=done?'出口へ':right?'右を通る':'左を通る';detail=`${o.id+1} / ${obstacleCount} · ポール ${Math.min(index+1,SLALOM.count)} / ${SLALOM.count}`}
  const key=`${o.id}:${icon}:${label}:${detail}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=near?'active':'ahead';
  el.innerHTML=`<strong aria-hidden="true">${icon}</strong><span><small>${detail}</small><b>${label}</b></span>`;
 }
 function frame(t){
  if(disposed)return;
  const dt=window.parkReview?.stepSeconds??(last?Math.max(0,Math.min(.2,(t-last)/1000)):0);last=t;
  // Keep ordinary slow frames on the game clock without skipping whole obstacles.
  const steps=Math.max(1,Math.ceil(dt/.05));
  for(let step=0;step<steps;step++)sim.step(dt/steps);
  track.animate?.(sim);
  for(const e of sim.drainEvents()){
   if(e.type==='treat')track.collectTreat(e.id);if(e.type==='hit')message('減速');if(e.type==='dash')message('ダッシュ！');if(e.type==='go')message('スタート！');
   if(e.type==='turn-wrong')message(e.direction==='right'?'右へ':'左へ');if(e.type==='turn-missed')message('ストップ');
   if(e.type==='obstacle-clear')message('クリア！');if(e.type==='obstacle-miss')message(`${faultText(e,sim)}　+${AGILITY.penalty}秒`);if(e.type==='finish')result();
   if(e.type==='seesaw-recover')message('止まり損ね');
  }
  const footing=footingFor(sim,agility);
  [sim.player,...sim.cpus].forEach((a,i)=>{
   if(sim.status==='paused')return;
   const {dog,shadow}=dogs[i],held=i===0&&(agility?sim.stopped:sim.waitingTurn!==null),run=sim.status==='running'&&a.finishTime===null&&!held,p=point(a.s,a.x),corner=agility?null:cornerAt(a.s,0,0,sim.layout.turns);
   dog.position.set(p.x,a.y+(run&&!reduced&&!a.surfaceY?Math.abs(Math.cos(a.phase*1.85))*.025:0),p.z);dog.rotation.order='YXZ';dog.rotation.x=a.pitch||0;dog.rotation.y=Math.PI-p.heading;
   dog.rotation.z=run&&!reduced?((agility?sim.targetX:a.lane*RACE.lanewidth)-a.x)*.07+(corner?(corner.direction==='right'?.08:-.08):0):0;
   poseLegs(dog,a.phase,run,a.jumpElapsed!==null,footing);
   if(dog.userData.expression)poseShiba(dog,t/1000,run,reduced);else dog.userData.tail.rotation.y=reduced?0:Math.sin(t*.006+i)*.15;shadow.position.set(p.x,.035,p.z);shadow.scale.setScalar(a.jumpElapsed!==null?.7:1);shadow.visible=!a.surfaceY;
  });
  const p=sim.player,nearTunnel=!park&&sim.layout.obstacles.some(o=>o.type==='tunnel'&&o.s-p.s<9&&o.s-p.s>-6&&Math.abs(p.x-o.lane*RACE.lanewidth)<.8);
  const surface=p.surfaceY||0,onRamp=sim.rampPass?.onBoard;
  const lift=onRamp?aFrameCameraLift(surface):surface;
  const height=surface?2.8+lift:camera.position.y+((nearTunnel?1.15:2.8+(reduced?0:p.y*.18))-camera.position.y)*(1-Math.exp(-dt*6));
  const follow=park?Math.min(8.65,Math.max(6,3.58/camera.aspect)):6;
  cameraOffset+=((nearTunnel?4:follow)-cameraOffset)*(1-Math.exp(-dt*5));
  const anchor=point(p.s,p.x),pose=chaseCameraPose(anchor,{distance:cameraOffset,height,lookHeight:nearTunnel?.65:1+lift*(onRamp ? .65 : 1)});
  camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);
  if(park){
   track.updateTunnelView(p.s,cameraOffset);
   scene.getObjectByName('park-sky').position.copy(camera.position);
  }
  light.position.set(anchor.x-7,12,anchor.z+6);light.target.position.set(anchor.x,0,anchor.z);
  uiTime+=dt;
  if(uiTime>.08||sim.status==='countdown'){updateHUD();uiTime=0}
  else if(beach&&sim.status==='running')updateTurnCue();
  if(!window.parkReview?.skipDraw)renderer.render(scene,camera);frameId=requestAnimationFrame(frame);
 }
 function pointerDown(e){
  if(!e.isPrimary||sim.status!=='running'||pointer)return;
  pointer={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),used:false,tapEligible:true};
  canvas.setPointerCapture(e.pointerId);
 }
 function readPointer(e,isRelease){
  if(!pointer||pointer.id!==e.pointerId||pointer.used)return;
  const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
  if(Math.hypot(dx,dy)>=12)pointer.tapEligible=false;
  const action=gestureAction(dx,dy,performance.now()-pointer.time,allowShortFlick);
  if(!action||(action==='dash'&&(!isRelease||!pointer.tapEligible)))return;
  pointer.used=true;
  sim.input(action);
 }
 function pointerMove(e){readPointer(e,false)}
 function cancelPointer(e){if(pointer?.id===e.pointerId)pointer=null}
 function pointerUp(e){readPointer(e,true);cancelPointer(e)}
 function key(e){if(e.target?.tagName==='BUTTON')return;const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',ArrowDown:'brake',' ':'dash'};if(e.key==='Escape'){e.preventDefault();pause()}else if(map[e.key]){e.preventDefault();if(!e.repeat)sim.input(map[e.key])}}
 function visibility(){if(document.hidden)pause()}
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'&&helpReturn){e.preventDefault();closeHelp();return}if(e.key!=='Tab'||overlay.hidden)return;const buttons=[...overlay.querySelectorAll('button')],first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',cancelPointer);canvas.addEventListener('lostpointercapture',cancelPointer);canvas.addEventListener('keydown',key);q('pauseRace').onclick=pause;document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',pause);window.addEventListener('resize',resize);
 const observer=new ResizeObserver(resize);observer.observe(container);
 try{setup();ready();frameId=requestAnimationFrame(frame)}catch(e){console.error('Race rendering unavailable',e);overlay.hidden=false;overlay.innerHTML='<div class="race-modal"><h2>3D表示を開始できませんでした</h2><button id="errorExit" class="primary">コース選択</button></div>';q('errorExit').onclick=onExit;q('pauseRace').hidden=true;q('errorExit').focus({preventScroll:true})}
 return {mode,courseId,pause,dispose(){disposed=true;cancelAnimationFrame(frameId);clearTimeout(messageTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',pause);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());light?.dispose();renderer?.dispose();renderer?.forceContextLoss();container.innerHTML='';container.hidden=true}};
}
````

### `dist/review/v22/race-track.js`

````javascript
import * as T from '../../assets/three.module.js';
import {dressPark,parkLog} from '../../park-art.js';
import {parkBiscuitGeometry} from '../../park-biscuit.js';
import {addTunnel,addParkTunnel} from './tunnel.js';
import {routePoint as parkPoint} from '../../race-route.js';
import {addForestScenery,addForestLog} from '../../forest-scene.js';
import {addBeachScenery,addDriftwood} from '../../beach-scene.js';
import {RACE} from '../../race-sim.js';
const mat=color=>new T.MeshStandardMaterial({color,roughness:1});

// One continuous ribbon keeps every lane connected through the 90-degree bends.
export function roadRibbon(lateral,width,y,from=-15,to=510,point=parkPoint){
 const vertices=[],indices=[],steps=Math.ceil(to-from);
 for(let i=0;i<=steps;i++){
  const s=from+(to-from)*i/steps;
  for(const side of [-1,1]){const p=point(s,lateral+side*width/2);vertices.push(p.x,y,p.z)}
  if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2)}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function makeRaceTrack(layout){
 const tunnelViews=[];
 const root=new T.Group();root.name=(layout.theme||'park')+'-race-track';const routePoint=layout.point||parkPoint,length=layout.length||RACE.length,end=length+30,field=layout.theme==='field';
 function mesh(geo,color,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,mat(color));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,c,x,y,z,parent=root){return mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent)}
 function groupAt(s,lateral=0){const p=routePoint(s,lateral),g=new T.Group();g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);return g}
 function pose(s,lateral,y,sx=1,sy=1,sz=1){const p=routePoint(s,lateral);return [p.x,y,p.z,sx,sy,sz,-p.heading]}
 function instances(geo,color,poses,name){const m=new T.InstancedMesh(geo,mat(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p[0],p[1],p[2]);dummy.scale.set(p[3]??1,p[4]??1,p[5]??1);dummy.rotation.set(0,p[6]??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 if(layout.theme==='beach'){
  addBeachScenery(layout,{mesh,box,pose,instances,groupAt,ribbon:roadRibbon});
 }else if(layout.theme==='forest'){
  addForestScenery(layout,{mesh,box,pose,instances,ribbon:roadRibbon});
 }else if(layout.theme==='park'){
  dressPark({root,routePoint,end,ribbon:roadRibbon,mesh,box,groupAt,instances,pose});
 }else{
  box(800,.12,800,'#9fb681',50,-.12,-200);
  mesh(roadRibbon(0,7.6,.015,-15,end,routePoint),field?'#b4c49a':'#cfbc95').name='continuous-road';
  for(const x of [-3.7,3.7])mesh(roadRibbon(x,.08,.025,-15,end,routePoint),'#e6d7b6');
  const lines=[];for(let s=-12;s<end;s+=5)for(const x of [-1,1])lines.push(pose(s,x,.025));
  instances(new T.BoxGeometry(.035,.015,1.5),'#e3d5b5',lines,'lane-markings');
  const trunks=[],crowns=[],caps=[],posts=[],rails=[];
  for(let s=-12;s<end;s+=4)for(const side of [-1,1])posts.push(pose(s,side*4.4,.6));
  for(let s=-12;s<end;s+=2)for(const side of [-1,1]){
   const a=routePoint(s,side*4.4),b=routePoint(s+2,side*4.4);
   rails.push([(a.x+b.x)/2,.75,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.04,-Math.atan2(b.x-a.x,a.z-b.z)]);
  }
  for(let s=-10;s<end;s+=11)for(const side of [-1,1]){
   const lateral=side*(7+(Math.abs(s)%4)*.6);
   trunks.push(pose(s,lateral,1));crowns.push(pose(s,lateral,2.5,1.3,1.5,1.3));caps.push(pose(s+.4,lateral+.45,3.2,1,1.2,1));
  }
  instances(new T.CylinderGeometry(.13,.17,2,7),'#8e7c54',trunks,'tree-trunks');
  instances(new T.SphereGeometry(1,10,7),'#79985f',crowns,'tree-crowns');
  instances(new T.SphereGeometry(1,10,7),'#8caa6a',caps,'tree-caps');
  instances(new T.BoxGeometry(.10,1.2,.10),'#d7c6a2',posts,'fence-posts');
  instances(new T.BoxGeometry(.07,.12,1),'#d7c6a2',rails,'fence-rails');
 }
 for(const t of layout.turns){
  for(const lead of [23,6]){
   const side=t.direction==='right'?-1:1,g=groupAt(t.start-lead,side*4.7);g.name='turn-sign';g.userData.turnId=t.id;
   box(.12,2.2,.12,'#778566',0,1.1,0,g);box(2.5,1.2,.12,'#315b49',0,2.2,0,g);
   const shape=new T.Shape();[[-.8,.14],[.12,.14],[.12,.43],[.8,0],[.12,-.43],[.12,-.14],[-.8,-.14]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
   const arrow=mesh(new T.ShapeGeometry(shape),'#f5df9f',0,2.2,.071,g);arrow.material.side=T.DoubleSide;if(t.direction==='left')arrow.scale.x=-1;
  }
 }
 for(const o of layout.obstacles){
  const g=groupAt(o.s,o.lane*RACE.lanewidth);g.name='race-obstacle';g.userData.obstacleId=o.id;
  if(o.type==='log'){
   if(layout.theme==='forest')addForestLog(g,mesh);else addDriftwood(g,mesh);
  }else if(o.type==='hurdle'&&layout.theme==='park'&&o.id%4===0){
   parkLog(g,mesh);
  }else if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.10,1.1,.12,'#72929b',x,.55,0,g);box(.42,.08,.6,'#72929b',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.20,.11,.10,j%2?'#c78465':'#f6edda',-.70+j*.20,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#d6b35a',0,1.7,0,g);
   for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#72929b',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#72929b',x,.04,0,g)}
  }else{
   if(layout.theme==='park')tunnelViews.push(addParkTunnel(g,mesh,o.s));
   else addTunnel(g,mesh);
   box(.12,.10,6,'#6a97a2',-1.58,.05,0,g);box(.12,.10,6,'#6a97a2',1.58,.05,0,g);
  }
 }
 const park=layout.theme==='park';
 const biscuit=park?parkBiscuitGeometry():boneGeometry();
 const biscuitMaterial=park?new T.MeshStandardMaterial({vertexColors:true,roughness:.93}):mat('#dca644');
 const treatMesh=new T.InstancedMesh(biscuit,biscuitMaterial,layout.treats.length);treatMesh.name='treat-trail';treatMesh.visible=layout.treats.length>0;root.add(treatMesh);
 function resetTreats(){const dummy=new T.Object3D();for(const t of layout.treats){const p=routePoint(t.s,t.lane*RACE.lanewidth);dummy.position.set(p.x,t.y,p.z);dummy.rotation.set(0,-p.heading,0);dummy.updateMatrix();treatMesh.setMatrixAt(t.id,dummy.matrix)}treatMesh.instanceMatrix.needsUpdate=true;if(layout.treats.length)treatMesh.computeBoundingSphere()}
 function collectTreat(id){treatMesh.setMatrixAt(id,new T.Matrix4().makeScale(0,0,0));treatMesh.instanceMatrix.needsUpdate=true}
 resetTreats();
 const finish=groupAt(length);finish.name='finish-gate';
 for(const x of [-3.6,3.6])box(.18,4,.18,'#607e6c',x,2,0,finish);
 for(let j=0;j<16;j++)for(let row=0;row<2;row++)box(.45,.35,.06,(j+row)%2?'#f6efda':'#486f59',-3.375+j*.45,3.3+row*.35,0,finish);
 const tiles=[];for(let j=0;j<16;j++)for(let k=0;k<2;k++)if((j+k)%2===0)tiles.push(pose(length-k*.5,-3.75+j*.5,.03));
 instances(new T.BoxGeometry(.5,.012,.5),'#f6f0dc',tiles,'finish-tiles');
 return {root,treatMesh,resetTreats,collectTreat,updateTunnelView(s,distance){for(const update of tunnelViews)update(s,distance)}};
}
function boneGeometry(){
 const items=[new T.BoxGeometry(.30,.12,.14)];
 for(const x of [-.15,.15])for(const z of [-.07,.07]){const g=new T.SphereGeometry(.095,8,6);g.translate(x,0,z);items.push(g)}
 const pos=[],norm=[];for(const g of items){const n=g.index?g.toNonIndexed():g;pos.push(...n.attributes.position.array);norm.push(...n.attributes.normal.array);n.dispose();g.dispose()}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(norm,3));return g;
}
````

### `dist/review/v22/tunnel.js`

````javascript
import * as T from '../../assets/three.module.js';

// One open-ended fabric arch under the hoops, also used by the course miniature.
export function addTunnel(parent, mesh, radius = 1.58, length = 6) {
  const fabric = new T.CylinderGeometry(radius, radius, length, 32, 1, true, Math.PI / 2, Math.PI);
  fabric.rotateX(Math.PI / 2);
  const wall = mesh(fabric, '#5686aa', 0, 0, 0, parent);
  wall.material.side = T.DoubleSide;
  wall.name = 'tunnel-fabric';
  const intervals = 8;
  for (let i = 0; i <= intervals; i++) {
    const end = i === 0 || i === intervals;
    const rib = mesh(new T.TorusGeometry(radius, radius * (end ? .068 : .032), 8, 32, Math.PI),
      end ? '#91b7c3' : '#729cba', 0, 0, length * (i / intervals - .5), parent);
    rib.name = end ? 'tunnel-rim' : 'tunnel-rib';
  }
}

// A tall fabric arch for the park. The low side panels mark the lane while the
// crown fades out whenever it would stand between the rear camera and the dog.
export function addParkTunnel(parent, mesh, distanceAlongCourse) {
  const radius=1.54, length=6, sideAngle=.20, crown=[];
  const tunnel=new T.Group();
  tunnel.name='park-tunnel';tunnel.scale.y=1.48;parent.add(tunnel);
  for(const [start,sweep,isCrown] of [
    [0,sideAngle,false],[sideAngle,Math.PI-2*sideAngle,true],[Math.PI-sideAngle,sideAngle,false]
  ]){
    const segments=isCrown?28:3;
    const sections=isCrown?6:1;
    for(let i=0;i<sections;i++){
      const z=length*((i+.5)/sections-.5);
      const shell=new T.CylinderGeometry(radius,radius,length/sections,segments,1,true,Math.PI/2+start,sweep);
      shell.rotateX(Math.PI/2);
      const wall=mesh(shell,'#53899c',0,0,z,tunnel);
      wall.material.side=T.DoubleSide;wall.name=isCrown?'park-tunnel-canopy':'park-tunnel-side';
      if(isCrown)crown.push(wall);
    }
    for(let i=0;i<=6;i++){
      const end=i===0||i===6, hoop=new T.TorusGeometry(radius,end?.071:.038,6,segments,sweep);
      hoop.rotateZ(start);
      const rib=mesh(hoop,end?'#83acac':'#749fa9',0,0,length*(i/6-.5),tunnel);
      rib.name=isCrown?'park-tunnel-upper-rib':'park-tunnel-side-rib';
      if(isCrown)crown.push(rib);
    }
  }
  return (runnerDistance,cameraDistance)=>{
    // The far arch stays visible ahead. Restore each strip only once the camera clears it.
    for(const part of crown){
      const past=runnerDistance-distanceAlongCourse+part.position.z;
      const approach=1-T.MathUtils.smoothstep(past,-3.8,-1.65);
      const leaving=T.MathUtils.smoothstep(past,cameraDistance+1.3,cameraDistance+4);
      const alpha=Math.max(approach,leaving);
      if(alpha===part.material.opacity)continue;
      part.visible=alpha>0;
      part.material.opacity=alpha;
      part.material.depthWrite=alpha===1;
      const blended=alpha<1;
      if(part.material.transparent!==blended){part.material.transparent=blended;part.material.needsUpdate=true}
    }
  };
}
````

### `dist/review/v24.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-game.js":"./v24/race-game.js","../race-sim.js":"./v26/race-sim.js","../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v24/park-camera.js`

````javascript
import {MathUtils} from '../../assets/three.module.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {routePoint} from '../../race-route.js';
import {RACE} from '../../race-sim.js';

// Remember the lane the dog actually took. A swipe just beyond the exit must
// not drag the trailing camera sideways through the tunnel wall.
export function makeParkCamera(obstacles) {
  const gates = obstacles.filter(o => o.type === 'tunnel');
  const trail = [];
  function lateralAt(s) {
    const i = trail.findIndex(sample => sample.s >= s);
    if (i < 0) return trail.at(-1).x;
    if (i === 0) return trail[0].x;
    const a = trail[i - 1], b = trail[i];
    return MathUtils.lerp(a.x, b.x, (s - a.s) / (b.s - a.s));
  }
  return (runner, normalDistance, normalHeight) => {
    const {s, x} = runner;
    if (trail.length && s < trail.at(-1).s) trail.length = 0;
    if (!trail.length || s - trail.at(-1).s >= .10) trail.push({s, x});
    while (trail.length > 2 && trail[1].s < s - 10) trail.shift();
    const anchor = routePoint(s, x);
    const gate = gates.find(o => s > o.s - 22 && s < o.s + 24);
    if (!gate) return chaseCameraPose(anchor, {distance:normalDistance, height:normalHeight});
    const past = s - gate.s;
    const approach = MathUtils.smoothstep(past, -22, -7);
    const exit = 1 - MathUtils.smoothstep(past, 12, 24);
    const earlierX = lateralAt(s - normalDistance);
    const lane = gate.lane * RACE.lanewidth;
    const proximity = Math.min(Math.abs(x - lane), Math.abs(earlierX - lane));
    const through = approach * exit * (1 - MathUtils.smoothstep(proximity, .85, 1.85));
    const distance = MathUtils.lerp(normalDistance, 5.15, through);
    const height = MathUtils.lerp(normalHeight, 1.85, through);
    const pose = chaseCameraPose(anchor, {distance, height, lookHeight:MathUtils.lerp(1, 1.24, through)});
    if (through > 0) {
      const offset = (lateralAt(s - distance) - x) * through;
      const dx = Math.cos(anchor.heading) * offset, dz = Math.sin(anchor.heading) * offset;
      pose.position.x += dx;
      pose.position.z += dz;
      // Keep the dog centred as the camera follows through the previous lane.
      pose.target.x -= dx * 10 / distance;
      pose.target.z -= dz * 10 / distance;
    }
    return pose;
  };
}
````

### `dist/review/v24/race-game.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeShiba,poseShiba} from '../../shiba.js';
import {makeDog} from '../../dog-model.js';
import {footingFor,poseLegs} from '../../dog-gait.js';
import {breeds} from '../../breeds.js';
import {RACE,RaceSimulation,gestureAction} from '../../race-sim.js';
import {routePoint,cornerAt} from '../../race-route.js';
import {AgilitySimulation,AGILITY} from '../../agility-sim.js';
import {courses,nextPlayableCourse} from '../../courses.js';
import {biscuitIcon} from '../../park-biscuit.js';
import {makeRaceTrack} from './race-track.js';
import {makeAgilityField} from '../../agility-field.js';
import {makeParkCamera} from './park-camera.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {helpContent} from '../../help-content.js';
import {A_FRAME,aFrameCameraLift} from '../../a-frame.js';
import {SEESAW} from '../../seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from '../../slalom.js';
import {finishRecord,formatTime as seconds} from '../../course-records.js';
const boneIcon='<svg viewBox="0 0 32 18" aria-hidden="true"><path d="M7 5C3-2-4 7 3 9c-7 2 0 11 4 4h18c4 7 11-2 4-4 7-2 0-11-4-4Z" fill="currentColor"/></svg>';
function faultText(event,sim){
 if(event.reason==='off-line')return sim.layout.obstacles.find(o=>o.id===event.id)?.type==='hoop'?'輪っかの横を通過':'ハードルの横を通過';
 if(event.reason==='slalom'){
  const firstMiss=sim.slaloms.get(event.id).passed.indexOf(false);
  return firstMiss>=0?`ポール${firstMiss+1}本目をミス`:'ポールの通過ミス';
 }
 const labels={'jump-low':'ジャンプが届かず','tunnel-entry':'トンネルの入口を外れた','tunnel-exit':'トンネルの出口を外れた',
  'board-entry':'シーソーに乗れず','board-stop':'停止位置を通過','ramp-entry':'坂の入口を外れた','ramp-jump':'坂の入口でジャンプ'};
 return labels[event.reason]??'ミス';
}
export function mountRace({container,breed,coat,onExit,onNextCourse,mode='race',courseId=mode==='agility'?'first-field':'park'}){
 const agility=mode==='agility',beach=mode==='race'&&courseId==='beach',forest=mode==='race'&&courseId==='forest',sim=agility?new AgilitySimulation(courseId):new RaceSimulation(courseId),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const park=courseId==='park';
 const parkCamera=park?makeParkCamera(sim.layout.obstacles):null;
 const treatIcon=park?biscuitIcon:boneIcon;
 const allowShortFlick=beach||courseId==='hill-field';
 const point=sim.layout.point||routePoint,length=sim.layout.length||RACE.length,obstacleCount=sim.layout.obstacles.length,courseName=courses.find(course=>course.id===courseId)?.name||(agility?'はじめての広場':'公園');
 let renderer,scene,camera,light,dogs=[],track,frameId,last=0,uiTime=0,disposed=false,pointer=null,messageTimer,helpReturn=null;
 let countdownLabel='',turnLabel='',cameraOffset=6;
 const rivals=agility?'':sim.cpus.map((_,i)=>`<i class="rival-marker" style="--row:${i}" aria-hidden="true"></i>`).join('');
 const playerMarker=agility?'':'<i class="player-marker" aria-hidden="true"></i>';
 container.hidden=false;container.dataset.mode=mode;container.dataset.course=courseId;container.className='race-root';container.setAttribute('aria-label',courseName);
 container.innerHTML=`<canvas id="raceCanvas" tabindex="0" aria-label="${agility?'アジリティ。左右スワイプで移動、上でジャンプ、下で停止、タップで再開。':courseName+'レース。左右スワイプで移動と右左折、上でジャンプ、下でブレーキ、ゲージ満タン時にタップでダッシュ。'}"></canvas>
 <div class="race-hud"><div class="race-top"><div class="race-rank"><strong id="raceRank">${agility?'0':'1'}</strong><span>${agility?`/ ${obstacleCount} クリア`:`位 / ${sim.cpus.length+1}匹`}</span></div><div class="race-treats">${agility?'<span class="fault-label">ミス</span>':treatIcon}<span id="raceTreats">0</span></div><button id="pauseRace" aria-label="一時停止">Ⅱ</button></div><div class="race-progress" role="progressbar" aria-label="コースの進み具合" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="raceProgressFill"></div>${rivals}${playerMarker}</div><div class="race-course-label"><span>${courseName}</span><span id="raceClock">00:00.0</span></div></div>
 <div id="raceTurnCue" class="race-turn-cue" role="status" hidden></div><div id="raceCount" class="race-count" aria-live="polite"></div><div id="raceFeedback" class="race-feedback" role="status"></div>
 ${agility?`<div class="agility-bottom"><div class="agility-steps" aria-label="障害物の結果">${sim.layout.obstacles.map((o,i)=>`<span data-step="${o.id}" aria-label="障害物${i+1} 未通過">${i+1}</span>`).join('')}</div><div id="agilityStopped" class="agility-stopped" role="status" hidden>停止中 <span>タップで再開</span></div></div>`:`<div class="race-bottom"><div class="race-gauge-label"><span>${treatIcon}<b id="raceDashHint">ダッシュ</b></span><strong id="raceGaugeCount">0 / 20</strong></div><div id="raceGauge" class="race-gauge" role="meter" aria-label="ダッシュゲージ" aria-valuemin="0" aria-valuemax="20" aria-valuenow="0"><div id="raceGaugeFill"></div></div></div>`}
 <div id="raceOverlay" class="race-overlay" role="dialog" aria-modal="true" aria-label="ゲームのメニュー"></div>`;
 const canvas=container.querySelector('#raceCanvas'),overlay=container.querySelector('#raceOverlay'),q=id=>container.querySelector('#'+id);
 const rivalMarkers=container.querySelectorAll('.rival-marker'),playerPin=container.querySelector('.player-marker');
 function setup(){
  renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const skyColor=forest?'#c1cfb0':beach?'#b5dce4':agility?'#bad7e3':'#9ed9ee';
  scene=new T.Scene();scene.background=new T.Color(skyColor);scene.fog=new T.Fog(skyColor,park?32:agility||beach?85:42,park?107:agility||beach?175:110);camera=new T.PerspectiveCamera(60,1,.1,180);
  scene.add(new T.HemisphereLight('#fff8e8','#8d9f75',2.5));light=new T.DirectionalLight('#fff0d7',2.7);light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:45});light.shadow.bias=-.0003;light.shadow.normalBias=.03;scene.add(light,light.target);
  if(park){
   renderer.toneMappingExposure=1.04;
   const dome=new T.Mesh(new T.SphereGeometry(134,24,12),new T.ShaderMaterial({
    side:T.BackSide,depthWrite:false,
    vertexShader:'varying float altitude; void main(){altitude=position.y/134.;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying float altitude; void main(){vec3 sky=mix(vec3(.73,.91,.89),vec3(.26,.67,.88),smoothstep(-.035,.34,altitude));gl_FragColor=vec4(sky,1.);}'
   }));
   dome.name='park-sky';dome.renderOrder=-10;scene.add(dome);
  }
  track=agility?makeAgilityField(sim.layout):makeRaceTrack(sim.layout);scene.add(track.root);
  const roster=agility?[breed]:[breed,...breeds.filter(b=>b.id!==breed.id).slice(0,sim.cpus.length)];
  dogs=roster.map((b,i)=>{const fur=i===0?coat:park?({corgi:2,poodle:1,dachshund:1}[b.id]??0):0;const dog=park&&b.id==='shiba'?makeShiba(fur):makeDog(b,fur);dog.scale.setScalar(park&&b.id==='shiba'?.86:.76);dog.rotation.y=Math.PI;dog.traverse(o=>{if(o.isMesh)o.castShadow=i===0});scene.add(dog);const shadow=new T.Mesh(new T.CircleGeometry(.8,24),new T.MeshStandardMaterial({color:'#536848',transparent:true,opacity:.15}));shadow.rotation.x=-Math.PI/2;scene.add(shadow);return {dog,shadow}});
  camera.position.set(0,2.8,6);resize();
 }
 function resize(){if(!renderer)return;const r=container.getBoundingClientRect();if(r.width<1||r.height<1)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.fov=r.width>r.height?54:60;camera.updateProjectionMatrix()}
 function message(text){clearTimeout(messageTimer);q('raceFeedback').textContent=text;messageTimer=setTimeout(()=>q('raceFeedback')&&(q('raceFeedback').textContent=''),1300)}
 function ready(){
  helpReturn=null;q('pauseRace').hidden=true;overlay.hidden=false;
  overlay.innerHTML=`<div class="race-modal race-ready"><span class="race-overline">${agility?'アジリティ':'レース'}</span><h2>${courseName}</h2><div class="start-summary"><span>${breed.name}</span><span>${agility?`${obstacleCount}つの障害物`:`${sim.cpus.length+1}匹で競走`}</span></div><button id="startRun" class="primary">走る <span>→</span></button><div class="race-menu-links"><button id="readyHelp" class="race-secondary">遊び方</button><button id="readyExit" class="race-secondary">コース選択</button></div></div>`;
  q('startRun').onclick=begin;q('readyExit').onclick=onExit;q('readyHelp').onclick=()=>showHelp(ready);q('startRun').focus({preventScroll:true});
 }
 function showHelp(returnTo){
  helpReturn=returnTo;overlay.hidden=false;overlay.innerHTML=`<div class="race-modal game-help"><div class="help-heading"><h2>遊び方</h2><button id="closeGameHelp" class="close" aria-label="遊び方を閉じる">×</button></div>${helpContent(mode,'game',courseId)}</div>`;
  q('closeGameHelp').onclick=closeHelp;q('closeGameHelp').focus({preventScroll:true});
 }
 function closeHelp(){const back=helpReturn;helpReturn=null;back?.()}
 function begin(){pointer=null;helpReturn=null;overlay.hidden=true;q('pauseRace').hidden=false;sim.start();updateHUD();canvas.focus({preventScroll:true})}
 function pause(){
  if(window.parkReview)return;
  pointer=null;sim.pause();if(sim.status!=='paused')return;helpReturn=null;overlay.hidden=false;
  overlay.innerHTML='<div class="race-modal"><h2>一時停止</h2><button id="resumeRun" class="primary">続ける <span>→</span></button><button id="restartRun" class="race-secondary">最初から</button><div class="race-menu-links"><button id="pauseHelp" class="race-secondary">遊び方</button><button id="pauseExit" class="race-secondary">コース選択</button></div></div>';
  q('resumeRun').onclick=()=>{overlay.hidden=true;sim.resume();last=performance.now();updateHUD();canvas.focus({preventScroll:true})};q('restartRun').onclick=restart;q('pauseExit').onclick=onExit;q('pauseHelp').onclick=()=>showHelp(pause);q('resumeRun').focus({preventScroll:true});updateHUD();
 }
 function restart(){sim.reset();track.resetTreats();camera.position.set(0,2.8,6);cameraOffset=6;last=performance.now();q('raceFeedback').textContent='';begin()}
 function result(){
  const r=sim.result,record=finishRecord(courseId,agility?r.total:r.time);
  const recordLabel=record.temporary?'今回のベスト':'自己ベスト';
  const recordRow=`<div class="result-record" data-record-state="${record.state}">
   <span class="record-pair">${recordLabel} <strong>${seconds(record.best)}</strong></span>
   <span class="record-delta">${record.label}</span></div>`;
  q('pauseRace').hidden=true;overlay.hidden=false;
  const stats=agility?`<div><span>走行タイム</span><strong>${seconds(r.time)}</strong></div><div><span>ペナルティ</span><strong>+${r.penalty}秒</strong></div><div><span>クリア</span><strong>${r.cleared} / ${obstacleCount}</strong></div><div><span>ミス</span><strong>${r.faults}回</strong></div>`:`<div><span>タイム</span><strong>${seconds(r.time)}</strong></div><div><span>おやつ</span><strong>${r.treats}個</strong></div><div><span>ダッシュ</span><strong>${r.dashes}回</strong></div><div><span>障害物のミス</span><strong>${r.hits}回</strong></div>`;
  const next=onNextCourse&&nextPlayableCourse(mode,courseId);
  const nextButton=next?`<button id="nextCourseRun" class="primary result-next" aria-label="次のコース「${next.name}」へ">${next.shortName}へ <span aria-hidden="true">→</span></button>`:'';
  overlay.innerHTML=`<div class="race-modal race-result"><span class="race-overline">${courseName}</span>${agility?`<div class="result-score">${r.total.toFixed(2)}<span>秒</span></div>`:`<div class="result-rank">${r.rank}<span>位 / ${sim.cpus.length+1}匹</span></div>`}<h2>${agility?(r.faults===0?'ノーミスで完走！':'完走！'):(r.rank===1?'いちばんでゴール！':'完走！')}</h2><div class="race-stats">${stats}</div>${agility?'':`<p class="race-turn-result">曲がり損ね ${r.turnMisses}回</p>`}${recordRow}<div class="result-actions"><button id="retryRun" class="primary">もう一度 <span aria-hidden="true">↻</span></button>${nextButton}</div><button id="resultExit" class="race-secondary">コース選択</button></div>`;
  if(next)q('nextCourseRun').onclick=()=>{if(!disposed)onNextCourse(next.id)};
  q('retryRun').onclick=restart;q('resultExit').onclick=onExit;q('retryRun').focus({preventScroll:true});
 }
 function updateHUD(){
  q('raceRank').textContent=agility?sim.cleared:sim.rank;q('raceTreats').textContent=agility?sim.faults:sim.treatCount;
  const progress=Math.min(100,sim.player.s/length*100);q('raceProgressFill').style.width=progress+'%';container.querySelector('.race-progress').setAttribute('aria-valuenow',Math.round(progress));q('raceClock').textContent=`${String(Math.floor(sim.time/60)).padStart(2,'0')}:${(sim.time%60).toFixed(1).padStart(4,'0')}`;
  if(agility){
   track?.update(sim);
   for(const o of sim.layout.obstacles){const el=container.querySelector(`[data-step="${o.id}"]`),done=sim.results.has(o.id),clear=sim.results.get(o.id);el.dataset.state=done?(clear?'clear':'miss'):'pending';el.textContent=done?(clear?'✓':'−'):o.id+1;el.setAttribute('aria-label',`障害物${o.id+1} ${done?(clear?'クリア':'ミス'):'未通過'}`)}
   q('agilityStopped').hidden=!(sim.stopped&&sim.status==='running'&&!sim.activeSeesaw);updateObstacleCue();
  }else{
   playerPin.style.left=progress+'%';
   sim.cpus.forEach((dog,i)=>{rivalMarkers[i].style.left=Math.max(0,Math.min(100,dog.s/length*100))+'%'});
   const boost=sim.player.boost>0,ready=sim.gauge===RACE.gaugeMax&&!boost;
   q('raceGaugeCount').textContent=boost?`${sim.player.boost.toFixed(1)}秒`:`${sim.gauge} / 20`;
   q('raceGaugeFill').style.width=sim.gauge/RACE.gaugeMax*100+'%';q('raceGauge').setAttribute('aria-valuenow',sim.gauge);
   container.classList.toggle('dash-ready',ready);container.classList.toggle('boosting',boost);q('raceDashHint').textContent=boost?'ダッシュ中':ready?'タップでダッシュ':'ダッシュ';updateTurnCue();
  }
  const label=sim.status==='countdown'?String(Math.ceil(sim.countdown)):'';if(label!==countdownLabel){countdownLabel=label;q('raceCount').textContent=label}
 }
 function updateTurnCue(){
  const cue=sim.status==='running'?sim.turnCue:null,el=q('raceTurnCue');el.hidden=!cue;container.classList.toggle('turn-visible',!!cue);if(!cue){turnLabel='';return}
  const right=cue.direction==='right',direction=right?'右':'左';
  const state=cue.waiting?'waiting':cue.armed?'armed':cue.active?'active':'ahead';
  const label=cue.waiting?`${direction}へスワイプ`:cue.armed?(sim.player.s>=cue.start?`${direction}カーブ`:`${direction}折 OK`):cue.active?`${direction}へスワイプ`:`この先 ${direction}カーブ`;
  const key=`${cue.id}:${state}:${label}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=state;
  el.innerHTML=`<strong aria-hidden="true">${right?'↱':'↰'}</strong><span><small>${cue.id+1} / ${sim.layout.turns.length}</small><b>${label}</b></span>${cue.armed?'<span class="turn-check" aria-hidden="true">✓</span>':''}`;
 }
 function updateObstacleCue(){
  const o=sim.status==='running'?sim.nextObstacle:null,el=q('raceTurnCue');el.hidden=!o;container.classList.toggle('turn-visible',!!o);if(!o){turnLabel='';return}
  const names={'a-frame':'Aフレーム',hurdle:'ハードル',hoop:'輪っか',tunnel:'トンネル',seesaw:'シーソー',slalom:'スラローム'},lane=o.lane<0?'左':o.lane>0?'右':'中央';
  const aligned=Math.abs(sim.player.x-o.lane*2)<(o.type==='seesaw'?.48:o.type==='a-frame'?A_FRAME.entryTolerance:.72),near=(o.type==='slalom'?slalomPoleS(o,0):o.type==='a-frame'?o.s-A_FRAME.run:o.s)-sim.player.s<8,board=sim.activeSeesaw,slalom=sim.activeSlalom;
  let icon=!aligned?(o.lane*2<sim.player.x?'←':'→'):o.type==='tunnel'?'∩':['seesaw','slalom','a-frame'].includes(o.type)?'◇':near?'↑':'◇',label=names[o.type],detail=`${o.id+1} / ${obstacleCount} · ${lane}`;
  if(o.type==='a-frame'){
   if(sim.rampPass){icon='◇';label=sim.rampPass.onBoard?'坂を駆け抜けよう':'坂の横を通過中'}
   else if(near&&aligned){icon='◇';label='黄色い入口へ'}
  }
  if(board){const phase=board.state.phase;label=phase==='hold'||phase==='tipping'?'板が下がるまで待つ':phase==='ready'?'タップで再開':sim.stopped?'タップで再開':phase==='exit'?'そのまま進もう':sim.player.s-o.s>=SEESAW.stopFrom?'下スワイプで停止':'中央へ進もう';icon=phase==='hold'||phase==='tipping'?'…':phase==='ready'||sim.stopped?'●':phase==='exit'?'✓':sim.player.s-o.s>=SEESAW.stopFrom?'↓':'◇'}
  if(slalom){const index=slalom.state.index,done=index>=SLALOM.count,right=slalomSide(o,index)>0;icon=done?'✓':right?'→':'←';label=done?'出口へ':right?'右を通る':'左を通る';detail=`${o.id+1} / ${obstacleCount} · ポール ${Math.min(index+1,SLALOM.count)} / ${SLALOM.count}`}
  const key=`${o.id}:${icon}:${label}:${detail}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=near?'active':'ahead';
  el.innerHTML=`<strong aria-hidden="true">${icon}</strong><span><small>${detail}</small><b>${label}</b></span>`;
 }
 function frame(t){
  if(disposed)return;
  const dt=window.parkReview?.stepSeconds??(last?Math.max(0,Math.min(.2,(t-last)/1000)):0);last=t;
  // Keep ordinary slow frames on the game clock without skipping whole obstacles.
  const steps=Math.max(1,Math.ceil(dt/.05));
  for(let step=0;step<steps;step++)sim.step(dt/steps);
  track.animate?.(sim);
  for(const e of sim.drainEvents()){
   if(e.type==='treat')track.collectTreat(e.id);if(e.type==='hit')message('減速');if(e.type==='dash')message('ダッシュ！');if(e.type==='go')message('スタート！');
   if(e.type==='turn-wrong')message(e.direction==='right'?'右へ':'左へ');if(e.type==='turn-missed')message('ストップ');
   if(e.type==='obstacle-clear')message('クリア！');if(e.type==='obstacle-miss')message(`${faultText(e,sim)}　+${AGILITY.penalty}秒`);if(e.type==='finish')result();
   if(e.type==='seesaw-recover')message('止まり損ね');
  }
  const footing=footingFor(sim,agility);
  [sim.player,...sim.cpus].forEach((a,i)=>{
   if(sim.status==='paused')return;
   const {dog,shadow}=dogs[i],held=i===0&&(agility?sim.stopped:sim.waitingTurn!==null),run=sim.status==='running'&&a.finishTime===null&&!held,p=point(a.s,a.x),corner=agility?null:cornerAt(a.s,0,0,sim.layout.turns);
   dog.position.set(p.x,a.y+(run&&!reduced&&!a.surfaceY?Math.abs(Math.cos(a.phase*1.85))*.025:0),p.z);dog.rotation.order='YXZ';dog.rotation.x=a.pitch||0;dog.rotation.y=Math.PI-p.heading;
   dog.rotation.z=run&&!reduced?((agility?sim.targetX:a.lane*RACE.lanewidth)-a.x)*.07+(corner?(corner.direction==='right'?.08:-.08):0):0;
   poseLegs(dog,a.phase,run,a.jumpElapsed!==null,footing);
   if(dog.userData.expression)poseShiba(dog,t/1000,run,reduced);else dog.userData.tail.rotation.y=reduced?0:Math.sin(t*.006+i)*.15;shadow.position.set(p.x,.035,p.z);shadow.scale.setScalar(a.jumpElapsed!==null?.7:1);shadow.visible=!a.surfaceY;
  });
  const p=sim.player,nearTunnel=!park&&sim.layout.obstacles.some(o=>o.type==='tunnel'&&o.s-p.s<9&&o.s-p.s>-6&&Math.abs(p.x-o.lane*RACE.lanewidth)<.8);
  const surface=p.surfaceY||0,onRamp=sim.rampPass?.onBoard;
  const lift=onRamp?aFrameCameraLift(surface):surface;
  const height=surface?2.8+lift:camera.position.y+((nearTunnel?1.15:2.8+(reduced?0:p.y*.18))-camera.position.y)*(1-Math.exp(-dt*6));
  const follow=park?Math.min(8.65,Math.max(6,3.58/camera.aspect)):6;
  cameraOffset+=((nearTunnel?4:follow)-cameraOffset)*(1-Math.exp(-dt*5));
  const anchor=point(p.s,p.x),pose=park?parkCamera(p,cameraOffset,2.8+(reduced?0:p.y*.18)):chaseCameraPose(anchor,{distance:cameraOffset,height,lookHeight:nearTunnel?.65:1+lift*(onRamp ? .65 : 1)});
  camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);
  if(park){
   scene.getObjectByName('park-sky').position.copy(camera.position);
  }
  light.position.set(anchor.x-7,12,anchor.z+6);light.target.position.set(anchor.x,0,anchor.z);
  uiTime+=dt;
  if(uiTime>.08||sim.status==='countdown'){updateHUD();uiTime=0}
  else if(beach&&sim.status==='running')updateTurnCue();
  if(!window.parkReview?.skipDraw)renderer.render(scene,camera);frameId=requestAnimationFrame(frame);
 }
 function pointerDown(e){
  if(!e.isPrimary||sim.status!=='running'||pointer)return;
  pointer={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),used:false,tapEligible:true};
  canvas.setPointerCapture(e.pointerId);
 }
 function readPointer(e,isRelease){
  if(!pointer||pointer.id!==e.pointerId||pointer.used)return;
  const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
  if(Math.hypot(dx,dy)>=12)pointer.tapEligible=false;
  const action=gestureAction(dx,dy,performance.now()-pointer.time,allowShortFlick);
  if(!action||(action==='dash'&&(!isRelease||!pointer.tapEligible)))return;
  pointer.used=true;
  sim.input(action);
 }
 function pointerMove(e){readPointer(e,false)}
 function cancelPointer(e){if(pointer?.id===e.pointerId)pointer=null}
 function pointerUp(e){readPointer(e,true);cancelPointer(e)}
 function key(e){if(e.target?.tagName==='BUTTON')return;const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',ArrowDown:'brake',' ':'dash'};if(e.key==='Escape'){e.preventDefault();pause()}else if(map[e.key]){e.preventDefault();if(!e.repeat)sim.input(map[e.key])}}
 function visibility(){if(document.hidden)pause()}
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'&&helpReturn){e.preventDefault();closeHelp();return}if(e.key!=='Tab'||overlay.hidden)return;const buttons=[...overlay.querySelectorAll('button')],first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',cancelPointer);canvas.addEventListener('lostpointercapture',cancelPointer);canvas.addEventListener('keydown',key);q('pauseRace').onclick=pause;document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',pause);window.addEventListener('resize',resize);
 const observer=new ResizeObserver(resize);observer.observe(container);
 try{setup();ready();frameId=requestAnimationFrame(frame)}catch(e){console.error('Race rendering unavailable',e);overlay.hidden=false;overlay.innerHTML='<div class="race-modal"><h2>3D表示を開始できませんでした</h2><button id="errorExit" class="primary">コース選択</button></div>';q('errorExit').onclick=onExit;q('pauseRace').hidden=true;q('errorExit').focus({preventScroll:true})}
 return {mode,courseId,pause,dispose(){disposed=true;cancelAnimationFrame(frameId);clearTimeout(messageTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',pause);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());light?.dispose();renderer?.dispose();renderer?.forceContextLoss();container.innerHTML='';container.hidden=true}};
}
````

### `dist/review/v24/race-track.js`

````javascript
import * as T from '../../assets/three.module.js';
import {dressPark,parkLog} from '../../park-art.js';
import {parkBiscuitGeometry} from '../../park-biscuit.js';
import {addTunnel,addParkTunnel} from './tunnel.js';
import {routePoint as parkPoint} from '../../race-route.js';
import {addForestScenery,addForestLog} from '../../forest-scene.js';
import {addBeachScenery,addDriftwood} from '../../beach-scene.js';
import {RACE} from '../../race-sim.js';
const mat=color=>new T.MeshStandardMaterial({color,roughness:1});

// One continuous ribbon keeps every lane connected through the 90-degree bends.
export function roadRibbon(lateral,width,y,from=-15,to=510,point=parkPoint){
 const vertices=[],indices=[],steps=Math.ceil(to-from);
 for(let i=0;i<=steps;i++){
  const s=from+(to-from)*i/steps;
  for(const side of [-1,1]){const p=point(s,lateral+side*width/2);vertices.push(p.x,y,p.z)}
  if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2)}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function makeRaceTrack(layout){
 const root=new T.Group();root.name=(layout.theme||'park')+'-race-track';const routePoint=layout.point||parkPoint,length=layout.length||RACE.length,end=length+30,field=layout.theme==='field';
 function mesh(geo,color,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,mat(color));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,c,x,y,z,parent=root){return mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent)}
 function groupAt(s,lateral=0){const p=routePoint(s,lateral),g=new T.Group();g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);return g}
 function pose(s,lateral,y,sx=1,sy=1,sz=1){const p=routePoint(s,lateral);return [p.x,y,p.z,sx,sy,sz,-p.heading]}
 function instances(geo,color,poses,name){const m=new T.InstancedMesh(geo,mat(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p[0],p[1],p[2]);dummy.scale.set(p[3]??1,p[4]??1,p[5]??1);dummy.rotation.set(0,p[6]??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 if(layout.theme==='beach'){
  addBeachScenery(layout,{mesh,box,pose,instances,groupAt,ribbon:roadRibbon});
 }else if(layout.theme==='forest'){
  addForestScenery(layout,{mesh,box,pose,instances,ribbon:roadRibbon});
 }else if(layout.theme==='park'){
  dressPark({root,routePoint,end,ribbon:roadRibbon,mesh,box,groupAt,instances,pose});
 }else{
  box(800,.12,800,'#9fb681',50,-.12,-200);
  mesh(roadRibbon(0,7.6,.015,-15,end,routePoint),field?'#b4c49a':'#cfbc95').name='continuous-road';
  for(const x of [-3.7,3.7])mesh(roadRibbon(x,.08,.025,-15,end,routePoint),'#e6d7b6');
  const lines=[];for(let s=-12;s<end;s+=5)for(const x of [-1,1])lines.push(pose(s,x,.025));
  instances(new T.BoxGeometry(.035,.015,1.5),'#e3d5b5',lines,'lane-markings');
  const trunks=[],crowns=[],caps=[],posts=[],rails=[];
  for(let s=-12;s<end;s+=4)for(const side of [-1,1])posts.push(pose(s,side*4.4,.6));
  for(let s=-12;s<end;s+=2)for(const side of [-1,1]){
   const a=routePoint(s,side*4.4),b=routePoint(s+2,side*4.4);
   rails.push([(a.x+b.x)/2,.75,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.04,-Math.atan2(b.x-a.x,a.z-b.z)]);
  }
  for(let s=-10;s<end;s+=11)for(const side of [-1,1]){
   const lateral=side*(7+(Math.abs(s)%4)*.6);
   trunks.push(pose(s,lateral,1));crowns.push(pose(s,lateral,2.5,1.3,1.5,1.3));caps.push(pose(s+.4,lateral+.45,3.2,1,1.2,1));
  }
  instances(new T.CylinderGeometry(.13,.17,2,7),'#8e7c54',trunks,'tree-trunks');
  instances(new T.SphereGeometry(1,10,7),'#79985f',crowns,'tree-crowns');
  instances(new T.SphereGeometry(1,10,7),'#8caa6a',caps,'tree-caps');
  instances(new T.BoxGeometry(.10,1.2,.10),'#d7c6a2',posts,'fence-posts');
  instances(new T.BoxGeometry(.07,.12,1),'#d7c6a2',rails,'fence-rails');
 }
 for(const t of layout.turns){
  for(const lead of [23,6]){
   const side=t.direction==='right'?-1:1,g=groupAt(t.start-lead,side*4.7);g.name='turn-sign';g.userData.turnId=t.id;
   box(.12,2.2,.12,'#778566',0,1.1,0,g);box(2.5,1.2,.12,'#315b49',0,2.2,0,g);
   const shape=new T.Shape();[[-.8,.14],[.12,.14],[.12,.43],[.8,0],[.12,-.43],[.12,-.14],[-.8,-.14]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
   const arrow=mesh(new T.ShapeGeometry(shape),'#f5df9f',0,2.2,.071,g);arrow.material.side=T.DoubleSide;if(t.direction==='left')arrow.scale.x=-1;
  }
 }
 for(const o of layout.obstacles){
  const g=groupAt(o.s,o.lane*RACE.lanewidth);g.name='race-obstacle';g.userData.obstacleId=o.id;
  if(o.type==='log'){
   if(layout.theme==='forest')addForestLog(g,mesh);else addDriftwood(g,mesh);
  }else if(o.type==='hurdle'&&layout.theme==='park'&&o.id%4===0){
   parkLog(g,mesh);
  }else if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.10,1.1,.12,'#72929b',x,.55,0,g);box(.42,.08,.6,'#72929b',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.20,.11,.10,j%2?'#c78465':'#f6edda',-.70+j*.20,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#d6b35a',0,1.7,0,g);
   for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#72929b',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#72929b',x,.04,0,g)}
  }else{
   if(layout.theme==='park')addParkTunnel(g,mesh);
   else addTunnel(g,mesh);
   box(.12,.10,6,'#6a97a2',-1.58,.05,0,g);box(.12,.10,6,'#6a97a2',1.58,.05,0,g);
  }
 }
 const park=layout.theme==='park';
 const biscuit=park?parkBiscuitGeometry():boneGeometry();
 const biscuitMaterial=park?new T.MeshStandardMaterial({vertexColors:true,roughness:.93}):mat('#dca644');
 const treatMesh=new T.InstancedMesh(biscuit,biscuitMaterial,layout.treats.length);treatMesh.name='treat-trail';treatMesh.visible=layout.treats.length>0;root.add(treatMesh);
 function resetTreats(){const dummy=new T.Object3D();for(const t of layout.treats){const p=routePoint(t.s,t.lane*RACE.lanewidth);dummy.position.set(p.x,t.y,p.z);dummy.rotation.set(0,-p.heading,0);dummy.updateMatrix();treatMesh.setMatrixAt(t.id,dummy.matrix)}treatMesh.instanceMatrix.needsUpdate=true;if(layout.treats.length)treatMesh.computeBoundingSphere()}
 function collectTreat(id){treatMesh.setMatrixAt(id,new T.Matrix4().makeScale(0,0,0));treatMesh.instanceMatrix.needsUpdate=true}
 resetTreats();
 const finish=groupAt(length);finish.name='finish-gate';
 for(const x of [-3.6,3.6])box(.18,4,.18,'#607e6c',x,2,0,finish);
 for(let j=0;j<16;j++)for(let row=0;row<2;row++)box(.45,.35,.06,(j+row)%2?'#f6efda':'#486f59',-3.375+j*.45,3.3+row*.35,0,finish);
 const tiles=[];for(let j=0;j<16;j++)for(let k=0;k<2;k++)if((j+k)%2===0)tiles.push(pose(length-k*.5,-3.75+j*.5,.03));
 instances(new T.BoxGeometry(.5,.012,.5),'#f6f0dc',tiles,'finish-tiles');
 return {root,treatMesh,resetTreats,collectTreat};
}
function boneGeometry(){
 const items=[new T.BoxGeometry(.30,.12,.14)];
 for(const x of [-.15,.15])for(const z of [-.07,.07]){const g=new T.SphereGeometry(.095,8,6);g.translate(x,0,z);items.push(g)}
 const pos=[],norm=[];for(const g of items){const n=g.index?g.toNonIndexed():g;pos.push(...n.attributes.position.array);norm.push(...n.attributes.normal.array);n.dispose();g.dispose()}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(norm,3));return g;
}
````

### `dist/review/v24/tunnel.js`

````javascript
import * as T from '../../assets/three.module.js';

// One open-ended fabric arch under the hoops, also used by the course miniature.
export function addTunnel(parent, mesh, radius = 1.58, length = 6) {
  const fabric = new T.CylinderGeometry(radius, radius, length, 32, 1, true, Math.PI / 2, Math.PI);
  fabric.rotateX(Math.PI / 2);
  const wall = mesh(fabric, '#5686aa', 0, 0, 0, parent);
  wall.material.side = T.DoubleSide;
  wall.name = 'tunnel-fabric';
  const intervals = 8;
  for (let i = 0; i <= intervals; i++) {
    const end = i === 0 || i === intervals;
    const rib = mesh(new T.TorusGeometry(radius, radius * (end ? .068 : .032), 8, 32, Math.PI),
      end ? '#91b7c3' : '#729cba', 0, 0, length * (i / intervals - .5), parent);
    rib.name = end ? 'tunnel-rim' : 'tunnel-rib';
  }
}

// A continuous canvas sleeve, with short open-sided hoods beyond the marked lane.
export function addParkTunnel(parent, mesh) {
  const rings = [-6, -4.5, -3, -1.5, 0, 1.5, 3, 4.5, 6];
  const subdivisions = 32;
  const section = (z, step) => {
    const hood = Math.max(0, (Math.abs(z) - 3) / 3);
    const hem = .84 * T.MathUtils.smoothstep(Math.abs(z), 1.8, 4.5);
    const angle = hem + (Math.PI - 2 * hem) * step / subdivisions;
    return new T.Vector3((1.52 + hood * .15) * Math.cos(angle),
      3.35 * Math.sin(angle), z);
  };
  for (let bay = 0; bay < rings.length - 1; bay++) {
    const vertices = [], indices = [];
    for (const z of [rings[bay], rings[bay + 1]]) {
      for (let k = 0; k <= subdivisions; k++) vertices.push(...section(z, k).toArray());
    }
    for (let k = 0; k < subdivisions; k++) {
      const j = k + subdivisions + 1;
      indices.push(k, k + 1, j, k + 1, j + 1, j);
    }
    const fabric = new T.BufferGeometry();
    fabric.setAttribute('position', new T.Float32BufferAttribute(vertices, 3));
    fabric.setIndex(indices);
    fabric.computeVertexNormals();
    const panel = mesh(fabric, bay % 2 ? '#75a6ad' : '#83b3b5', 0, 0, 0, parent);
    panel.name = 'park-tunnel-fabric';
    panel.material.side = T.DoubleSide;
  }
  for (const z of rings) {
    const end = Math.abs(z) === 6;
    const points = Array.from({length: subdivisions + 1}, (_, k) => section(z, k));
    const hoop = new T.TubeGeometry(new T.CatmullRomCurve3(points), subdivisions,
      end ? .085 : .045, 8, false);
    mesh(hoop, end ? '#e5cea1' : '#adcac4', 0, 0, 0, parent).name = 'park-tunnel-rib';
  }
}
````

