# 第10章　開発用比較画面と旧実装（3）

### `dist/review/v25.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-game.js":"./v26/race-game.js","../park-camera.js":"./v25/park-camera.js","../race-sim.js":"./v26/race-sim.js","../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v25/park-camera.js`

````javascript
import {MathUtils} from '../../assets/three.module.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {routePoint} from '../../race-route.js';
import {RACE} from '../../race-sim.js';

// Remember the lane the dog actually took. A swipe just beyond the exit must
// not drag the trailing camera sideways through the tunnel wall.
export function makeParkCamera(obstacles) {
  const gates = obstacles.filter(o => o.type === 'tunnel');
  const trail = [];
  function lateralAt(s) {
    const i = trail.findIndex(sample => sample.s >= s);
    if (i < 0) return trail.at(-1).x;
    if (i === 0) return trail[0].x;
    const a = trail[i - 1], b = trail[i];
    return MathUtils.lerp(a.x, b.x, (s - a.s) / (b.s - a.s));
  }
  return (runner, normalDistance, normalHeight) => {
    const {s, x} = runner;
    if (trail.length && s < trail.at(-1).s) trail.length = 0;
    if (!trail.length || s - trail.at(-1).s >= .10) trail.push({s, x});
    while (trail.length > 2 && trail[1].s < s - 10) trail.shift();
    const anchor = routePoint(s, x);
    const gate = gates.find(o => s > o.s - 22 && s < o.s + 24);
    if (!gate) return chaseCameraPose(anchor, {distance:normalDistance, height:normalHeight});
    const past = s - gate.s;
    const approach = MathUtils.smoothstep(past, -22, -7);
    const exit = 1 - MathUtils.smoothstep(past, 12, 24);
    const earlierX = lateralAt(s - normalDistance);
    const lane = gate.lane * RACE.lanewidth;
    const proximity = Math.min(Math.abs(x - lane), Math.abs(earlierX - lane));
    const through = approach * exit * (1 - MathUtils.smoothstep(proximity, .85, 1.85));
    const distance = MathUtils.lerp(normalDistance, 4.85, through);
    const height = MathUtils.lerp(normalHeight, 1.26, through);
    const pose = chaseCameraPose(anchor, {distance, height, lookHeight:MathUtils.lerp(1, .77, through)});
    if (through > 0) {
      const offset = (lateralAt(s - distance) - x) * through;
      const dx = Math.cos(anchor.heading) * offset, dz = Math.sin(anchor.heading) * offset;
      pose.position.x += dx;
      pose.position.z += dz;
      // Keep the dog centred as the camera follows through the previous lane.
      pose.target.x -= dx * 10 / distance;
      pose.target.z -= dz * 10 / distance;
    }
    return pose;
  };
}
````

### `dist/review/v26.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"><style>.race-overlay{z-index:auto}</style></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-sim.js":"./v26/race-sim.js","../race-game.js":"./v26/race-game.js","../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v26/race-game.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeShiba,poseShiba} from '../../shiba.js';
import {makeDog} from '../../dog-model.js';
import {footingFor,poseLegs} from '../../dog-gait.js';
import {breeds} from '../../breeds.js';
import {RACE,RaceSimulation,gestureAction} from '../../race-sim.js';
import {routePoint,cornerAt} from '../../race-route.js';
import {AgilitySimulation,AGILITY} from '../../agility-sim.js';
import {courses,nextPlayableCourse} from '../../courses.js';
import {biscuitIcon} from '../../park-biscuit.js';
import {makeRaceTrack} from '../../race-track.js';
import {makeAgilityField} from '../../agility-field.js';
import {makeParkCamera} from '../../park-camera.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {helpContent} from '../../help-content.js';
import {A_FRAME,aFrameCameraLift} from '../../a-frame.js';
import {SEESAW} from '../../seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from '../../slalom.js';
import {finishRecord,formatTime as seconds} from '../../course-records.js';
const boneIcon='<svg viewBox="0 0 32 18" aria-hidden="true"><path d="M7 5C3-2-4 7 3 9c-7 2 0 11 4 4h18c4 7 11-2 4-4 7-2 0-11-4-4Z" fill="currentColor"/></svg>';
function faultText(event,sim){
 if(event.reason==='off-line')return sim.layout.obstacles.find(o=>o.id===event.id)?.type==='hoop'?'輪っかの横を通過':'ハードルの横を通過';
 if(event.reason==='slalom'){
  const firstMiss=sim.slaloms.get(event.id).passed.indexOf(false);
  return firstMiss>=0?`ポール${firstMiss+1}本目をミス`:'ポールの通過ミス';
 }
 const labels={'jump-low':'ジャンプが届かず','tunnel-entry':'トンネルの入口を外れた','tunnel-exit':'トンネルの出口を外れた',
  'board-entry':'シーソーに乗れず','board-stop':'停止位置を通過','ramp-entry':'坂の入口を外れた','ramp-jump':'坂の入口でジャンプ'};
 return labels[event.reason]??'ミス';
}
export function mountRace({container,breed,coat,onExit,onNextCourse,mode='race',courseId=mode==='agility'?'first-field':'park'}){
 const agility=mode==='agility',beach=mode==='race'&&courseId==='beach',forest=mode==='race'&&courseId==='forest',sim=agility?new AgilitySimulation(courseId):new RaceSimulation(courseId),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const park=courseId==='park';
 const parkCamera=park?makeParkCamera(sim.layout.obstacles):null;
 const treatIcon=park?biscuitIcon:boneIcon;
 const allowShortFlick=beach||courseId==='hill-field';
 const point=sim.layout.point||routePoint,length=sim.layout.length||RACE.length,obstacleCount=sim.layout.obstacles.length,courseName=courses.find(course=>course.id===courseId)?.name||(agility?'はじめての広場':'公園');
 let renderer,scene,camera,light,dogs=[],track,frameId,last=0,uiTime=0,disposed=false,pointer=null,messageTimer,helpReturn=null;
 let countdownLabel='',turnLabel='',cameraOffset=6;
 const rivals=agility?'':sim.cpus.map((_,i)=>`<i class="rival-marker" style="--row:${i}" aria-hidden="true"></i>`).join('');
 const playerMarker=agility?'':'<i class="player-marker" aria-hidden="true"></i>';
 container.hidden=false;container.dataset.mode=mode;container.dataset.course=courseId;container.className='race-root';container.setAttribute('aria-label',courseName);
 container.innerHTML=`<canvas id="raceCanvas" tabindex="0" aria-label="${agility?'アジリティ。左右スワイプで移動、上でジャンプ、下で停止、タップで再開。':courseName+'レース。左右スワイプで移動と右左折、上でジャンプ、下でブレーキ、ゲージ満タン時にタップでダッシュ。'}"></canvas>
 <div class="race-hud"><div class="race-top"><div class="race-rank"><strong id="raceRank">${agility?'0':'1'}</strong><span>${agility?`/ ${obstacleCount} クリア`:`位 / ${sim.cpus.length+1}匹`}</span></div><div class="race-treats">${agility?'<span class="fault-label">ミス</span>':treatIcon}<span id="raceTreats">0</span></div><button id="pauseRace" aria-label="一時停止">Ⅱ</button></div><div class="race-progress" role="progressbar" aria-label="コースの進み具合" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="raceProgressFill"></div>${rivals}${playerMarker}</div><div class="race-course-label"><span>${courseName}</span><span id="raceClock">00:00.0</span></div></div>
 <div id="raceTurnCue" class="race-turn-cue" role="status" hidden></div><div id="raceCount" class="race-count" aria-live="polite"></div><div id="raceFeedback" class="race-feedback" role="status"></div>
 ${agility?`<div class="agility-bottom"><div class="agility-steps" aria-label="障害物の結果">${sim.layout.obstacles.map((o,i)=>`<span data-step="${o.id}" aria-label="障害物${i+1} 未通過">${i+1}</span>`).join('')}</div><div id="agilityStopped" class="agility-stopped" role="status" hidden>停止中 <span>タップで再開</span></div></div>`:`<div class="race-bottom"><div class="race-gauge-label"><span>${treatIcon}<b id="raceDashHint">ダッシュ</b></span><strong id="raceGaugeCount">0 / 20</strong></div><div id="raceGauge" class="race-gauge" role="meter" aria-label="ダッシュゲージ" aria-valuemin="0" aria-valuemax="20" aria-valuenow="0"><div id="raceGaugeFill"></div></div></div>`}
 <div id="raceOverlay" class="race-overlay" role="dialog" aria-modal="true" aria-label="ゲームのメニュー"></div>`;
 const canvas=container.querySelector('#raceCanvas'),overlay=container.querySelector('#raceOverlay'),q=id=>container.querySelector('#'+id);
 const rivalMarkers=container.querySelectorAll('.rival-marker'),playerPin=container.querySelector('.player-marker');
 function setup(){
  renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const skyColor=forest?'#c1cfb0':beach?'#b5dce4':agility?'#bad7e3':'#9ed9ee';
  scene=new T.Scene();scene.background=new T.Color(skyColor);scene.fog=new T.Fog(skyColor,park?32:agility||beach?85:42,park?107:agility||beach?175:110);camera=new T.PerspectiveCamera(60,1,.1,180);
  scene.add(new T.HemisphereLight('#fff8e8','#8d9f75',2.5));light=new T.DirectionalLight('#fff0d7',2.7);light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:45});light.shadow.bias=-.0003;light.shadow.normalBias=.03;scene.add(light,light.target);
  if(park){
   renderer.toneMappingExposure=1.04;
   const dome=new T.Mesh(new T.SphereGeometry(134,24,12),new T.ShaderMaterial({
    side:T.BackSide,depthWrite:false,
    vertexShader:'varying float altitude; void main(){altitude=position.y/134.;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying float altitude; void main(){vec3 sky=mix(vec3(.73,.91,.89),vec3(.26,.67,.88),smoothstep(-.035,.34,altitude));gl_FragColor=vec4(sky,1.);}'
   }));
   dome.name='park-sky';dome.renderOrder=-10;scene.add(dome);
  }
  track=agility?makeAgilityField(sim.layout):makeRaceTrack(sim.layout);scene.add(track.root);
  const roster=agility?[breed]:[breed,...breeds.filter(b=>b.id!==breed.id).slice(0,sim.cpus.length)];
  dogs=roster.map((b,i)=>{
   const fur=i===0?coat:park?({corgi:2,poodle:1,dachshund:1}[b.id]??0):0;
   const parkShiba=park&&b.id==='shiba';
   const dog=parkShiba?makeShiba(fur):makeDog(b,fur);
   dog.scale.setScalar(park?(parkShiba?.63:.62):.76);
   dog.rotation.y=Math.PI;
   dog.traverse(o=>{if(o.isMesh)o.castShadow=i===0});
   const shadowRadius=park?(parkShiba?.52:.55):.8;
   const shadow=new T.Mesh(new T.CircleGeometry(shadowRadius,24),
    new T.MeshStandardMaterial({color:'#536848',transparent:true,opacity:.15}));
   shadow.rotation.x=-Math.PI/2;
   scene.add(dog,shadow);
   return {dog,shadow};
  });
  camera.position.set(0,2.8,6);resize();
 }
 function resize(){if(!renderer)return;const r=container.getBoundingClientRect();if(r.width<1||r.height<1)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.fov=r.width>r.height?54:60;camera.updateProjectionMatrix()}
 function message(text){clearTimeout(messageTimer);q('raceFeedback').textContent=text;messageTimer=setTimeout(()=>q('raceFeedback')&&(q('raceFeedback').textContent=''),1300)}
 function ready(){
  helpReturn=null;q('pauseRace').hidden=true;overlay.hidden=false;
  overlay.innerHTML=`<div class="race-modal race-ready"><span class="race-overline">${agility?'アジリティ':'レース'}</span><h2>${courseName}</h2><div class="start-summary"><span>${breed.name}</span><span>${agility?`${obstacleCount}つの障害物`:`${sim.cpus.length+1}匹で競走`}</span></div><button id="startRun" class="primary">走る <span>→</span></button><div class="race-menu-links"><button id="readyHelp" class="race-secondary">遊び方</button><button id="readyExit" class="race-secondary">コース選択</button></div></div>`;
  q('startRun').onclick=begin;q('readyExit').onclick=onExit;q('readyHelp').onclick=()=>showHelp(ready);q('startRun').focus({preventScroll:true});
 }
 function showHelp(returnTo){
  helpReturn=returnTo;overlay.hidden=false;overlay.innerHTML=`<div class="race-modal game-help"><div class="help-heading"><h2>遊び方</h2><button id="closeGameHelp" class="close" aria-label="遊び方を閉じる">×</button></div>${helpContent(mode,'game',courseId)}</div>`;
  q('closeGameHelp').onclick=closeHelp;q('closeGameHelp').focus({preventScroll:true});
 }
 function closeHelp(){const back=helpReturn;helpReturn=null;back?.()}
 function begin(){pointer=null;helpReturn=null;overlay.hidden=true;q('pauseRace').hidden=false;sim.start();updateHUD();canvas.focus({preventScroll:true})}
 function pause(){
  if(window.parkReview && !window.parkReview.showPause)return;
  pointer=null;sim.pause();if(sim.status!=='paused')return;helpReturn=null;overlay.hidden=false;
  overlay.innerHTML='<div class="race-modal"><h2>一時停止</h2><button id="resumeRun" class="primary">続ける <span>→</span></button><button id="restartRun" class="race-secondary">最初から</button><div class="race-menu-links"><button id="pauseHelp" class="race-secondary">遊び方</button><button id="pauseExit" class="race-secondary">コース選択</button></div></div>';
  q('resumeRun').onclick=()=>{overlay.hidden=true;sim.resume();last=performance.now();updateHUD();canvas.focus({preventScroll:true})};q('restartRun').onclick=restart;q('pauseExit').onclick=onExit;q('pauseHelp').onclick=()=>showHelp(pause);q('resumeRun').focus({preventScroll:true});updateHUD();
 }
 function restart(){sim.reset();track.resetTreats();camera.position.set(0,2.8,6);cameraOffset=6;last=performance.now();q('raceFeedback').textContent='';begin()}
 function result(){
  const r=sim.result,record=finishRecord(courseId,agility?r.total:r.time);
  const recordLabel=record.temporary?'今回のベスト':'自己ベスト';
  const recordRow=`<div class="result-record" data-record-state="${record.state}">
   <span class="record-pair">${recordLabel} <strong>${seconds(record.best)}</strong></span>
   <span class="record-delta">${record.label}</span></div>`;
  q('pauseRace').hidden=true;overlay.hidden=false;
  const stats=agility?`<div><span>走行タイム</span><strong>${seconds(r.time)}</strong></div><div><span>ペナルティ</span><strong>+${r.penalty}秒</strong></div><div><span>クリア</span><strong>${r.cleared} / ${obstacleCount}</strong></div><div><span>ミス</span><strong>${r.faults}回</strong></div>`:`<div><span>タイム</span><strong>${seconds(r.time)}</strong></div><div><span>おやつ</span><strong>${r.treats}個</strong></div><div><span>ダッシュ</span><strong>${r.dashes}回</strong></div><div><span>障害物のミス</span><strong>${r.hits}回</strong></div>`;
  const next=onNextCourse&&nextPlayableCourse(mode,courseId);
  const nextButton=next?`<button id="nextCourseRun" class="primary result-next" aria-label="次のコース「${next.name}」へ">${next.shortName}へ <span aria-hidden="true">→</span></button>`:'';
  overlay.innerHTML=`<div class="race-modal race-result"><span class="race-overline">${courseName}</span>${agility?`<div class="result-score">${r.total.toFixed(2)}<span>秒</span></div>`:`<div class="result-rank">${r.rank}<span>位 / ${sim.cpus.length+1}匹</span></div>`}<h2>${agility?(r.faults===0?'ノーミスで完走！':'完走！'):(r.rank===1?'いちばんでゴール！':'完走！')}</h2><div class="race-stats">${stats}</div>${agility?'':`<p class="race-turn-result">曲がり損ね ${r.turnMisses}回</p>`}${recordRow}<div class="result-actions"><button id="retryRun" class="primary">もう一度 <span aria-hidden="true">↻</span></button>${nextButton}</div><button id="resultExit" class="race-secondary">コース選択</button></div>`;
  if(next)q('nextCourseRun').onclick=()=>{if(!disposed)onNextCourse(next.id)};
  q('retryRun').onclick=restart;q('resultExit').onclick=onExit;q('retryRun').focus({preventScroll:true});
 }
 function updateHUD(){
  q('raceRank').textContent=agility?sim.cleared:sim.rank;q('raceTreats').textContent=agility?sim.faults:sim.treatCount;
  const progress=Math.min(100,sim.player.s/length*100);q('raceProgressFill').style.width=progress+'%';container.querySelector('.race-progress').setAttribute('aria-valuenow',Math.round(progress));q('raceClock').textContent=`${String(Math.floor(sim.time/60)).padStart(2,'0')}:${(sim.time%60).toFixed(1).padStart(4,'0')}`;
  if(agility){
   track?.update(sim);
   for(const o of sim.layout.obstacles){const el=container.querySelector(`[data-step="${o.id}"]`),done=sim.results.has(o.id),clear=sim.results.get(o.id);el.dataset.state=done?(clear?'clear':'miss'):'pending';el.textContent=done?(clear?'✓':'−'):o.id+1;el.setAttribute('aria-label',`障害物${o.id+1} ${done?(clear?'クリア':'ミス'):'未通過'}`)}
   q('agilityStopped').hidden=!(sim.stopped&&sim.status==='running'&&!sim.activeSeesaw);updateObstacleCue();
  }else{
   playerPin.style.left=progress+'%';
   sim.cpus.forEach((dog,i)=>{rivalMarkers[i].style.left=Math.max(0,Math.min(100,dog.s/length*100))+'%'});
   const boost=sim.player.boost>0,ready=sim.gauge===RACE.gaugeMax&&!boost;
   q('raceGaugeCount').textContent=boost?`${sim.player.boost.toFixed(1)}秒`:`${sim.gauge} / 20`;
   q('raceGaugeFill').style.width=sim.gauge/RACE.gaugeMax*100+'%';q('raceGauge').setAttribute('aria-valuenow',sim.gauge);
   container.classList.toggle('dash-ready',ready);container.classList.toggle('boosting',boost);q('raceDashHint').textContent=boost?'ダッシュ中':ready?'タップでダッシュ':'ダッシュ';updateTurnCue();
  }
  const label=sim.status==='countdown'?String(Math.ceil(sim.countdown)):'';if(label!==countdownLabel){countdownLabel=label;q('raceCount').textContent=label}
 }
 function updateTurnCue(){
  const cue=sim.status==='running'?sim.turnCue:null,el=q('raceTurnCue');el.hidden=!cue;container.classList.toggle('turn-visible',!!cue);if(!cue){turnLabel='';return}
  const right=cue.direction==='right',direction=right?'右':'左';
  const state=cue.waiting?'waiting':cue.armed?'armed':cue.active?'active':'ahead';
  const label=cue.waiting?`${direction}へスワイプ`:cue.armed?(sim.player.s>=cue.start?`${direction}カーブ`:`${direction}折 OK`):cue.active?`${direction}へスワイプ`:`この先 ${direction}カーブ`;
  const key=`${cue.id}:${state}:${label}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=state;
  el.innerHTML=`<strong aria-hidden="true">${right?'↱':'↰'}</strong><span><small>${cue.id+1} / ${sim.layout.turns.length}</small><b>${label}</b></span>${cue.armed?'<span class="turn-check" aria-hidden="true">✓</span>':''}`;
 }
 function updateObstacleCue(){
  const o=sim.status==='running'?sim.nextObstacle:null,el=q('raceTurnCue');el.hidden=!o;container.classList.toggle('turn-visible',!!o);if(!o){turnLabel='';return}
  const names={'a-frame':'Aフレーム',hurdle:'ハードル',hoop:'輪っか',tunnel:'トンネル',seesaw:'シーソー',slalom:'スラローム'},lane=o.lane<0?'左':o.lane>0?'右':'中央';
  const aligned=Math.abs(sim.player.x-o.lane*2)<(o.type==='seesaw'?.48:o.type==='a-frame'?A_FRAME.entryTolerance:.72),near=(o.type==='slalom'?slalomPoleS(o,0):o.type==='a-frame'?o.s-A_FRAME.run:o.s)-sim.player.s<8,board=sim.activeSeesaw,slalom=sim.activeSlalom;
  let icon=!aligned?(o.lane*2<sim.player.x?'←':'→'):o.type==='tunnel'?'∩':['seesaw','slalom','a-frame'].includes(o.type)?'◇':near?'↑':'◇',label=names[o.type],detail=`${o.id+1} / ${obstacleCount} · ${lane}`;
  if(o.type==='a-frame'){
   if(sim.rampPass){icon='◇';label=sim.rampPass.onBoard?'坂を駆け抜けよう':'坂の横を通過中'}
   else if(near&&aligned){icon='◇';label='黄色い入口へ'}
  }
  if(board){const phase=board.state.phase;label=phase==='hold'||phase==='tipping'?'板が下がるまで待つ':phase==='ready'?'タップで再開':sim.stopped?'タップで再開':phase==='exit'?'そのまま進もう':sim.player.s-o.s>=SEESAW.stopFrom?'下スワイプで停止':'中央へ進もう';icon=phase==='hold'||phase==='tipping'?'…':phase==='ready'||sim.stopped?'●':phase==='exit'?'✓':sim.player.s-o.s>=SEESAW.stopFrom?'↓':'◇'}
  if(slalom){const index=slalom.state.index,done=index>=SLALOM.count,right=slalomSide(o,index)>0;icon=done?'✓':right?'→':'←';label=done?'出口へ':right?'右を通る':'左を通る';detail=`${o.id+1} / ${obstacleCount} · ポール ${Math.min(index+1,SLALOM.count)} / ${SLALOM.count}`}
  const key=`${o.id}:${icon}:${label}:${detail}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=near?'active':'ahead';
  el.innerHTML=`<strong aria-hidden="true">${icon}</strong><span><small>${detail}</small><b>${label}</b></span>`;
 }
 function frame(t){
  if(disposed)return;
  const dt=window.parkReview?.stepSeconds??(last?Math.max(0,Math.min(.2,(t-last)/1000)):0);last=t;
  // Keep ordinary slow frames on the game clock without skipping whole obstacles.
  const steps=Math.max(1,Math.ceil(dt/.05));
  for(let step=0;step<steps;step++)sim.step(dt/steps);
  track.animate?.(sim);
  for(const e of sim.drainEvents()){
   if(e.type==='treat')track.collectTreat(e.id);if(e.type==='hit')message('減速');if(e.type==='dash')message('ダッシュ！');if(e.type==='go')message('スタート！');
   if(e.type==='turn-wrong')message(e.direction==='right'?'右へ':'左へ');if(e.type==='turn-missed')message('ストップ');
   if(e.type==='obstacle-clear')message('クリア！');if(e.type==='obstacle-miss')message(`${faultText(e,sim)}　+${AGILITY.penalty}秒`);if(e.type==='finish')result();
   if(e.type==='seesaw-recover')message('止まり損ね');
  }
  const footing=footingFor(sim,agility);
  [sim.player,...sim.cpus].forEach((a,i)=>{
   if(sim.status==='paused')return;
   const {dog,shadow}=dogs[i],held=i===0&&(agility?sim.stopped:sim.waitingTurn!==null),run=sim.status==='running'&&a.finishTime===null&&!held,p=point(a.s,a.x),corner=agility?null:cornerAt(a.s,0,0,sim.layout.turns);
   dog.position.set(p.x,a.y+(run&&!reduced&&!a.surfaceY?Math.abs(Math.cos(a.phase*1.85))*.025:0),p.z);dog.rotation.order='YXZ';dog.rotation.x=a.pitch||0;dog.rotation.y=Math.PI-p.heading;
   dog.rotation.z=run&&!reduced?((agility?sim.targetX:a.lane*RACE.lanewidth)-a.x)*.07+(corner?(corner.direction==='right'?.08:-.08):0):0;
   poseLegs(dog,a.phase,run,a.jumpElapsed!==null,footing);
   if(dog.userData.expression)poseShiba(dog,t/1000,run,reduced);else dog.userData.tail.rotation.y=reduced?0:Math.sin(t*.006+i)*.15;shadow.position.set(p.x,.035,p.z);shadow.scale.setScalar(a.jumpElapsed!==null?.7:1);shadow.visible=!a.surfaceY;
  });
  const p=sim.player,nearTunnel=!park&&sim.layout.obstacles.some(o=>o.type==='tunnel'&&o.s-p.s<9&&o.s-p.s>-6&&Math.abs(p.x-o.lane*RACE.lanewidth)<.8);
  const surface=p.surfaceY||0,onRamp=sim.rampPass?.onBoard;
  const lift=onRamp?aFrameCameraLift(surface):surface;
  const height=surface?2.8+lift:camera.position.y+((nearTunnel?1.15:2.8+(reduced?0:p.y*.18))-camera.position.y)*(1-Math.exp(-dt*6));
  const follow=park?Math.min(8.65,Math.max(6,3.58/camera.aspect)):6;
  cameraOffset+=((nearTunnel?4:follow)-cameraOffset)*(1-Math.exp(-dt*5));
  const anchor=point(p.s,p.x),pose=park?parkCamera(p,cameraOffset,2.8+(reduced?0:p.y*.18)):chaseCameraPose(anchor,{distance:cameraOffset,height,lookHeight:nearTunnel?.65:1+lift*(onRamp ? .65 : 1)});
  camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);
  if(park){
   const zoom=pose.zoom??1;
   if(Math.abs(camera.zoom-zoom)>.00001){camera.zoom=zoom;camera.updateProjectionMatrix()}
   scene.getObjectByName('park-sky').position.copy(camera.position);
  }
  light.position.set(anchor.x-7,12,anchor.z+6);light.target.position.set(anchor.x,0,anchor.z);
  uiTime+=dt;
  if(uiTime>.08||sim.status==='countdown'){updateHUD();uiTime=0}
  else if(beach&&sim.status==='running')updateTurnCue();
  if(!window.parkReview?.skipDraw)renderer.render(scene,camera);frameId=requestAnimationFrame(frame);
 }
 function pointerDown(e){
  if(!e.isPrimary||sim.status!=='running'||pointer)return;
  pointer={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),used:false,tapEligible:true};
  canvas.setPointerCapture(e.pointerId);
 }
 function readPointer(e,isRelease){
  if(!pointer||pointer.id!==e.pointerId||pointer.used)return;
  const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
  if(Math.hypot(dx,dy)>=12)pointer.tapEligible=false;
  const action=gestureAction(dx,dy,performance.now()-pointer.time,allowShortFlick);
  if(!action||(action==='dash'&&(!isRelease||!pointer.tapEligible)))return;
  pointer.used=true;
  sim.input(action);
 }
 function pointerMove(e){readPointer(e,false)}
 function cancelPointer(e){if(pointer?.id===e.pointerId)pointer=null}
 function pointerUp(e){readPointer(e,true);cancelPointer(e)}
 function key(e){if(e.target?.tagName==='BUTTON')return;const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',ArrowDown:'brake',' ':'dash'};if(e.key==='Escape'){e.preventDefault();pause()}else if(map[e.key]){e.preventDefault();if(!e.repeat)sim.input(map[e.key])}}
 function visibility(){if(document.hidden)pause()}
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'&&helpReturn){e.preventDefault();closeHelp();return}if(e.key!=='Tab'||overlay.hidden)return;const buttons=[...overlay.querySelectorAll('button')],first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',cancelPointer);canvas.addEventListener('lostpointercapture',cancelPointer);canvas.addEventListener('keydown',key);q('pauseRace').onclick=pause;document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',pause);window.addEventListener('resize',resize);
 const observer=new ResizeObserver(resize);observer.observe(container);
 try{setup();ready();frameId=requestAnimationFrame(frame)}catch(e){console.error('Race rendering unavailable',e);overlay.hidden=false;overlay.innerHTML='<div class="race-modal"><h2>3D表示を開始できませんでした</h2><button id="errorExit" class="primary">コース選択</button></div>';q('errorExit').onclick=onExit;q('pauseRace').hidden=true;q('errorExit').focus({preventScroll:true})}
 return {mode,courseId,pause,dispose(){disposed=true;cancelAnimationFrame(frameId);clearTimeout(messageTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',pause);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());light?.dispose();renderer?.dispose();renderer?.forceContextLoss();container.innerHTML='';container.hidden=true}};
}
````

### `dist/review/v26/race-sim.js`

````javascript
import {PARK_TURNS,TURN_NOTICE,TURN_WINDOW,cornerAt} from '../../race-route.js';
import {buildForestRace} from '../../forest-layout.js';
import {buildBeachRace,touchesSoftSand} from '../../beach-layout.js';
export const RACE = {length:480,lanewidth:2,speed:9.6,jumpDuration:.94,jumpHeight:1.55,gaugeMax:20,boostDuration:3,boostSpeed:16.2};
export const lanePosition=(x,target,seconds)=>target+(x-target)*Math.exp(-13*seconds);
export const jumpHeight=elapsed=>elapsed===null||elapsed>=RACE.jumpDuration?0:
 Math.sin(elapsed/RACE.jumpDuration*Math.PI)*RACE.jumpHeight;

// Sample the runner at the gate, using the same motion as the full frame.
export function crossingAt(gate,start,end){
 if(gate<=start.s||gate>end)return null;
 const time=start.dt*(gate-start.s)/(end-start.s);
 const jump=start.jump===null?null:start.jump+time;
 return {x:lanePosition(start.x,start.target,time),y:jumpHeight(jump),grounded:jump===null||jump>=RACE.jumpDuration};
}
export function buildParkRace(){
 const obstacles=Array.from({length:15},(_,i)=>({id:i,s:36+i*28,lane:[0,-1,1,0,1,-1,0,1,0,-1,1,0,-1,1,0][i],type:i%4===2?'tunnel':'hurdle'}))
  .filter(o=>!cornerAt(o.s,TURN_WINDOW+6,9));
 const treats=[];
 for(let s=8;s<465;s+=2.2){
  let lane=[0,0,-1,0,1,0][Math.floor((s-8)/17)%6],y=.65;
  if(cornerAt(s,TURN_WINDOW,4))lane=0;
  const nearby=obstacles.find(o=>Math.abs(o.s-s)<4.5);
  if(nearby){lane=nearby.lane;if(nearby.type==='hurdle')y=.65+1.25*Math.sin(Math.PI*(s-nearby.s+4.5)/9)}
  treats.push({id:treats.length,s,lane,y});
 }
 return {theme:'park',length:RACE.length,obstacles,treats,turns:PARK_TURNS};
}
const actor=(id,lane,s,speed)=>({id,lane,x:lane*RACE.lanewidth,s,speed,y:0,jumpElapsed:null,slow:0,brake:0,boost:0,finishTime:null,hits:0,phase:0});
export class RaceSimulation{
 constructor(courseId='park'){const createLayout={park:buildParkRace,beach:buildBeachRace,forest:buildForestRace}[courseId]??buildParkRace;this.layout=createLayout();this.reset()}
 reset(){
  this.status='ready';this.previousStatus=null;this.countdown=3;this.time=0;
  this.player=actor('player',0,0,RACE.speed);
  this.cpus=[actor('cpu0',-1,0,9.7),actor('cpu1',1,0,10.0),actor('cpu2',0,-3.3,10.25),actor('cpu3',-1,-4.4,9.9)];
  // Park is introductory. Beach rewards its outer trails; the middle forest
  // rival spends treats earned on the bends, leaving the log arcs to overtake.
  const dashRivals=this.layout.theme==='beach'?this.cpus.slice(0,2):
   this.layout.theme==='forest'?[this.cpus[2],this.cpus[1]]:[];
  for(const rival of dashRivals){rival.nextTreat=0;rival.gauge=0}
  this.gauge=0;this.treatCount=0;this.dashCount=0;this.collected=new Set();this.events=[];this.result=null;
  this.armedTurns=new Set();this.passedTurns=new Set();this.missedTurns=new Set();this.waitingTurn=null;
 }
 start(){if(this.status==='ready')this.status='countdown'}
 pause(){if(['countdown','running'].includes(this.status)){this.previousStatus=this.status;this.status='paused'}}
 resume(){if(this.status==='paused'){this.status=this.previousStatus;this.previousStatus=null}}
 inTunnel(a){return this.layout.obstacles.find(o=>o.type==='tunnel'&&Math.abs(a.s-o.s)<3.4&&Math.abs(a.x-o.lane*RACE.lanewidth)<.8)}
 get turnCue(){
  const t=cornerAt(this.player.s,TURN_NOTICE,0,this.layout.turns);if(!t)return null;
  return {...t,distance:Math.max(0,t.start-this.player.s),active:this.player.s>=t.start-TURN_WINDOW,armed:this.armedTurns.has(t.id),waiting:this.waitingTurn===t.id};
 }
 input(action){
  if(this.status!=='running')return false;const p=this.player;
  if(action==='left'||action==='right'){
   const cue=this.turnCue;
   if(cue?.active){
    if(cue.armed)return false;
    if(action!==cue.direction){this.events.push({type:'turn-wrong',direction:cue.direction});return false}
    this.armedTurns.add(cue.id);this.waitingTurn=null;p.lane=0;
    this.events.push({type:'turn-armed',direction:cue.direction});return true;
   }
  }
  if(this.waitingTurn!==null)return false;
  if(action==='dash'){if(this.gauge<RACE.gaugeMax||p.boost>0)return false;this.gauge=0;p.boost=RACE.boostDuration;this.dashCount++;this.events.push({type:'dash'});return true}
  if(action==='brake'){p.brake=.6;return true}
  if(this.inTunnel(p))return false;
  if(action==='left'||action==='right'){p.lane=Math.max(-1,Math.min(1,p.lane+(action==='left'?-1:1)));return true}
  if(action==='jump'&&p.jumpElapsed===null){p.jumpElapsed=0;return true}return false;
 }
 collectRivalTreats(rival,motion){
  // The trail is sorted. Each rival can pick up each treat once on its own pass.
  const treats=this.layout.treats;
  while(rival.nextTreat<treats.length && treats[rival.nextTreat].s<=rival.s){
   const treat=treats[rival.nextTreat++];
   const pass=crossingAt(treat.s,motion,rival.s);
   if(pass&&Math.abs(pass.x-treat.lane*RACE.lanewidth)<.72 && Math.abs(pass.y+.65-treat.y)<.8){
    rival.gauge=Math.min(RACE.gaugeMax,rival.gauge+1);
   }
  }
  if(rival.gauge===RACE.gaugeMax && rival.boost===0){
   rival.gauge=0;rival.boost=RACE.boostDuration;
  }
 }
 get rank(){if(this.result)return this.result.rank;return 1+this.cpus.filter(a=>a.finishTime!==null||a.s>this.player.s+.02).length}
 step(dt){
  if(!Number.isFinite(dt)||dt<=0||dt>.1)return;
  if(this.status==='countdown'){this.countdown=Math.max(0,this.countdown-dt);if(this.countdown===0){this.status='running';this.events.push({type:'go'})}return}
  if(this.status!=='running')return;
  const timeBefore=this.time;this.time+=dt;
  for(let i=0;i<this.cpus.length;i++){
   const a=this.cpus[i];if(a.finishTime!==null)continue;
   a.lane=cornerAt(a.s,TURN_WINDOW,0,this.layout.turns)?0:[-1,1,0,-1][i];
   const next=this.layout.obstacles.find(o=>o.s>a.s&&o.s-a.s<4.3&&Math.abs(a.x-o.lane*RACE.lanewidth)<.65);
   if((next?.type==='hurdle'||next?.type==='log')&&a.jumpElapsed===null&&((next.id+i*3)%7!==0))a.jumpElapsed=0;
  }
  for(const a of [this.player,...this.cpus]){
   if(a.finishTime!==null)continue;const previousS=a.s;
   const motion={s:previousS,x:a.x,target:a.lane*RACE.lanewidth,jump:a.jumpElapsed,dt};
   a.slow=Math.max(0,a.slow-dt);a.brake=Math.max(0,a.brake-dt);a.boost=Math.max(0,a.boost-dt);
   if(a.jumpElapsed!==null){a.jumpElapsed+=dt;if(a.jumpElapsed>=RACE.jumpDuration){a.jumpElapsed=null;a.y=0}else a.y=jumpHeight(a.jumpElapsed)}
   a.x=lanePosition(a.x,motion.target,dt);
   const held=a===this.player&&this.waitingTurn!==null;
   const inSoftSand=this.layout.sand&&a.y<.2&&touchesSoftSand(this.layout.sand,a.s,a.x);
   const speed=held?0:(inSoftSand?.8:1)*(a.boost>0?RACE.boostSpeed:a.speed)*(a.slow>0?.43:1)*(a.brake>0?.63:1);
   a.s+=speed*dt;
   if(a===this.player){
    // An unconfirmed corner stops forward motion. A direction swipe is required to enter it.
    const missed=this.layout.turns.find(t=>previousS<=t.start&&a.s>=t.start&&!this.armedTurns.has(t.id));
    if(missed){
     a.s=missed.start;this.waitingTurn=missed.id;
     if(!this.missedTurns.has(missed.id)){this.missedTurns.add(missed.id);this.events.push({type:'turn-missed',direction:missed.direction})}
    }
    for(const t of this.layout.turns)if(previousS<t.end&&a.s>=t.end&&!this.passedTurns.has(t.id)){
     this.passedTurns.add(t.id);this.events.push({type:'turn-done',direction:t.direction});
    }
   }
   a.phase+=a.s-previousS;
   for(const o of this.layout.obstacles){
    const pass=crossingAt(o.s,motion,a.s);
    if(!pass||Math.abs(pass.x-o.lane*RACE.lanewidth)>=(o.type==='log'?1.12:.72))continue;
    const hit=o.type==='tunnel'?pass.y>.55:pass.y<(o.type==='log'?.68:.74);
    if(hit){a.slow=1.15;a.hits++;if(o.type==='tunnel'){a.jumpElapsed=null;a.y=0}if(a===this.player)this.events.push({type:'hit'})}
   }
   if(a===this.player)for(const t of this.layout.treats)if(!this.collected.has(t.id)&&previousS<=t.s+.4&&a.s>=t.s-.4&&Math.abs(a.x-t.lane*RACE.lanewidth)<.72&&Math.abs((a.y+.65)-t.y)<.8){
    this.collected.add(t.id);this.treatCount++;const previousGauge=this.gauge;this.gauge=Math.min(RACE.gaugeMax,this.gauge+1);
    this.events.push({type:'treat',id:t.id});if(previousGauge<RACE.gaugeMax&&this.gauge===RACE.gaugeMax)this.events.push({type:'ready'});
   }
   if(a.nextTreat!==undefined)this.collectRivalTreats(a,motion);
   if(a.s>=this.layout.length){a.finishTime=timeBefore+dt*(this.layout.length-previousS)/(a.s-previousS);a.s=this.layout.length}
  }
  if(this.player.finishTime!==null){
   this.result={rank:1+this.cpus.filter(a=>a.finishTime!==null&&a.finishTime<this.player.finishTime).length,time:this.player.finishTime,treats:this.treatCount,dashes:this.dashCount,hits:this.player.hits,turns:this.passedTurns.size,turnMisses:this.missedTurns.size};
   this.time=this.player.finishTime;this.status='finished';this.events.push({type:'finish'});
  }
 }
 drainEvents(){const events=this.events;this.events=[];return events}
}
export function gestureAction(dx,dy,elapsed,allowShortFlick=false){
 const x=Math.abs(dx),y=Math.abs(dy),major=Math.max(x,y),minor=Math.min(x,y);
 const shortFlick=allowShortFlick&&elapsed<=210&&major>=20&&major>=minor*1.4;
 if(major>=28||shortFlick)return x>y?(dx<0?'left':'right'):(dy<0?'jump':'brake');
 if(Math.hypot(dx,dy)<12&&elapsed<350)return 'dash';
 return null;
}
````

### `dist/review/v28.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v28/companions.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeShiba,poseShiba} from './shiba.js';

// Dimensions are in the same units as the course. The paws are grounded by poseLegs.
const profiles = {
  corgi:      {hip:.47, length:.67, width:.37, face:.44, snout:.17, ear:'bat',   tail:'bob',    scarf:'#428478'},
  poodle:     {hip:.68, length:.48, width:.30, face:.35, snout:.17, ear:'puff',  tail:'pom',    scarf:'#9f4755'},
  dachshund:  {hip:.39, length:.81, width:.29, face:.32, snout:.28, ear:'silk',  tail:'whip',   scarf:'#527b96'},
  retriever:  {hip:.77, length:.70, width:.41, face:.42, snout:.22, ear:'fold',  tail:'feather',scarf:'#416c80'},
  collie:     {hip:.74, length:.64, width:.35, face:.36, snout:.23, ear:'tipped',tail:'brush',  scarf:'#b46f37'},
  pomeranian: {hip:.54, length:.47, width:.35, face:.36, snout:.13, ear:'fox',   tail:'plume',  scarf:'#657da1'},
  chihuahua:  {hip:.47, length:.39, width:.25, face:.33, snout:.11, ear:'fan',   tail:'sickle', scarf:'#ad6261'}
};

function makeTail(type,fur,accent) {
  const paths={
    bob:[[0,0,0],[.02,.05,-.07],[.035,.10,-.12]],
    pom:[[0,0,0],[.025,.17,-.11],[.08,.36,-.14]],
    whip:[[0,0,0],[0,.03,-.20],[.06,.14,-.42],[.13,.32,-.48]],
    feather:[[0,0,0],[.04,.01,-.25],[.16,.07,-.48],[.26,.21,-.65]],
    brush:[[0,0,0],[.02,-.09,-.26],[.13,-.07,-.52],[.27,.06,-.66]],
    plume:[[0,0,0],[-.08,.25,-.16],[-.05,.43,-.12],[.11,.50,.07],[.19,.42,.23]],
    sickle:[[0,0,0],[-.02,.19,-.13],[.05,.32,-.12],[.16,.35,-.02]]
  };
  const radius={bob:.149,pom:.057,whip:.068,feather:.14,brush:.15,plume:.185,sickle:.074}[type];
  const curve=new T.CatmullRomCurve3(paths[type].map(p=>new T.Vector3(...p)));
  const tube=new T.TubeGeometry(curve,24,1,12,false);
  const vertices=tube.attributes.position,normals=tube.attributes.normal,colors=[];
  for(let row=0;row<=24;row++){
    const u=row/24,center=curve.getPointAt(u),r=radius*(.65+.49*Math.sin(u*Math.PI))*(1-.99*T.MathUtils.smoothstep(u,.65,1));
    const color=fur.clone().lerp(accent,T.MathUtils.smoothstep(u,type==='brush'?.53:.68,.91));
    for(let j=0;j<=12;j++){
      const i=row*13+j;
      vertices.setXYZ(i,center.x+normals.getX(i)*r,center.y+normals.getY(i)*r,center.z+normals.getZ(i)*r);
      color.toArray(colors,i*3);
    }
  }
  tube.setAttribute('color',new T.Float32BufferAttribute(colors,3));tube.computeVertexNormals();
  const tail=new T.Group(),strand=new T.Mesh(tube,new T.MeshStandardMaterial({vertexColors:true,roughness:.92}));
  strand.castShadow=true;tail.add(strand);return tail;
}

export function makeCompanion(breed,coat) {
  if(breed.id==='shiba')return makeShiba(coat);
  const p=profiles[breed.id],id=breed.id,root=new T.Group();
  const material=(color,roughness=.90)=>new T.MeshStandardMaterial({color,roughness});
  const fur=material(breed.coats[coat][1]),bib=material(breed.coats[coat][2]);
  const dark=material('#302824',.37),glint=material('#fff7dc',.25),pink=material('#d68e83');
  const shade=material(fur.color.clone().lerp(new T.Color('#653f3a'),.22));
  const sphere=new T.SphereGeometry(1,24,18);
  function oval(parent,m,x,y,z,rx,ry,rz) {
    const part=new T.Mesh(sphere,m);part.position.set(x,y,z);part.scale.set(rx,ry,rz);
    part.castShadow=part.receiveShadow=true;parent.add(part);return part;
  }
  const group=(parent,x,y,z)=>{const g=new T.Group();g.position.set(x,y,z);parent.add(g);return g};
  const {hip,length,width,face}=p,short=hip<.50;
  oval(root,fur,0,hip+.08,-.03,width,width*.94,length);
  oval(root,bib,0,hip+.11,length*.59,width*.88,width*1.08,length*.38);
  if(id==='corgi'||id==='collie')oval(root,bib,0,hip+.17,length*.39,width*.98,width,length*.23);
  const legs=[];
  for(const side of [-1,1])for(const end of [-1,1]){
    const leg=group(root,side*width*.64,hip,end*length*.59);
    leg.userData.hip=leg.position.clone();leg.userData.phase=side*end>0?0:Math.PI;legs.push(leg);
    oval(leg,fur,0,-hip*.14,0,width*(end<0?.47:.34),hip*.48,width*.47);
    oval(leg,id==='poodle'?fur:bib,0,-hip*.60,0,width*.27,hip*.31,width*.30);
    leg.userData.paw=oval(leg,bib,0,.092-hip,.036,width*.37,.092,width*.43);
    if(id==='poodle')oval(leg,fur,0,.155-hip,0,.13,.12,.13);
  }
  const head=group(root,0,hip+face*(short?1.26:1.38),length*.67);
  oval(head,fur,0,0,0,face*1.1,face,face*.92);
  if(id==='corgi'||id==='collie')oval(head,bib,0,.048,face*.82,face*.175,face*.55,face*.15).rotation.x=-.21;
  if(id==='pomeranian'){
    for(let j=0;j<9;j++){
      const a=j*2*Math.PI/9;
      oval(root,bib,Math.cos(a)*.24,hip+.27+Math.sin(a)*.13,length*.40+Math.sin(a)*.17,.18,.23,.19);
    }
  }
  if(id==='poodle'){
    for(let j=0;j<7;j++){
      const a=j*2*Math.PI/7;
      oval(head,fur,.21*Math.cos(a),.24+.02*Math.cos(3*a),.14*Math.sin(a),.16,.14,.16);
    }
  }
  const eyes=[],ears=[];
  for(const s of [-1,1]){
    const eye=group(head,s*face*.47,face*.10,face*.785);eye.rotation.y=s*.36;
    const size=face*(id==='chihuahua'?.19:.153);
    oval(eye,dark,0,0,0,size,size*1.11,size*.72);
    oval(eye,glint,-size*.26,size*.33,size*.64,size*.24,size*.24,size*.13);eyes.push(eye);
    if((coat===1&&id==='chihuahua')||(coat>0&&id==='dachshund')||(coat===2&&id==='corgi'))
      oval(head,bib,s*face*.47,face*.36,face*.75,size*.85,size*.46,size*.5);
    const upright=['bat','fan','fox','tipped'].includes(p.ear);
    const ear=group(head,s*face*(upright?.64:.91),face*(upright?.52:.42),-.025);
    ears.push(ear);ear.rotation.z=s*(upright?-.26:.12);
    if(upright){
      const h={bat:.39,fan:.39,fox:.25,tipped:.33}[p.ear],w={bat:.172,fan:.18,fox:.126,tipped:.13}[p.ear];
      const points=[[.67,0],[.97,.17],[1,.32],[.85,.52],[.54,.78],[.15,.96],[.005,1]];
      const geo=new T.LatheGeometry(points.map(([r,y])=>new T.Vector2(r*w,y*h)),22);
      const tip=new T.Mesh(geo,fur);tip.castShadow=true;tip.scale.z=.59;ear.add(tip);
      oval(ear,pink,0,h*.45,w*.49,w*.55,h*.30,w*.16);
      if(p.ear==='tipped')oval(ear,shade,0,h*.84,.035,w*.57,.073,.061).rotation.x=.62;
    }else{
      const h=p.ear==='silk'?.25:p.ear==='fold'?.19:.155;
      oval(ear,p.ear==='puff'?fur:shade,s*.03,-h*.83,0,p.ear==='puff'?.153:.106,h*1.35,.158);
      if(p.ear==='puff')oval(ear,fur,s*.035,-.265,.02,.166,.159,.171);
    }
    oval(head,bib,s*face*.22,-face*.24,face*.79,face*.36,face*.26,p.snout*.90);
  }
  const noseZ=face*.79+p.snout;
  oval(head,bib,0,-face*.20,noseZ-.077,face*.32,face*.22,.113);
  oval(head,pink,0,-face*.39,noseZ-.039,face*.128,face*.104,.058);
  oval(head,dark,0,-face*.12,noseZ+.016,face*.20,face*.132,.051);
  const scarf=material(p.scarf);
  oval(root,scarf,0,head.position.y-face*.65,length*.50,face*.82,.085,face*.73);
  oval(root,scarf,face*.77,head.position.y-face*.69,length*.48,.095,.073,.079);
  oval(root,scarf,face*.91,head.position.y-face*.80,length*.41,.096,.049,.060).rotation.z=-.62;
  const tail=makeTail(p.tail,fur.color,bib.color);root.add(tail);tail.position.set(0,hip+.14,-length*.82);
  if(p.tail==='pom')oval(tail,fur,.08,.36,-.14,.126,.138,.125);
  root.userData.legs=legs;root.userData.tail=tail;root.userData.height=hip;
  root.userData.companionPose={head,eyes,ears,rest:ears.map(e=>e.rotation.z),floppy:['fold','puff','silk'].includes(p.ear),wag:id==='retriever'?4.4:id==='chihuahua'?8.4:6.5};
  return root;
}

export function poseCompanion(dog,t,running,reduced) {
  if(dog.userData.expression){poseShiba(dog,t,running,reduced);return}
  const {head,eyes,ears,rest,floppy,wag}=dog.userData.companionPose;
  const wave=reduced?0:Math.sin(t*(running?wag*1.25:wag*.62));
  dog.userData.tail.rotation.y=wave*(running?.35:.24);
  head.rotation.z=running?0:wave*.039;
  const blink=reduced?1:1-.93*Math.max(0,1-Math.abs((t+1.4)%4.1-.14)/.105);
  eyes.forEach(eye=>eye.scale.y=blink);
  ears.forEach((ear,i)=>{ear.rotation.z=rest[i]+(i?1:-1)*wave*(floppy&&running?.14:.035);ear.rotation.x=floppy&&running?wave*.12:0});
}
````

### `dist/review/v28/shiba.js`

````javascript
import * as T from '../../assets/three.module.js';

const clamp = T.MathUtils.clamp;
const blend = (value, a, b) => T.MathUtils.smoothstep(value, a, b);
const coats = [
  ['#db904d', '#fff0ce', '#ba7041'],
  ['#443b37', '#f5dbb8', '#bf8753'],
  ['#ebce98', '#fff4d9', '#e4bd81']
];

export function makeShiba(coatIndex) {
  const root = new T.Group();
  const [fur, cream, accent] = coats[coatIndex].map(color => new T.Color(color));
  const sphere = new T.SphereGeometry(1, 36, 26);
  const plain = (color, roughness = .9) => new T.MeshStandardMaterial({color, roughness});
  const furMat = plain(fur), bib = plain(cream), nose = plain('#2c2424', .39);
  const tongue = plain('#d8877a'), scarf = plain('#2066a2'), glint = plain('#fff8e8', .28);
  const painted = new T.MeshStandardMaterial({vertexColors:true, roughness:.94});
  function mesh(parent, geom, mat, x, y, z) {
    const part = new T.Mesh(geom, mat);
    part.position.set(x,y,z); part.castShadow = true; part.receiveShadow = true;
    parent.add(part); return part;
  }
  function oval(parent, mat, x,y,z, rx,ry,rz, geom=sphere) {
    const part = mesh(parent,geom,mat,x,y,z);
    part.scale.set(rx,ry,rz); return part;
  }
  function paintedSphere(paint, source=sphere) {
    const geom = source.clone(), pos = geom.attributes.position, colors = [];
    for (let i=0; i<pos.count; i++) {
      paint(pos.getX(i),pos.getY(i),pos.getZ(i)).toArray(colors,i*3);
    }
    geom.setAttribute('color',new T.Float32BufferAttribute(colors,3));
    return geom;
  }
  function stroke(parent, points, radius, mat) {
    const curve = new T.CatmullRomCurve3(points.map(v => new T.Vector3(...v)));
    return mesh(parent,new T.TubeGeometry(curve,13,radius,7,false),mat,0,0,0);
  }
  const mix = (a,b,k) => a.clone().lerp(b,k);
  const bodyColors = paintedSphere((x,y,z) => {
    const bibLine = -.46 + .68 * Math.max(z,0)**2 + .23 * Math.max(-z,0)**3;
    return mix(fur,cream,1-blend(y,bibLine-.08,bibLine+.09));
  });
  oval(root,painted,0,.76,-.05,.419,.424,.659,bodyColors);
  oval(root,bib,0,.90,.345,.34,.38,.275);
  const legs=[];
  for (const side of [-1,1]) for (const end of [-1,1]) {
    const leg = new T.Group();
    leg.position.set(side*.253,.69,end*.383); root.add(leg);
    leg.userData.hip=leg.position.clone(); leg.userData.phase=side*end>0?0:Math.PI;
    oval(leg,furMat,0,-.082,0,end<0?.173:.127,.29,.155);
    oval(leg,bib,0,-.32,-.01,.107,.244,.118);
    const paw=oval(leg,bib,0,.12-.69,.045,.136,.12,.163);
    leg.userData.paw=paw; legs.push(leg);
    // The hind soles show a carpal pad and three toes when the foot swings up.
    const pad=plain('#6d5145');
    oval(paw,pad,0,-.925,0,.42,.075,.39);
    for(const toe of [-1,0,1])oval(paw,pad,toe*.34,-.81,.43-Math.abs(toe)*.11,.135,.085,.145);
  }
  root.userData.legs=legs;
  const head=new T.Group(); head.position.set(0,1.315,.368); root.add(head);
  const face = paintedSphere((x,y,z)=>{
    const cheekLine=-.30+.33*Math.abs(x)**1.5+.045*z;
    const cheek=(1-blend(y,cheekLine-.042,cheekLine+.055))*blend(z,-.35,.46);
    const browX=(Math.abs(x)-.426)/.155, browY=(y-.332)/.091;
    const marking=(1-blend(browX*browX+browY*browY,.44,1.38))*blend(z,.46,.69);
    return mix(mix(fur,cream,cheek),coatIndex===1?accent:cream,marking*(coatIndex===1?.93:.75));
  },new T.SphereGeometry(1,64,42));
  oval(head,painted,0,0,0,.482,.435,.399,face);
  const inner=plain(coatIndex===1?'#ab826c':'#d99683');
  function ear(side) {
    const group=new T.Group(); group.position.set(side*.287,.243,-.048);
    group.rotation.z=-side*.20;group.rotation.x=-.045;head.add(group);
    // Rounded cross-sections taper to a soft point and a shallow inner cup.
    const rings=[[0,.149,.095],[.062,.158,.093],[.155,.137,.074],[.255,.098,.055],[.332,.06,.035],[.387,.025,.017],[.398,.003,.003]];
    const pos=[],index=[],colors=[];
    rings.forEach(([h,w,d],j)=>{
      for(let i=0;i<24;i++){
        const a=i*Math.PI/12,front=Math.sin(a),inset=blend(front,.52,.87)*blend(h,.055,.12)*(1-blend(h,.30,.38));
        pos.push(Math.cos(a)*w+side*h*.11,h,front*d-.016*inset+.018*j/6);
        mix(fur,inner.color,inset*.90).toArray(colors,colors.length);
        if(j>0){const k=(j-1)*24+i,n=(j-1)*24+(i+1)%24;index.push(k,k+24,n,n,k+24,n+24)}
      }
    });
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));
    geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.setIndex(index);geo.computeVertexNormals();
    mesh(group,geo,painted,0,0,0);return group;
  }
  const ears=[ear(-1),ear(1)],eyes=[];
  for(const s of [-1,1]) {
    const eyeball=new T.Group();eyeball.position.set(s*.209,.047,.339);
    eyeball.rotation.y=s*.39;head.add(eyeball);eyes.push(eyeball);
    oval(eyeball,nose,0,0,.011,.059,.065,.041);
    oval(eyeball,glint,-.018,.023,.043,.016,.017,.010);
    oval(head,bib,s*.093,-.104,.360,.158,.118,.147);
  }
  oval(head,bib,0,-.192,.385,.126,.071,.103);
  oval(head,tongue,0,-.183,.466,.054,.043,.037);
  for(const s of [-1,1])stroke(head,[[0,-.108,.489],[s*.034,-.137,.485],[s*.085,-.142,.492],[s*.129,-.123,.488]],.0068,plain('#644737'));
  oval(head,nose,0,-.068,.491,.088,.059,.058);
  // Broad kerchief folded over the nape, with a knot off-centre.
  const band=mesh(root,new T.CylinderGeometry(.337,.378,.113,36,1,true),scarf,0,1.027,.306);
  band.scale.z=.84;band.rotation.x=-.12;
  oval(root,scarf,.292,1.029,.150,.105,.074,.07);
  oval(root,scarf,.365,.998,.092,.136,.059,.052).rotation.z=.37;
  oval(root,scarf,.356,.953,.145,.107,.051,.049).rotation.z=-.53;
  const kerchief=new T.Shape();
  kerchief.moveTo(-.246,0);kerchief.quadraticCurveTo(-.086,-.238,.116,-.262);
  kerchief.quadraticCurveTo(.18,-.132,.253,0);kerchief.closePath();
  const flap=mesh(root,new T.ExtrudeGeometry(kerchief,{depth:.025,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:.018,bevelThickness:.016}),scarf,0,1.055,.039);
  flap.rotation.x=.66;
  // A tapered plume curls sideways across the rump so its spiral reads from behind.
  const tail=new T.Group(); tail.position.set(0,.834,-.538);root.add(tail);
  const path=new T.CatmullRomCurve3([[0,0,0],[-.102,.153,-.128],[-.081,.337,-.178],[.055,.440,-.165],[.218,.401,-.143],[.267,.274,-.143],[.205,.208,-.175],[.148,.24,-.195]].map(p=>new T.Vector3(...p)));
  const tube=new T.TubeGeometry(path,42,1,16,false),verts=tube.attributes.position,normals=tube.attributes.normal,tc=[];
  for(let i=0;i<verts.count;i++){
    const u=Math.floor(i/17)/42,center=path.getPointAt(u);
    const radius=.081+.063*Math.sin(Math.PI*u)**.55-.076*blend(u,.79,1);
    verts.setXYZ(i,center.x+normals.getX(i)*radius,center.y+normals.getY(i)*radius,center.z+normals.getZ(i)*radius);
    mix(fur,cream,blend(u+.07*normals.getY(i),.36,.74)).toArray(tc,tc.length);
  }
  tube.setAttribute('color',new T.Float32BufferAttribute(tc,3));tube.computeVertexNormals();
  mesh(tail,tube,painted,0,0,0);
  root.userData.tail=tail;root.userData.height=.69;
  root.userData.expression={head,ears,eyes};
  return root;
}

export function poseShiba(dog, time, running, reduced) {
  const rig=dog.userData.expression;
  if(!rig)return;
  const t=reduced?0:time;
  const blink=Math.max(0,1-Math.abs(t%4.9-3.61)/.115);
  rig.eyes.forEach(eye=>eye.scale.y=1-.91*blink);
  rig.head.rotation.z=running?0:Math.sin(t*1.34)*.034;
  rig.head.rotation.x=running?Math.sin(t*10)*.026:Math.sin(t*1.65)*.015;
  rig.ears.forEach((ear,i)=>ear.rotation.x=-.045+(running?.057*Math.sin(t*10+i*.5):.095*Math.max(0,Math.sin(t*1.9+i*3)-.8)*5));
  dog.userData.tail.rotation.y=Math.sin(t*(running?8.8:3.8))*(running?.255:.18);
  dog.userData.tail.rotation.x=running?.082*Math.sin(t*9.5):0;
}
````

