# 第10章　Node回帰テスト（1）

### `tests/arena-roster.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {FIELD_SEGMENTS,FIELD_BOUNDS,fieldPoint,FIELD_LENGTH} from '../dist/agility-route.js';
import {AGILITY,AgilitySimulation,buildFirstField} from '../dist/agility-sim.js';
import {RaceSimulation} from '../dist/race-sim.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {makeAgilityField} from '../dist/agility-field.js';
test('agility runs 50% faster without adding an item system',()=>{
 assert.equal(AGILITY.speed,7.5*1.5);const s=new AgilitySimulation();s.start();for(let i=0;i<61;i++)s.step(.05);
 const before=s.player.s;for(let i=0;i<60;i++)s.step(1/60);assert(Math.abs(s.player.s-before-11.25)<1e-8);assert.equal(s.input('dash'),false);assert.equal(s.layout.treats.length,0);assert.equal(s.cpus.length,0);
});
test('the course folds through an open arena, with continuous headings and clear perimeter margins',()=>{
 const b=FIELD_BOUNDS;let east=false,west=false,south=false;
 for(let s=0;s<=FIELD_LENGTH;s+=.3)for(const lane of [-2,0,2]){const p=fieldPoint(s,lane),next=fieldPoint(s+.001,lane);assert(p.x>b.minX+6&&p.x<b.maxX-6);assert(p.z>b.minZ+6&&p.z<b.maxZ-6);assert(Math.hypot(next.x-p.x,next.z-p.z)<.002);east||=Math.sin(p.heading)>.9;west||=Math.sin(p.heading)<-.9;south||=Math.cos(p.heading)<-.9}
 assert(east&&west&&south);for(const t of FIELD_SEGMENTS.slice(1)){const a=fieldPoint(t.start-.00001),b=fieldPoint(t.start+.00001);assert(Math.hypot(a.x-b.x,a.z-b.z)<.00003);assert(Math.abs(a.heading-b.heading)<.00001)}
 const obstacles=buildFirstField().obstacles;for(const o of obstacles){const segment=FIELD_SEGMENTS.find(t=>o.s>=t.start&&o.s<=t.end);assert.equal(segment.turn,0);assert(o.s-segment.start>7&&segment.end-o.s>7)}
});
test('rear-camera projection stays centred through the new arena turns in portrait and landscape',()=>{
 for(const aspect of [390/844,844/390]){const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let screenY;
  for(let s=0;s<FIELD_LENGTH;s+=.5){const p=fieldPoint(s,2),pose=chaseCameraPose(p);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const projected=new T.Vector3(p.x,.75,p.z).project(camera);assert(Math.abs(projected.x)<1e-9);screenY??=projected.y;assert(Math.abs(projected.y-screenY)<1e-9)}
 }
});
test('arena fence encloses the whole lawn; target marker follows only the next obstacle',()=>{
 const s=new AgilitySimulation(),field=makeAgilityField(s.layout),b=FIELD_BOUNDS;
 assert(field.root.getObjectByName('open-lawn'));for(const name of ['continuous-road','lane-markings','fence-rails','treat-trail'])assert(!field.root.getObjectByName(name));
 const posts=field.root.getObjectByName('perimeter-posts'),m=new T.Matrix4(),p=new T.Vector3();for(let i=0;i<posts.count;i++){posts.getMatrixAt(i,m);p.setFromMatrixPosition(m);assert(Math.min(Math.abs(p.x-b.minX),Math.abs(p.x-b.maxX),Math.abs(p.z-b.minZ),Math.abs(p.z-b.maxZ))<.0001)}
 field.update(s);const marker=field.root.getObjectByName('next-obstacle-marker'),first=fieldPoint(s.layout.obstacles[0].s);assert(marker.visible);assert.equal(marker.position.x,first.x);
 s.results.set(0,true);field.update(s);const second=s.layout.obstacles[1],pos=fieldPoint(second.s,second.lane*2);assert.equal(marker.position.x,pos.x);assert.equal(marker.position.z,pos.z);
 for(const o of s.layout.obstacles)s.results.set(o.id,true);field.update(s);assert(!marker.visible);field.resetTreats();assert(!marker.visible);
 const geo=new Set(),mats=new Set();field.root.traverse(o=>{if(o.geometry)geo.add(o.geometry);if(o.material)mats.add(o.material)});geo.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());
});
test('race has four finite CPU actors and correctly awards fifth place, including after retry',()=>{
 const s=new RaceSimulation();assert.equal(s.cpus.length,4);assert.equal(new Set(s.cpus.map(c=>c.id)).size,4);s.start();
 for(let i=0;i<1300;i++)s.step(.05);assert.equal(s.rank,5);assert(s.cpus.every(c=>c.finishTime!==null&&Number.isFinite(c.x)&&Number.isFinite(c.s)));
 for(let i=0;i<1300&&s.status!=='finished';i++){const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);s.step(.05)}
 assert.equal(s.status,'finished');assert.equal(s.result.rank,5);s.reset();assert.equal(s.cpus.length,4);assert(s.cpus.every(c=>c.finishTime===null));
});
````

### `tests/balance.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {AgilitySimulation,AGILITY,buildAgilityCourse} from '../dist/agility-sim.js';
import {SEESAW,seesawHalfSpan,seesawSurface} from '../dist/seesaw.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
const advance=(sim,seconds)=>{for(let i=0;i<Math.ceil(seconds*60);i++)sim.step(1/60)};
const running=()=>{const sim=new AgilitySimulation('balance');sim.start();advance(sim,3.1);return sim};
const enter=()=>{const sim=running(),o=sim.layout.obstacles.find(o=>o.type==='seesaw');sim.player.s=o.s-seesawHalfSpan()-.2;sim.player.x=o.lane*2;sim.player.lane=o.lane;advance(sim,.1);assert.equal(sim.activeSeesaw.state.phase,'approach');return {sim,o}};
test('seesaw requires stopping near its centre, waiting, and manually tapping to exit',()=>{
 const {sim,o}=enter();assert.equal(sim.input('jump'),false);assert.equal(sim.input('right'),false);
 sim.input('brake');advance(sim,1);assert.equal(sim.activeSeesaw.state.phase,'approach','early stop must not tip the board');sim.input('dash');
 while(sim.player.s<o.s+.1)sim.step(1/60);sim.input('brake');const position=sim.player.s,time=sim.time;assert.equal(sim.activeSeesaw.state.phase,'hold');assert.equal(sim.input('dash'),false);
 advance(sim,.6);assert.equal(sim.activeSeesaw.state.phase,'tipping');assert.equal(sim.input('dash'),false);const angle=sim.activeSeesaw.state.angle;
 sim.pause();advance(sim,2);assert.equal(sim.activeSeesaw.state.angle,angle);sim.resume();advance(sim,1);assert.equal(sim.activeSeesaw.state.phase,'ready');assert.equal(sim.player.s,position);assert(sim.time>time+1.5);assert(sim.stopped);
 advance(sim,1);assert.equal(sim.player.s,position,'board reaching ground never auto-resumes');sim.input('dash');advance(sim,1.3);assert.equal(sim.results.get(o.id),true);assert.equal(sim.cleared,1);assert.equal(sim.player.surfaceY,0);assert.equal(sim.player.pitch,0);
 const s=sim.player.s;advance(sim,.2);assert(Math.abs(sim.player.s-s-AGILITY.speed*.2)<1e-8);
});
test('missing the stop recovers on the board and counts one fault only on exit',()=>{
 const {sim,o}=enter();advance(sim,3);assert.equal(sim.activeSeesaw.state.phase,'ready');assert(sim.stopped);assert(sim.activeSeesaw.state.failed);assert.equal(sim.results.has(o.id),false);sim.input('dash');advance(sim,2);assert.equal(sim.results.get(o.id),false);assert.equal(sim.faults,1);advance(sim,.5);assert.equal(sim.faults,1);
});
test('bypassing or jumping onto a seesaw cannot count as a successful crossing',()=>{
 for(const jump of [true,false]){const sim=running(),o=sim.layout.obstacles[1];sim.player.s=o.s-seesawHalfSpan()-.3;sim.player.lane=jump?o.lane:1;sim.player.x=sim.player.lane*2;if(jump)sim.input('jump');advance(sim,1.3);assert.equal(sim.results.get(o.id),false);assert.equal(sim.faults,1);assert.equal(sim.activeSeesaw,null)}
});
test('all six balance obstacles can be cleared in a continuous run at varied frame intervals',()=>{
 for(const dt of [1/60,.05,.1]){const sim=running();for(let i=0;i<6000&&sim.status==='running';i++){
  const o=sim.nextObstacle,p=sim.player,board=sim.activeSeesaw;
  if(board){if(board.state.phase==='approach'&&p.s>=o.s-.25)sim.input('brake');if(board.state.phase==='ready')sim.input('dash')}
  else if(o){if(o.lane<p.lane)sim.input('left');if(o.lane>p.lane)sim.input('right');if(['hoop','hurdle'].includes(o.type)&&o.s-p.s<3.8&&o.s>p.s&&p.jumpElapsed===null)sim.input('jump')}
  sim.step(dt);
 }
 assert.equal(sim.status,'finished');assert.equal(sim.cleared,6);assert.equal(sim.faults,0);assert.equal(sim.result.total,sim.result.time);assert.equal(sim.cpus.length,0);assert.equal(sim.layout.treats.length,0);
 sim.reset();assert.equal(sim.results.size,0);assert.equal(sim.activeSeesaw,null);assert.equal(sim.player.y,0);assert.equal(sim.player.pitch,0);assert([...sim.seesaws.values()].every(s=>s.phase==='idle'&&s.angle===SEESAW.angle&&!s.failed));
 }
});
test('a tipping board stays rigid and the dog contact point remains on its painted top surface',()=>{
 const {sim,o}=enter(),field=makeAgilityField(sim.layout),plank=field.root.getObjectByName('rigid-plank');
 const parts=plank.children.slice().sort((a,b)=>a.position.z-b.position.z);assert.equal(parts.length,3);
 for(let i=1;i<parts.length;i++)assert(Math.abs(parts[i-1].position.z+parts[i-1].geometry.parameters.depth/2-parts[i].position.z+parts[i].geometry.parameters.depth/2)<1e-9);
 while(sim.player.s<o.s+.2)sim.step(1/60);sim.input('brake');let tipped=false;
 for(let i=0;i<100;i++){sim.step(1/60);field.animate(sim);field.root.updateMatrixWorld(true);const state=sim.seesaws.get(o.id),p=sim.player,anchor=sim.layout.point(p.s,p.x),contact=plank.worldToLocal(new T.Vector3(anchor.x,p.y,anchor.z));assert(Math.abs(contact.y-SEESAW.thickness/2)<1e-8);assert(Math.abs(contact.x)<1e-8);assert.equal(plank.rotation.x,state.angle);assert.equal(p.pitch,-state.angle);tipped||=state.angle<0}
 assert(tipped);sim.reset();field.resetTreats();assert.equal(plank.rotation.x,SEESAW.angle);
 const geo=new Set(),mats=new Set();field.root.traverse(o=>{if(o.geometry)geo.add(o.geometry);if(o.material)mats.add(o.material)});geo.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());
});
test('camera stays centred vertically as either seesaw tips, in portrait and landscape',()=>{
 for(const aspect of [390/844,844/390]){const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let screenY;
  for(const o of buildAgilityCourse('balance').obstacles.filter(o=>o.type==='seesaw'))for(const angle of [SEESAW.angle,0,-SEESAW.angle]){const p=buildAgilityCourse('balance').point(o.s+.4,o.lane*2),surface=seesawSurface(.4,angle),pose=chaseCameraPose(p,{height:2.8+surface,lookHeight:1+surface});camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const dog=new T.Vector3(p.x,surface+.75,p.z).project(camera);assert(Math.abs(dog.x)<1e-9);screenY??=dog.y;assert(Math.abs(dog.y-screenY)<1e-9)}
 }
});
````

### `tests/beach.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation, RACE} from '../dist/race-sim.js';
import {buildBeachRace, touchesSoftSand} from '../dist/beach-layout.js';
import {cornerAt, TURN_WINDOW} from '../dist/race-route.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {courses,canPlay} from '../dist/courses.js';
import {breeds} from '../dist/breeds.js';
import {makeCourseScene} from '../dist/course-scene.js';

function start() {
  const sim = new RaceSimulation('beach');
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}
test('the beach has reachable trails beside all logs and clear turn windows', () => {
  const layout = buildBeachRace();
  assert(canPlay('race','beach'));
  assert.deepEqual(layout.obstacles.map(log=>log.lane),[0,1,-1,1,-1]);
  assert.equal(new Set(layout.treats.map(x=>x.id)).size,layout.treats.length);
  for (const o of layout.obstacles) {
    const row = layout.treats.filter(t=>Math.abs(t.s-o.s)<8 && t.lane===o.snackLane);
    const arc=layout.treats.filter(t=>t.jumpLog===o.id);
    assert.equal(arc.length,3);assert(arc.every(t=>t.lane===o.lane && t.y>.65+.8));
    assert.equal(row.length,13);
    assert(row.every(t=>t.lane===o.snackLane && t.y===.65 && !cornerAt(t.s,TURN_WINDOW,4,layout.turns)));
    assert.notEqual(o.lane,o.snackLane);
    assert(!touchesSoftSand(layout.sand,o.s,o.lane*RACE.lanewidth));
    assert(!layout.treats.some(t=>t.lane===o.lane && t.y===.65 && Math.abs(t.s-o.s)<8));
    assert(touchesSoftSand(layout.sand,o.s,o.snackLane*2));
  }
  for (const turn of layout.turns) {
    const start = layout.point(turn.start), end = layout.point(turn.end);
    assert((end.heading-start.heading)*(turn.direction==='right'?1:-1)>.4);
    const p = layout.point(turn.end-.001), q = layout.point(turn.end+.001);
    assert(Math.hypot(p.x-q.x,p.z-q.z)<.0021);
  }
});
test('the firm line rewards a jump and the soft side awards the whole treat row', () => {
  for(const choice of ['jump','hit','snacks']){
    const sim=start(), log=sim.layout.obstacles[0],p=sim.player;
    p.s=log.s-8.2;
    if(choice==='snacks')sim.input('left');
    let slowSand=false,elapsed=0;
    while(p.s<log.s+8.2){
      if(choice==='jump'&&p.s>=log.s-3.6&&p.s<log.s&&p.jumpElapsed===null)sim.input('jump');
      const before=p.s;sim.step(.025);elapsed+=.025;
      if(Math.abs(p.s-log.s)<3 && p.s-before<RACE.speed*.025*.9)slowSand=true;
    }
    assert.equal(p.hits,choice==='hit'?1:0);
    if(choice==='jump'){assert(elapsed<1.8);assert.equal(sim.treatCount,3)}
    if(choice==='hit')assert.equal(sim.treatCount,0);
    if(choice==='snacks'){assert.equal(sim.treatCount,13);assert(slowSand);assert(elapsed>1.8)}
  }
});
test('a five-dog beach race supports manual boosts, real turns, recovery, finish and retry', () => {
  for(const dt of [.02,.05,.1]){
    const sim=start();let ready=false,recovered=false;
    for(let i=0;i<9000&&sim.status==='running';i++){
      const cue=sim.turnCue,p=sim.player;
      if(cue?.waiting){assert.equal(cue.start,p.s);assert.equal(sim.input(cue.direction==='right'?'left':'right'),false);sim.input(cue.direction);recovered=true}
      else if(cue?.active&&cue.id!==0&&!cue.armed)sim.input(cue.direction);
      else if(!cue?.active){
        const log=sim.layout.obstacles.find(o=>p.s>o.s-11&&p.s<o.s+8);
        const lane=log?.snackLane??0;
        if(p.lane!==lane)sim.input(lane>p.lane?'right':'left');
      }
      if(sim.gauge===20 && !p.boost){assert.equal(p.boost,0);ready=true;sim.input('dash')}
      sim.step(dt);
    }
    assert(ready&&recovered);assert.equal(sim.status,'finished');assert.equal(sim.cpus.length,4);assert.equal(sim.player.s,sim.layout.length);assert(sim.result.dashes>0);
    assert.equal(sim.result.turns,4);assert.equal(sim.result.turnMisses,1);assert(sim.result.rank>=1&&sim.result.rank<=5);
    sim.reset();assert.equal(sim.layout.theme,'beach');assert.equal(sim.collected.size,0);assert.equal(sim.gauge,0);
  }
});
test('beach geometry, log and pickup positions match the physics route', () => {
  const layout=buildBeachRace(),track=makeRaceTrack(layout),preview=makeCourseScene(courses.find(c=>c.id==='beach'),breeds[0],0);
  for(const name of ['ocean','surf-line','soft-sand','beach-stakes','parasols','finish-gate'])assert(track.root.getObjectByName(name),name);
  assert(!track.root.getObjectByName('fence-rails'));
  const logs=track.root.children.filter(c=>c.name==='race-obstacle');
  assert.equal(logs.length,5);assert.equal(preview.children.filter(c=>c.name==='log').length,5);
  for(const obj of logs){const o=layout.obstacles[obj.userData.obstacleId],p=layout.point(o.s,o.lane*2);assert.equal(obj.position.x,p.x);assert.equal(obj.position.z,p.z)}
  const matrix=new T.Matrix4(),v=new T.Vector3();
  for(const t of layout.treats){track.treatMesh.getMatrixAt(t.id,matrix);v.setFromMatrixPosition(matrix);const p=layout.point(t.s,t.lane*2);assert(Math.hypot(v.x-p.x,v.z-p.z)<.0001)}
  const gate=track.root.getObjectByName('finish-gate'),p=layout.point(layout.length);assert.equal(gate.position.x,p.x);assert.equal(gate.position.z,p.z);
  for(const obj of [track.root,preview])obj.traverse(node=>{if(node.geometry){assert(node.geometry.attributes.position.array.every(Number.isFinite));node.geometry.dispose();node.material.dispose()}});
});

test('steering along either beach trail beats staying in the middle even with timely jumps and dashes', () => {
  for (const dt of [1/60, .05, .1]) {
    const results = {};
    for (const route of ['middle', 'logs', 'sand']) {
      const sim = start(), p = sim.player;
      for (let frame = 0; frame < 6500 && sim.status === 'running'; frame++) {
        const turn = sim.turnCue;
        if (turn?.active && !turn.armed) sim.input(turn.direction);
        const log = sim.layout.obstacles.find(o => p.s < o.s + 8.6 && o.s - p.s < 16);
        let lane = 0;
        if (route !== 'middle') {
          const ground = sim.layout.treats.find(t => t.s >= p.s + 1.9 && t.y === .65);
          lane = log ? (route === 'logs' ? log.lane : log.snackLane) : (ground?.lane ?? 0);
        }
        if (!turn?.active && p.lane !== lane) sim.input(p.lane < lane ? 'right' : 'left');
        if (sim.gauge === RACE.gaugeMax) sim.input('dash');
        const toApex = RACE.jumpDuration / 2 + dt / 2;
        const takeoff = p.speed * toApex + (RACE.boostSpeed - p.speed) * Math.min(p.boost, toApex);
        if (log && p.lane === log.lane && p.s < log.s && log.s - p.s < takeoff) sim.input('jump');
        sim.step(dt);
      }
      assert.equal(sim.status, 'finished');
      assert.equal(sim.result.turnMisses, 0);
      assert.equal(sim.result.hits, 0);
      results[route] = sim.result;
      if (route === 'logs') {
        assert(sim.layout.treats.filter(t => t.jumpLog !== undefined).every(t => sim.collected.has(t.id)));
      }
      if (route === 'sand') {
        for (const log of sim.layout.obstacles) {
          const row = sim.layout.treats.filter(t => Math.abs(t.s - log.s) < 8 && t.lane === log.snackLane);
          assert(row.every(t => sim.collected.has(t.id)));
        }
      }
    }
    for (const route of [results.logs, results.sand]) {
      assert(route.treats > results.middle.treats);
      assert(route.time < results.middle.time);
      assert(route.rank < results.middle.rank);
    }
  }
});
````

### `tests/camera-agility.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {routePoint,PARK_TURNS} from '../dist/race-route.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {AgilitySimulation,AGILITY,fieldPoint,buildFirstField} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
const run=()=>{const s=new AgilitySimulation();s.start();for(let i=0;i<61;i++)s.step(.05);return s};
const advance=(s,seconds)=>{for(let i=0;i<Math.ceil(seconds*60);i++)s.step(1/60)};
test('dog projects to the same screen position on straights and every bend, in both orientations',()=>{
 for(const aspect of [390/844,844/390]){
  const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let baseline;
  for(let s=0;s<=480;s+=.5)for(const lane of [-2,0,2]){
   const anchor=routePoint(s,lane),pose=chaseCameraPose(anchor);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();
   const dog=new T.Vector3(anchor.x,.75,anchor.z).project(camera);assert(Math.abs(dog.x)<1e-10);baseline??=dog.y;assert(Math.abs(dog.y-baseline)<1e-10);assert(Math.abs(dog.y)<.85);
  }
 }
});
test('camera keeps a constant rear offset and heading through all turn boundaries',()=>{
 for(const t of PARK_TURNS)for(const s of [t.start-.01,t.start,t.start+.01,t.end-.01,t.end,t.end+.01]){
  const p=routePoint(s),c=chaseCameraPose(p);assert(Math.abs(Math.hypot(c.position.x-p.x,c.position.z-p.z)-6)<1e-9);
  const dx=p.x-c.position.x,dz=p.z-c.position.z;assert(Math.abs(dx*Math.cos(p.heading)+dz*Math.sin(p.heading))<1e-9);
 }
});
test('agility stop holds position while time runs; tap resumes and menu pause freezes time',()=>{
 const s=run();advance(s,1);s.input('brake');const distance=s.player.s,time=s.time;advance(s,2);assert.equal(s.player.s,distance);assert(s.time>time+1.9);assert.equal(s.input('jump'),false);assert(s.input('dash'));assert.equal(s.input('dash'),false);advance(s,.2);assert(s.player.s>distance);
 s.input('brake');s.pause();const paused=s.time;advance(s,2);assert.equal(s.time,paused);assert.equal(s.input('dash'),false);s.resume();assert(s.stopped);s.input('dash');assert(!s.stopped);
});
test('jumped hurdles clear once; walking into or bypassing one adds one fault',()=>{
 const good=run();good.player.s=good.layout.obstacles[0].s-AGILITY.speed*.45;good.input('jump');advance(good,.6);assert.equal(good.cleared,1);assert.equal(good.faults,0);
 for(const lane of [0,1]){const s=run();s.player.s=s.layout.obstacles[0].s-.2;s.player.lane=lane;s.player.x=lane*2;advance(s,.3);assert.equal(s.faults,1);advance(s,.5);assert.equal(s.faults,1);assert.equal(s.results.get(0),false)}
});
test('tunnel clearance requires correct ground-level entry and exit; jumping or cutting in fails',()=>{
 const t=buildFirstField().obstacles.find(o=>o.type==='tunnel');
 for(const correct of [true,false]){const s=run();s.player.s=t.s-3.2;s.player.lane=correct?t.lane:0;s.player.x=s.player.lane*2;advance(s,.06);if(correct){assert.equal(s.input('jump'),false);assert.equal(s.input('left'),false)}else{s.player.x=t.lane*2;s.player.lane=t.lane}advance(s,1);assert.equal(s.results.get(t.id),correct)}
});
test('all six agility obstacles are playable, with score and retry state kept separate from racing',()=>{
 const s=run();for(let i=0;i<4000&&s.status==='running';i++){
  const o=s.nextObstacle,p=s.player;if(o){if(o.lane<p.lane)s.input('left');if(o.lane>p.lane)s.input('right');if(o.type!=='tunnel'&&o.s-p.s<3.5&&o.s>p.s&&p.jumpElapsed===null)s.input('jump')}s.step(1/60);
 }
 assert.equal(s.status,'finished');assert.equal(s.result.cleared,6);assert.equal(s.result.faults,0);assert.equal(s.result.total,s.result.time);assert.equal(s.cpus.length,0);
 s.reset();assert.equal(s.results.size,0);assert.equal(s.tunnelEntries.size,0);assert.equal(s.faults,0);assert.equal(s.status,'ready');assert.equal(s.stopped,false);
 const missed=run();advance(missed,80);assert.equal(missed.status,'finished');assert.equal(missed.result.total,missed.result.time+missed.result.faults*AGILITY.penalty);assert.equal(missed.results.size,6);
});
test('agility track positions and hoops match its own route, without race treats or turn signs',()=>{
 const layout=buildFirstField(),track=makeAgilityField(layout);track.root.updateMatrixWorld(true);let hoops=0;
 track.root.traverse(o=>{if(o.geometry)assert(o.geometry.attributes.position.array.every(Number.isFinite));if(o.name==='race-obstacle'){const ob=layout.obstacles.find(x=>x.id===o.userData.obstacleId),p=fieldPoint(ob.s,ob.lane*2);assert(Math.abs(o.position.x-p.x)<1e-9);assert(Math.abs(o.position.z-p.z)<1e-9);if(ob.type==='hoop')hoops++}});
 assert.equal(hoops,2);assert(!track.root.getObjectByName('treat-trail'));assert(!track.root.getObjectByName('continuous-road'));assert(!track.root.getObjectByName('lane-markings'));assert(!track.root.getObjectByName('turn-sign'));const end=fieldPoint(AGILITY.length),gate=track.root.getObjectByName('finish-gate');assert.equal(gate.position.x,end.x);assert.equal(gate.position.z,end.z);
 const geometries=new Set(),materials=new Set();track.root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());
});

test('hurdles, hoops and tunnel mouths are judged at passage across different frame rates',()=>{
 for(const dt of [1/120,1/60,.05,.1]){
  for(const type of ['hurdle','hoop']){
   for(const [lead,expected] of [[.12,false],[.18,true],[.75,true],[.82,false]]){
    const s=run(),o=s.layout.obstacles.find(o=>o.type===type);
    s.player.lane=o.lane;s.player.x=o.lane*2;s.player.s=o.s-AGILITY.speed*lead;
    s.input('jump');while(!s.results.has(o.id))s.step(dt);
    assert.equal(s.results.get(o.id),expected,type+' lead '+lead+' dt '+dt);
    if(!expected)assert.equal(s.drainEvents().find(e=>e.type==='obstacle-miss').reason,'jump-low');
   }
  }
  for(const [lead,expected] of [[.04,false],[.09,true]]){
   const s=run(),o=s.layout.obstacles.find(o=>o.type==='tunnel');
   s.player.lane=o.lane;s.player.x=0;s.player.s=o.s-3-AGILITY.speed*lead;
   while(!s.results.has(o.id))s.step(dt);
   assert.equal(s.results.get(o.id),expected,'tunnel entry dt '+dt);
   if(!expected)assert.equal(s.drainEvents().find(e=>e.type==='obstacle-miss').reason,'tunnel-entry');
  }
 }
});
````

### `tests/companion-scarf.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {breeds} from '../dist/breeds.js';
import {makeCompanion,poseCompanion} from '../dist/companions.js';
import {poseLegs} from '../dist/dog-gait.js';

test('the scarf band is visible across the chest and both shoulders in selection and running poses',()=>{
  const ray=new T.Raycaster(),aim=new T.Vector3(),direction=new T.Vector3();
  for(const breed of breeds){
    const dog=makeCompanion(breed,0);
    const scarf=dog.getObjectByName('neck-scarf'),band=scarf.getObjectByName('scarf-band');
    const fabric=band.geometry.attributes.position;
    const center=new T.Box3().setFromObject(band).getCenter(new T.Vector3());
    for(const running of [false,true]){
      poseCompanion(dog,.82,running,false);
      poseLegs(dog,1.2,running,false,()=>0);
      dog.updateMatrixWorld(true);
      for(const angle of [0,-1.15,1.15]){
        const eye=center.clone().add(new T.Vector3(4*Math.sin(angle),.72,4*Math.cos(angle)));
        let visible=0,probes=0;
        // Long ears can cover a shoulder. The front bib should be visible across almost its full width.
        for(let i=0;i<64;i++){
          if(Math.cos(i*Math.PI/32-angle)<.86)continue;
          aim.fromBufferAttribute(fabric,3*64+i);
          ray.set(eye,direction.subVectors(aim,eye).normalize());
          if(ray.intersectObject(dog,true)[0]?.object===band)visible++;
          probes++;
        }
        assert(visible>=probes*(angle===0?.8:1/3),breed.id+' scarf hidden at '+angle+' ('+visible+'/'+probes+')');
      }
    }
  }
});
````

### `tests/course-progression.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import {courses,nextPlayableCourse} from '../dist/courses.js';

test('continue in the same mode, skipping preview courses and stopping at the end',()=>{
 const preview={id:'preview-only',mode:'race'};
 const index=courses.findIndex(course=>course.id==='park')+1;
 courses.splice(index,0,preview);
 try{
  assert.equal(nextPlayableCourse('race','park')?.id,'beach');
  assert.equal(nextPlayableCourse('race','beach')?.id,'forest');
  assert.equal(nextPlayableCourse('race','forest'),null);
  assert.equal(nextPlayableCourse('agility','first-field')?.id,'zigzag');
  assert.equal(nextPlayableCourse('agility','zigzag')?.id,'balance');
  assert.equal(nextPlayableCourse('agility','balance')?.id,'hill-field');
  assert.equal(nextPlayableCourse('agility','hill-field'),null);
  assert.equal(nextPlayableCourse('agility','park'),null);
 }finally{courses.splice(index,1)}
});
````

### `tests/course-records.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import {courseBest, finishRecord, formatRaceClock} from '../dist/course-records.js';
import {courses} from '../dist/courses.js';

const legacy = {
  park: 'wan-run-best-park-turns-v1', beach: 'wan-run-best-beach-v1', forest: 'wan-run-best-forest-v1',
  'first-field': 'wan-run-best-first-field-arena-v2', zigzag: 'wan-run-best-zigzag-v1', balance: 'wan-run-best-balance-v1'
};
function storage() {
  const data = new Map();
  globalThis.localStorage = {
    getItem: key => data.get(key) ?? null,
    setItem: (key, value) => data.set(key, value)
  };
  return data;
}
test('all six existing records are read without migration and compared independently', () => {
  const data = storage();
  const previousCourses = courses.filter(course => Object.hasOwn(legacy, course.id));
  previousCourses.forEach((course, i) => data.set(legacy[course.id], String(40+i)));
  for(const [i, course] of previousCourses.entries()) {
    assert.equal(courseBest(course.id), 40+i);
    const record = finishRecord(course.id, 39+i);
    assert.deepEqual([record.state, record.label, record.best], ['faster','1.00秒短縮',39+i]);
  }
  assert.equal(data.size, 6);
  assert.equal(courseBest('hill-field'), null);
  assert.equal(finishRecord('hill-field', 24.5).state, 'first');
  assert.equal(data.get('wan-run-best-hill-field-v1'), '24.5');
  assert.equal(courseBest('balance'),44);
});
test('first finish, tie, improvement and gap use the precision of the visible score', () => {
  const data = storage();
  assert.equal(courseBest('beach'), null);
  assert.equal(finishRecord('beach', 38.204).state, 'first');
  assert.equal(finishRecord('beach', 38.201).label, '自己ベストタイ');
  assert.equal(finishRecord('beach', 37.976).label, '0.22秒短縮');
  assert.equal(finishRecord('beach', 39.121).label, 'ベストまで 1.14秒');
  assert.equal(courseBest('beach'), 37.976);
  // Read the current saved record again if another tab updates it during play.
  data.set(legacy.beach, '35.555');
  assert.equal(finishRecord('beach', 36.5).state, 'slower');
  assert.equal(courseBest('beach'), 35.555);
});
test('invalid saved times do not prevent finishing; unavailable storage retains records for this session', () => {
  const data = storage();
  for(const bad of ['', 'nope', '0', '-2', 'Infinity']){
    data.set(legacy.zigzag, bad);
    assert.equal(courseBest('zigzag'),null);
  }
  const set = localStorage.setItem;
  localStorage.setItem = () => {throw Error('quota')};
  assert.equal(finishRecord('zigzag', 56).temporary,true);
  assert.equal(courseBest('zigzag'),56);
  localStorage.getItem = () => {throw Error('private')};
  assert.equal(finishRecord('zigzag', 55).label,'1.00秒短縮');
  localStorage.getItem = key => data.get(key) ?? null;
  localStorage.setItem = set;
  assert.equal(finishRecord('zigzag', 60).temporary,false);
  assert.equal(data.get(legacy.zigzag),'55');
});

test('the running clock carries rounded tenths into the next minute', () => {
  assert.equal(formatRaceClock(0), '00:00.0');
  assert.equal(formatRaceClock(59.94), '00:59.9');
  assert.equal(formatRaceClock(59.96), '01:00.0');
  assert.equal(formatRaceClock(60.06), '01:00.1');
  assert.equal(formatRaceClock(119.95), '02:00.0');
});
````

### `tests/forest.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation, RACE} from '../dist/race-sim.js';
import {buildForestRace} from '../dist/forest-layout.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {cornerAt,TURN_WINDOW} from '../dist/race-route.js';
import {courses,canPlay} from '../dist/courses.js';
import {makeCourseScene} from '../dist/course-scene.js';
import {breeds} from '../dist/breeds.js';

function start(course) {
  const sim = new RaceSimulation(course);
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}

test('each beach log rewards one normal or boosted jump at different frame intervals', () => {
  for (const log of start('beach').layout.obstacles) {
    for (const dt of [1/60, .05, .1]) for (const boosted of [true,false]) {
      const sim = start('beach'), p = sim.player;
      const speed = boosted ? RACE.boostSpeed : p.speed;
      p.s = log.s - speed * RACE.jumpDuration * .5;
      p.lane = log.lane; p.x = log.lane * RACE.lanewidth;
      if (boosted) {sim.gauge = 20;assert(sim.input('dash'))}
      assert(sim.input('jump'));
      while (p.s <= log.s+4) sim.step(dt);
      assert.equal(p.hits,0);
      const arc=sim.layout.treats.filter(t=>t.jumpLog===log.id);
      assert.equal(arc.filter(t=>sim.collected.has(t.id)).length,3);
    }
  }
});

test('forest rounds six real bends and allows all seven logs to be jumped in one race', () => {
  for(const dt of [1/60,.05,.1]){
    const sim=start('forest'), p=sim.player;
    assert.equal(sim.cpus.length,4);assert.equal(sim.layout.theme,'forest');
    let jumps=0;
    for(let i=0;i<6500&&sim.status==='running';i++){
      const cue=sim.turnCue;
      if(cue?.active&&!cue.armed)sim.input(cue.direction);
      if(!cue?.active){
        const next=sim.layout.obstacles.find(log=>p.s<log.s+3.4&&log.s-p.s<13);
        const lane=next?.lane??0;
        if(lane!==p.lane)sim.input(lane>p.lane?'right':'left');
        if(next && next.s>p.s && next.s-p.s<4.6 && p.jumpElapsed===null){sim.input('jump');jumps++}
      }
      sim.step(dt);
    }
    assert.equal(sim.status,'finished');assert.equal(sim.result.turns,6);assert.equal(sim.result.turnMisses,0);
    assert.equal(jumps,7);assert.equal(p.hits,0);assert.equal(p.s,510);assert(sim.result.rank>=1&&sim.result.rank<=5);
    assert(sim.layout.treats.filter(t=>t.jumpLog!==undefined).every(t=>sim.collected.has(t.id)));
    sim.reset();assert.equal(sim.gauge,0);assert.equal(sim.collected.size,0);assert.equal(sim.layout.theme,'forest');
  }
});

test('forest obstacles and turns leave space for steering; scenery, preview and rewards follow the playable path', () => {
  const layout=buildForestRace(),track=makeRaceTrack(layout), root=track.root;
  assert(canPlay('race','forest'));assert(root.getObjectByName('birch-trunks'));assert(root.getObjectByName('fir-boughs'));
  assert.equal(layout.turns.length,6);assert.equal(layout.obstacles.length,7);
  const preview=makeCourseScene(courses.find(c=>c.id==='forest'),breeds[0],0);
  assert.equal(preview.children.filter(o=>o.name==='log').length,7);
  assert.equal(preview.children.filter(o=>o.name==='treat'&&o.position.y>.3).length,21);
  for(const log of layout.obstacles){
    assert(!cornerAt(log.s,TURN_WINDOW+2.1,6,layout.turns));
    const mesh=root.children.find(c=>c.name==='race-obstacle'&&c.userData.obstacleId===log.id), p=layout.point(log.s,log.lane*2);
    assert(Math.hypot(mesh.position.x-p.x,mesh.position.z-p.z)<1e-6);
    const arc=layout.treats.filter(t=>t.jumpLog===log.id);assert.equal(arc.length,3);
    for(const treat of arc){const m=new T.Matrix4();track.treatMesh.getMatrixAt(treat.id,m);const v=new T.Vector3().setFromMatrixPosition(m),location=layout.point(treat.s,log.lane*2);assert(Math.hypot(v.x-location.x,v.z-location.z)<.0001);assert(Math.abs(v.y-treat.y)<1e-5)}
  }
  const end=layout.point(layout.length),gate=root.getObjectByName('finish-gate');
  assert(Math.hypot(gate.position.x-end.x,gate.position.z-end.z)<1e-6);
  for(const object of [root,preview])object.traverse(o=>{if(o.geometry){assert(o.geometry.attributes.position.array.every(Number.isFinite));o.geometry.dispose();o.material.dispose()}});
});

test('forest rivals make the jump trail count in the final standings',()=>{
 for(const dt of [1/60,.05,.1]){
  const results=[];
  for(const followLogs of [false,true]){
   const sim=start('forest'),p=sim.player;
   for(let frame=0;frame<8000&&sim.status==='running';frame++){
    const cue=sim.turnCue;
    if(cue?.active&&!cue.armed)sim.input(cue.direction);
    const log=sim.layout.obstacles.find(o=>o.s>p.s-3&&o.s-p.s<13);
    const next=sim.layout.treats.find(t=>t.s>=p.s+1.5);
    const lane=followLogs?(log?.lane??next?.lane??0):0;
    if(!cue?.active&&p.lane!==lane)sim.input(p.lane<lane?'right':'left');
    if(sim.gauge===RACE.gaugeMax)sim.input('dash');
    const apex=RACE.jumpDuration/2+dt/2;
    const lead=p.speed*apex+(RACE.boostSpeed-p.speed)*Math.min(apex,p.boost);
    if(log&&p.lane===log.lane&&log.s>p.s&&log.s-p.s<lead)sim.input('jump');
    sim.step(dt);
   }
   assert.equal(sim.status,'finished');
   assert.equal(sim.result.turnMisses,0);assert.equal(sim.result.hits,0);
   results.push(sim.result);
  }
  const [centre,trail]=results;
  assert(centre.rank>1);assert.equal(trail.rank,1);
  assert(trail.time<centre.time);assert(trail.treats>centre.treats);
 }
});
````

### `tests/hill-field.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {A_FRAME, aFrameHeight, aFrameCameraLift} from '../dist/a-frame.js';
import {AgilitySimulation} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';

function start() {
  const sim = new AgilitySimulation('hill-field');
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}

test('all six hill obstacles are clearable at running speed with the two ramps scored on exit', () => {
  for (const dt of [1/120,1/60,.05,.1]) {
    const sim = start(), p = sim.player, climbed = new Set();
    for (let i=0; i<4000 && sim.status==='running'; i++) {
      const o = sim.nextObstacle;
      if (o && !sim.rampPass) {
        if (p.lane !== o.lane) sim.input(p.lane < o.lane ? 'right' : 'left');
        if (['hurdle','hoop'].includes(o.type) && o.s > p.s && o.s-p.s < 4.4) sim.input('jump');
      }
      sim.step(dt);
      if (sim.rampPass?.onBoard) {
        const ramp = sim.rampPass.obstacle;
        assert(!sim.results.has(ramp.id));
        assert.equal(p.surfaceY,aFrameHeight(p.s-ramp.s));
        if(p.y>A_FRAME.height-.32)climbed.add(ramp.id);
      }
    }
    assert.equal(sim.status,'finished');
    assert.equal(climbed.size,2);
    assert.deepEqual([sim.cleared,sim.faults,sim.result.penalty],[6,0,0]);
    assert.equal(sim.layout.treats.length,0);
  }
});

test('stopping on the slope keeps footing; menu pause freezes time; retry clears the ramp', () => {
  const sim=start(), p=sim.player;
  while(p.surfaceY<1)sim.step(.025);
  const position=[p.s,p.y,p.pitch],time=sim.time;
  assert(sim.input('brake'));assert(!sim.input('jump'));assert(!sim.input('right'));
  for(let i=0;i<20;i++)sim.step(.05);
  assert.deepEqual([p.s,p.y,p.pitch],position);
  assert(sim.time>time+.9);
  sim.pause();const paused=sim.time;sim.step(.1);assert.equal(sim.time,paused);
  sim.resume();assert(sim.input('dash'));
  while(!sim.results.has(0))sim.step(.05);
  assert(sim.results.get(0));assert.equal(p.y,0);assert.equal(p.pitch,0);
  sim.reset();assert.equal(sim.rampPass,null);assert.equal(sim.results.size,0);assert.equal(sim.player.y,0);
});

test('missing the entrance on the ground or airborne costs exactly one fault per ramp', () => {
  for(const action of ['left','jump']){
    const sim=start();
    if(action==='left')sim.input('left');
    while(sim.player.s<12)sim.step(.025);
    if(action==='jump')sim.input('jump');
    while(sim.player.s<28)sim.step(.025);
    assert.equal(sim.results.get(0),false);assert.equal(sim.faults,1);
    assert.equal(sim.player.surfaceY,0);assert.equal(sim.rampPass,null);
  }
});

test('both rigid ramp surfaces match the paws, and both next obstacles project into portrait and landscape views at the ridge', () => {
  const sim=start(), layout=sim.layout, arena=makeAgilityField(layout);
  arena.root.updateMatrixWorld(true);
  for(const ramp of layout.obstacles.filter(o=>o.type==='a-frame')){
    const group=arena.root.children.find(o=>o.name==='race-obstacle' && o.userData.obstacleId===ramp.id);
    const panels=group.children.filter(o=>o.name==='a-frame-panel');
    assert.equal(panels.length,4);
    for(const offset of [-4.6,-3.2,-1,0,1,3.2,4.6]){
      const p=layout.point(ramp.s+offset,ramp.lane*2);
      const pos=new T.Vector3(p.x,aFrameHeight(offset),p.z);
      assert(panels.some(panel=>{
        const local=panel.worldToLocal(pos.clone()),dims=panel.geometry.parameters;
        return Math.abs(local.y-dims.height/2)<1e-6 && Math.abs(local.z)<=dims.depth/2+1e-6;
      }));
    }
    const anchor=layout.point(ramp.s,ramp.lane*2), next=layout.obstacles[ramp.id+1];
    const target=layout.point(next.s,next.lane*2);
    const lift=aFrameCameraLift(A_FRAME.height);
    const pose=chaseCameraPose(anchor,{height:2.8+lift,lookHeight:1+.65*lift});
    for(const [w,h] of [[320,568],[390,844],[844,390]]){
      const camera=new T.PerspectiveCamera(w>h?54:60,w/h,.1,180);
      camera.position.copy(pose.position);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld(true);
      const screen=new T.Vector3(target.x,1,target.z).project(camera);
      assert(Math.abs(screen.x)<.9 && Math.abs(screen.y)<.9 && screen.z>0 && screen.z<1);
      const dog=new T.Vector3(anchor.x,A_FRAME.height+.7,anchor.z).project(camera);
      assert(Math.abs(dog.x)<1e-7 && Math.abs(dog.y)<1);
    }
  }
  arena.root.traverse(o=>{o.geometry?.dispose();o.material?.dispose()});
});

test('the ramp camera eases across both toes and the crest, at the same height on a stopped step',()=>{
  const liftAt = s => aFrameCameraLift(aFrameHeight(s));
  const ds = .01;
  for(const offset of [-A_FRAME.run,0,A_FRAME.run]){
    const fromLeft=(liftAt(offset)-liftAt(offset-ds))/ds;
    const toRight=(liftAt(offset+ds)-liftAt(offset))/ds;
    assert(Math.abs(fromLeft-toRight)<.01);
  }
  assert.equal(liftAt(-A_FRAME.run),0);
  assert(liftAt(0)>1.6 && liftAt(0)<A_FRAME.height);
  for(let i=0;i<48;i++)assert(liftAt(i/10)>=liftAt((i+1)/10));
});
````

### `tests/partner-park.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {parkBiscuitGeometry} from '../dist/park-biscuit.js';
import {makeShiba,poseShiba} from '../dist/shiba.js';
import {poseLegs} from '../dist/dog-gait.js';
import {RaceSimulation} from '../dist/race-sim.js';
import {routePoint} from '../dist/race-route.js';
import {makeParkCamera} from '../dist/park-camera.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {lastFrame,recordedKey} from '../dist/review/replay.js';

function sample(frame) {
  const actions={ArrowRight:'right',ArrowLeft:'left',ArrowDown:'brake',ArrowUp:'jump',' ':'dash'};
  const sim=new RaceSimulation();sim.start();
  for(let i=0;i<=frame;i++){
    const key=recordedKey(i);
    if(key)sim.input(actions[key]);
    sim.step(i===0?0:1/60);
  }
  return sim;
}
test('the Shiba plants both diagonal paws and can rest its face and tail with reduced motion',()=>{
  for(let coat=0;coat<3;coat++){
    const dog=makeShiba(coat);
    dog.scale.setScalar(.94);dog.rotation.set(0,Math.PI,.06,'YXZ');
    for(const phase of [.2,1,2.5,4.7]){
      poseLegs(dog,phase,true,false,()=>.015);dog.updateMatrixWorld(true);
      const heights=dog.userData.legs.map(leg=>leg.userData.paw.localToWorld(new T.Vector3(0,-1,0)).y);
      assert.equal(heights.filter(y=>Math.abs(y-.015)<1e-5).length,2);
      assert(heights.every(y=>y>.01499));
    }
    poseShiba(dog,3.61,true,false);assert(dog.userData.expression.eyes[0].scale.y<.15);
    poseShiba(dog,6,false,true);assert.equal(dog.userData.tail.rotation.y,0);
    assert.equal(dog.userData.expression.eyes[0].scale.y,1);
  }
});
test('the viewing frames show the first jump, turn, mid-course clipping location and final tunnel',()=>{
  const log=sample(lastFrame.log),turn=sample(lastFrame.turn);
  assert.equal(log.layout.obstacles[0].type,'hurdle');
  assert(log.layout.obstacles[0].s-log.player.s>6 && log.layout.obstacles[0].s-log.player.s<10);
  assert.equal(log.rank,5);assert.equal(log.cpus.length,4);
  assert.equal(turn.turnCue.direction,'right');assert.equal(turn.turnCue.active,true);
  const mid=sample(lastFrame.midpark),tunnel=sample(lastFrame.tunnel);
  assert(mid.player.s>237&&mid.player.s<239);
  const gate=tunnel.layout.obstacles.filter(o=>o.type==='tunnel').at(-1);
  assert(tunnel.player.s-gate.s>.9 && tunnel.player.s-gate.s<1.8);
  assert(Math.abs(tunnel.player.x-gate.lane*2)<.01);
});
test('all five bodies, the first log and the next biscuits project between the portrait HUD strips in the viewing frame',()=>{
  const sim=sample(lastFrame.log),anchor=routePoint(sim.player.s,sim.player.x);
  for(const [w,h] of [[320,568],[390,780],[390,844]]){
    const distance=Math.max(6,Math.min(8.65,3.58*h/w)),cp=chaseCameraPose(anchor,{distance});
    const cam=new T.PerspectiveCamera(60,w/h,.1,180);
    cam.position.set(cp.position.x,cp.position.y,cp.position.z);cam.lookAt(cp.target.x,cp.target.y,cp.target.z);cam.updateMatrixWorld();
    const points=[];
    for(const a of [sim.player,...sim.cpus])for(const dx of [-.38,.38])for(const y of [0,1.88]){
      const p=routePoint(a.s,a.x+dx);points.push(new T.Vector3(p.x,y,p.z+.4));
    }
    const gate=sim.layout.obstacles[0];
    for(const dx of [-.9,.9]){const p=routePoint(gate.s,dx);points.push(new T.Vector3(p.x,.39,p.z))}
    for(const t of sim.layout.treats.filter(t=>t.s>sim.player.s&&t.s<gate.s+3)){
      const p=routePoint(t.s,t.lane*2);points.push(new T.Vector3(p.x,t.y,p.z));
    }
    for(const point of points){const p=point.project(cam),pixelY=(1-p.y)*h/2;
      assert(Math.abs(p.x)<1);assert(pixelY>110&&pixelY<h-60);
    }
  }
});

test('distant hills clear the three lanes and the chase-camera sweep throughout the folded park',()=>{
  const track=makeRaceTrack(new RaceSimulation().layout);
  const hills=track.root.getObjectByName('far-hills');
  hills.updateMatrixWorld();
  const ray=new T.Raycaster(),down=new T.Vector3(0,-1,0);
  for(let s=0;s<=480;s+=.5){
    for(const lane of [-2,0,2]){
      const path=routePoint(s,lane),camera=chaseCameraPose(path,{distance:8.65}).position;
      for(const p of [path,camera]){
        ray.set(new T.Vector3(p.x,35,p.z),down);
        assert(!ray.intersectObject(hills).some(hit=>hit.point.y>0),'hill above course at '+s);
      }
    }
  }
});

test('park tunnels retain their opaque roof as the camera and dog enter and leave through the two open ends',()=>{
  const sim=new RaceSimulation(),track=makeRaceTrack(sim.layout),ray=new T.Raycaster();
  track.root.updateMatrixWorld(true);
  for(const gate of sim.layout.obstacles.filter(o=>o.type==='tunnel')){
    const group=track.root.children.find(child=>child.name==='race-obstacle'&&child.userData.obstacleId===gate.id);
    const surfaces=group.getObjectByName('park-tunnel').children;
    const panels=surfaces.filter(o=>o.name==='tunnel-fabric');
    assert.equal(panels.length,1);
    const sleeve=panels[0], localRay=new T.Raycaster();
    const start=new T.Vector3(), direction=new T.Vector3();
    // Sample both hems at ankle height all the way to the mouths.
    for(const z of [-3.78,-3,-1.5,0,1.5,3,3.78])for(const side of [-1,1]){
      sleeve.parent.localToWorld(start.set(0,.07,z));
      direction.set(side,0,0).transformDirection(sleeve.parent.matrixWorld);
      localRay.set(start,direction);
      const hit=localRay.intersectObject(sleeve)[0];
      assert(hit && Math.abs(hit.distance-1.70)<.03,'side opening at '+z);
    }
    sleeve.parent.localToWorld(start.set(0,0,0));localRay.set(start,direction.set(0,1,0));
    const rise=localRay.intersectObject(sleeve)[0].distance;
    assert(rise/1.70>=1 && rise/1.70<=1.12,'arched profile relative to the original semicircle');
    assert(surfaces.every(o=>o.visible&&o.material.opacity===1&&!o.material.transparent));
    for(const [w,h] of [[320,568],[393,639],[390,780],[390,844],[844,390]]){
      const base=Math.max(6,Math.min(8.65,3.58*h/w));
      for(const offset of [-.52,0,.52]){
        const follow=makeParkCamera(sim.layout.obstacles);
        let shared=0;
        for(let s=gate.s-25;s<=gate.s+26;s+=.20){
          const x=gate.lane*2+offset,pose=follow({s,x},base,2.8);
          const from=new T.Vector3().copy(pose.position);
          const cam=new T.PerspectiveCamera(w>h?54:60,w/h,.1,180);
          cam.position.copy(from);cam.lookAt(new T.Vector3().copy(pose.target));cam.updateMatrixWorld();
          for(const [y,dz] of [[.10,-.35],[.80,-.5],[1.40,.35]]){
            const point=routePoint(s+dz,x),target=new T.Vector3(point.x,y,point.z);
            const dir=target.clone().sub(from);ray.far=dir.length();ray.set(from,dir.normalize());
            assert.equal(ray.intersectObjects(surfaces,false).length,0,'blocked at '+s);
            const screen=target.project(cam);
            const pixelY=(1-screen.y)*h/2;
            assert(Math.abs(screen.x)<.01&&pixelY>60&&pixelY<h-58,'the dog overlaps the HUD at '+s);
          }
          ray.far=8;
          const dog=routePoint(s,x);
          const roofAt=(x,y,z)=>{ray.set(new T.Vector3(x,y,z),new T.Vector3(0,1,0));return ray.intersectObjects(panels).length>0};
          if(roofAt(from.x,from.y,from.z)&&roofAt(dog.x,1.40,dog.z)){
            shared+=.20;
            const exit=routePoint(gate.s+7,gate.lane*2),target=new T.Vector3(exit.x,1.0,exit.z);
            const dir=target.clone().sub(from);ray.far=dir.length();ray.set(from,dir.normalize());
            assert.equal(ray.intersectObjects(surfaces).length,0);
          }
        }
        assert(shared>2.5,'dog and camera must travel together inside the shorter sleeve');
      }
    }
  }
});

test('the park camera can bypass a tunnel, follow a late exit swipe, then restart on the normal chase view',()=>{
  const sim=new RaceSimulation(),gate=sim.layout.obstacles.filter(o=>o.type==='tunnel').at(-1);
  const follow=makeParkCamera(sim.layout.obstacles),distance=7.16;
  for(let s=gate.s-28;s<gate.s+25;s+=.2){
    const pose=follow({s,x:2},distance,2.8);
    assert.deepEqual(pose,chaseCameraPose(routePoint(s,2),{distance}));
  }
  const track=makeRaceTrack(sim.layout);
  track.root.updateMatrixWorld(true);
  const group=track.root.children.find(o=>o.name==='race-obstacle'&&o.userData.obstacleId===gate.id);
  const surfaces=group.getObjectByName('park-tunnel').children;
  const ray=new T.Raycaster();
  for(const speed of [6.05,9.6,16.2])for(const side of [-1,1]){
    for(let s=gate.s-26;s<gate.s+23;s+=.10){
      const lateral=s<gate.s+3.4?0:side*2*(1-Math.exp(-13*(s-gate.s-3.4)/speed));
      const pose=follow({s,x:lateral},distance,2.8),point=routePoint(s,lateral);
      const from=new T.Vector3().copy(pose.position);
      for(const location of [pose.position,pose.target]){
        const dx=location.x-point.x,dz=location.z-point.z;
        assert(Math.abs(dx*Math.cos(point.heading)+dz*Math.sin(point.heading))<1e-8);
      }
      for(const [height,lead] of [[.10,-.25],[.75,0],[1.32,.25]]){
        const dog=routePoint(s+lead,lateral);
        const dir=new T.Vector3(dog.x,height,dog.z).sub(from);
        ray.far=dir.length();ray.set(from,dir.normalize());
        assert.equal(ray.intersectObjects(surfaces).length,0,'exit swipe at '+s);
      }
    }
  }
  assert.deepEqual(follow({s:0,x:0},distance,2.8),chaseCameraPose(routePoint(0),{distance}));
});

test('every frame of the close-up lane changes shares the dog’s lateral anchor and the road heading',()=>{
  const sim=new RaceSimulation(),follow=makeParkCamera(sim.layout.obstacles);
  const inputs={ArrowRight:'right',ArrowLeft:'left',ArrowDown:'brake',ArrowUp:'jump',' ':'dash'};
  sim.start();
  for(let frame=0;frame<=2320;frame++){
    const key=recordedKey(frame,'swipe');
    if(key)sim.input(inputs[key]);
    sim.step(frame?1/60:0);
    const p=sim.player,anchor=routePoint(p.s,p.x),pose=follow(p,6.05,2.8);
    const side=new T.Vector2(Math.cos(anchor.heading),Math.sin(anchor.heading));
    const forward=new T.Vector2(side.y,-side.x);
    const offset=point=>new T.Vector2(point.x-anchor.x,point.z-anchor.z);
    const rear=offset(pose.position),aim=offset(pose.target);
    assert(Math.abs(rear.dot(side))<1e-8 && Math.abs(aim.dot(side))<1e-8,'camera turned during frame '+frame);
    assert(rear.dot(forward)<0 && aim.dot(forward)>0);
    if(frame===lastFrame.swipe)assert(p.x < -1.6 && p.x > -1.9);
    if(frame===2300)assert(p.x>1.7);
  }
});

test('the baked bone has a broad waist, a notch at each end and a shallow impression in its front face',()=>{
  const geo=parkBiscuitGeometry();geo.rotateX(.38);geo.rotateZ(-.22);
  const biscuit=new T.Mesh(geo,new T.MeshBasicMaterial());
  const ray=new T.Raycaster(),forward=new T.Vector3(0,0,-1);
  function faceAt(x,y){
    ray.set(new T.Vector3(x,y,1),forward);
    return ray.intersectObject(biscuit)[0]?.point.z;
  }
  assert(faceAt(0,.08)>.05);
  assert(Math.abs(faceAt(0,-.027)-.038)<.0001);
  for(const x of [-.325,.325]){
    assert.equal(faceAt(x,0),undefined);
    assert(faceAt(x,.095)>0 && faceAt(x,-.095)>0);
  }
  geo.computeBoundingBox();
  assert(geo.boundingBox.max.z-geo.boundingBox.min.z<.12);
});
````

### `tests/polish.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {breeds} from '../dist/breeds.js';
import {makeDog} from '../dist/dog-model.js';
import {footingFor, poseLegs} from '../dist/dog-gait.js';
import {A_FRAME, aFrameHeight, aFramePitch} from '../dist/a-frame.js';
import {SEESAW, seesawSurface} from '../dist/seesaw.js';
import {AgilitySimulation} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {addTunnel} from '../dist/tunnel.js';

const sole = new T.Vector3();
function clearances(dog, support) {
  dog.updateMatrixWorld(true);
  return dog.userData.legs.map(leg => {
    leg.userData.paw.localToWorld(sole.set(0, -1, 0));
    return sole.y - support(-sole.z);
  });
}
function checkContact(dog, support, running) {
  const gaps = clearances(dog, support);
  assert(Math.min(...gaps) > -.00001, 'sole below surface');
  assert(gaps.filter(gap => Math.abs(gap) < .00001).length >= (running ? 2 : 4));
}

test('all 24 coats plant the diagonal stance pair and lift the opposite paws, including on a banked turn', () => {
  const flat = () => .015;
  for (const breed of breeds) for (const index of breed.coats.keys()) {
    const dog = makeDog(breed, index);
    dog.scale.setScalar(.76);
    dog.rotation.set(0, Math.PI, .16, 'YXZ');
    for (let frame = 0; frame < 32; frame++) {
      const phase = frame / 8;
      dog.position.y = .025 * Math.abs(Math.cos(phase * 1.85));
      poseLegs(dog, phase, true, false, flat);
      checkContact(dog, flat, true);
    }
    poseLegs(dog, 0, true, false, flat);
    assert(Math.max(...clearances(dog, flat)) > .08);
    poseLegs(dog, 1, false, false, flat);
    checkContact(dog, flat, false);
    dog.position.y = 1;
    poseLegs(dog, 1, true, true, () => { throw Error('airborne dog sampled the ground'); });
    assert(Math.min(...clearances(dog, flat)) > .85);
    assert(dog.userData.legs[0].rotation.x * dog.userData.legs[1].rotation.x < 0);
  }
});

test('paws follow each panel at the ridge, the toes of the A-frame, and the rotating seesaw', () => {
  const dog = makeDog(breeds[3], 0), scale = .76;
  dog.scale.setScalar(scale);
  for (const course of ['hill-field', 'balance']) {
    const sim = new AgilitySimulation(course), ramp = course === 'hill-field';
    const obstacle = sim.layout.obstacles.find(o => o.type === (ramp ? 'a-frame' : 'seesaw'));
    const angles = ramp ? [0] : [-SEESAW.angle, 0, SEESAW.angle];
    for (const angle of angles) {
      const end = ramp ? A_FRAME.run : SEESAW.length / 2 * Math.cos(angle);
      const surface = offset => Math.abs(offset) > end ? -.035 :
        ramp ? aFrameHeight(offset) : seesawSurface(offset, angle);
      if (!ramp) sim.seesaws.get(obstacle.id).angle = angle;
      for (const distance of [-end - .1, -end + .15, -1, -.17, 0, .23, 1, end - .15, end + .1]) {
        sim.player.s = obstacle.s + distance;
        sim.player.x = obstacle.lane * 2;
        dog.position.y = surface(distance);
        dog.rotation.set(ramp ? aFramePitch(distance) : -angle, Math.PI, .06, 'YXZ');
        const support = ahead => surface(distance + ahead);
        for (const running of [false, true]) {
          poseLegs(dog, .45, running, false, footingFor(sim, true));
          checkContact(dog, support, running);
        }
      }
    }
  }
});

test('tunnel walls are continuous with an open entrance and exit, and the seesaw axle passes through its pivot', () => {
  for (const [radius, length] of [[1.58, 6], [.43, 1.16]]) {
    const root = new T.Group();
    addTunnel(root, (geo, color, x, y, z, parent) => {
      const part = new T.Mesh(geo, new T.MeshBasicMaterial({color}));
      part.position.set(x, y, z); parent.add(part); return part;
    }, radius, length);
    root.updateMatrixWorld(true);
    const cast = (x,y,z,dx,dy,dz) => new T.Raycaster(new T.Vector3(x,y,z), new T.Vector3(dx,dy,dz)).intersectObject(root,true);
    assert.equal(cast(0,.45*radius,-length,0,0,1).length, 0);
    assert.equal(root.children.filter(c => c.name === 'tunnel-rim').length, 2);
    for (const z of [-.46,-.3,-.1,.1,.3,.46]) {
      assert(cast(0, radius*.45, length*z, .6,.8,0).some(hit => hit.object.name === 'tunnel-fabric'));
    }
  }
  const field = makeAgilityField(new AgilitySimulation('balance').layout);
  for (const group of field.root.children.filter(c => c.getObjectByName('rigid-plank'))) {
    assert(group.getObjectByName('rigid-plank').position.equals(group.getObjectByName('seesaw-axle').position));
  }
});
````

### `tests/race-sim.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import {RaceSimulation,RACE,buildParkRace,gestureAction} from '../dist/race-sim.js';
const running=()=>{const s=new RaceSimulation();s.start();for(let i=0;i<181;i++)s.step(1/60);assert.equal(s.status,'running');return s};
const advance=(s,seconds,dt=1/60)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
test('countdown and hidden-page pause never advance race time or distance',()=>{const s=new RaceSimulation();s.start();s.step(.05);s.pause();const count=s.countdown;advance(s,3);assert.equal(s.countdown,count);assert.equal(s.time,0);s.resume();advance(s,3.1);assert.equal(s.status,'running');s.pause();const distance=s.player.s,time=s.time;advance(s,10);assert.equal(s.player.s,distance);assert.equal(s.time,time);assert.equal(s.input('dash'),false);s.resume();s.step(.02);assert(s.player.s>distance)});
test('full gauge waits for a tap; one activation lasts three seconds',()=>{const s=running();s.gauge=20;advance(s,.2);assert.equal(s.player.boost,0);assert.equal(s.dashCount,0);assert(s.input('dash'));assert.equal(s.gauge,0);assert.equal(s.player.boost,3);assert.equal(s.dashCount,1);s.gauge=20;assert.equal(s.input('dash'),false);advance(s,3.1);assert.equal(s.player.boost,0);assert.equal(s.dashCount,1);assert(s.input('dash'))});
test('hurdle collisions occur once, and a sufficiently high jump clears the bar',()=>{const hit=running(),o=hit.layout.obstacles[0];hit.player.s=o.s-.1;hit.player.x=o.lane*2;hit.player.lane=o.lane;hit.step(.03);assert.equal(hit.player.hits,1);advance(hit,.4);assert.equal(hit.player.hits,1);assert(hit.player.slow>0);const clear=running();clear.player.s=o.s-4.1;clear.player.x=o.lane*2;clear.player.lane=o.lane;assert(clear.input('jump'));assert.equal(clear.input('jump'),false);advance(clear,.6);assert(clear.player.s>o.s);assert.equal(clear.player.hits,0)});
test('hurdle treats are above the obstacle; tunnel treats stay at running height',()=>{const {treats,obstacles}=buildParkRace();assert(treats.length>150);for(const o of obstacles){const close=treats.filter(t=>Math.abs(t.s-o.s)<1.2);assert(close.length>0);for(const t of close){assert.equal(t.lane,o.lane);if(o.type==='hurdle')assert(t.y>1.45);else assert.equal(t.y,.65)}}});
test('one treat is collected once and gauge is capped',()=>{const s=running(),t=s.layout.treats[0];s.player.s=t.s-.2;s.player.lane=t.lane;s.player.x=t.lane*2;s.gauge=20;s.step(.02);assert.equal(s.treatCount,1);assert.equal(s.gauge,20);advance(s,.1);assert.equal(s.treatCount,1)});
test('lane bounds, tunnel entry and gesture cancellation thresholds',()=>{const s=running();for(let i=0;i<9;i++)s.input('left');assert.equal(s.player.lane,-1);for(let i=0;i<9;i++)s.input('right');assert.equal(s.player.lane,1);const o=s.layout.obstacles.find(o=>o.type==='tunnel');s.player.s=o.s;s.player.lane=o.lane;s.player.x=o.lane*2;assert.equal(s.input('jump'),false);assert.equal(s.input('left'),true);assert.equal(gestureAction(0,-35,150),'jump');assert.equal(gestureAction(36,2,100),'right');assert.equal(gestureAction(0,35,100),'brake');assert.equal(gestureAction(3,4,130),'dash');assert.equal(gestureAction(15,0,100),null);assert.equal(gestureAction(0,0,800),null)});
test('race finishes with real CPU ranking and reset clears all session state',()=>{const s=running();for(let i=0;i<6000&&s.status==='running';i++){const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);s.step(1/60)}assert.equal(s.status,'finished');assert(s.result.time>30&&s.result.time<90);assert(s.result.rank>=1&&s.result.rank<=5);const time=s.time;advance(s,5);assert.equal(s.time,time);s.reset();assert.equal(s.status,'ready');assert.equal(s.collected.size,0);assert.equal(s.time,0);assert.equal(s.player.hits,0);assert.equal(s.result,null)});
test('good lane choices, jumps and manual boosts can beat the CPUs',()=>{const s=running();for(let i=0;i<7000&&s.status==='running';i++){const p=s.player;const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);const next=s.layout.treats.find(t=>!s.collected.has(t.id)&&t.s>p.s+.3);const obstacle=s.layout.obstacles.find(o=>o.s>p.s&&o.s-p.s<7);
 const lane=obstacle?obstacle.lane:next?.lane??0;if(lane<p.lane)s.input('left');if(lane>p.lane)s.input('right');if(obstacle?.type==='hurdle'&&obstacle.s-p.s<(p.boost>0?6:4.3)&&p.jumpElapsed===null)s.input('jump');if(s.gauge===20)s.input('dash');s.step(1/60)}assert.equal(s.status,'finished');assert(s.result.treats>=60);assert(s.result.dashes>=3);assert.equal(s.result.rank,1)});

test('a quick short flick needs a clear axis and remains separate from a tap',()=>{
 for(const [dx,dy,action] of [[20,5,'right'],[-22,9,'left'],[3,-21,'jump'],[4,22,'brake']]){
  assert.equal(gestureAction(dx,dy,140,true),action);
  assert.equal(gestureAction(dx,dy,260,true),null);
  assert.equal(gestureAction(dx,dy,140),null);
 }
 assert.equal(gestureAction(19,1,80,true),null);
 assert.equal(gestureAction(20,19,100,true),null);
 assert.equal(gestureAction(1,2,200,true),'dash');
 assert.equal(gestureAction(1,2,400,true),null);
 assert.equal(gestureAction(32,5,450,true),'right');
});

test('park tunnel side walls block swipes on either side and apply the normal obstacle penalty once',()=>{
 for(const hz of [10,30,60,120])for(const side of [-1,1]){
  for(const gate of buildParkRace().obstacles.filter(o=>o.type==='tunnel')){
   const sim=running(),p=sim.player,center=gate.lane*RACE.lanewidth;
   Object.assign(p,{s:gate.s-3.8,x:center,lane:gate.lane});
   assert(sim.input(side<0?'left':'right'));
   while(!p.hits && p.s<gate.s+2.55)sim.step(1/hz);
   assert.equal(p.hits,1);assert.equal(p.slow,1.15);
   assert.equal(p.lane,gate.lane);assert(Math.abs(p.x-center)<1.3);
   assert.equal(sim.drainEvents().filter(e=>e.reason==='tunnel-wall').length,1);
   const hitAt=p.s;
   sim.step(1/hz);
   assert(Math.abs(p.s-hitAt-p.speed*.43/hz)<1e-8);
   for(let i=0;i<Math.ceil(.3*hz);i++){
    sim.input(side<0?'left':'right');sim.step(1/hz);
    assert(Math.abs(p.x-center)<1.3);
   }
   assert.equal(p.hits,1);
   sim.reset();assert.equal(sim.player.hits,0);
  }
 }
});

test('park tunnel geometry allows a straight run and an outside bypass, but blocks cutting through the fabric',()=>{
 const gate=buildParkRace().obstacles.filter(o=>o.type==='tunnel').at(-1);
 for(const lane of [-1,0,1]){
  const sim=running(),p=sim.player;
  Object.assign(p,{s:gate.s-6.5,x:lane*2,lane});
  while(p.s<gate.s+2.6)sim.step(.05);
  assert.equal(p.hits,0);
  sim.input(lane===1?'left':'right');advance(sim,.25);
  assert.equal(p.hits,0);
 }
 for(const side of [-1,1]){
  const sim=running(),p=sim.player;
  Object.assign(p,{s:gate.s-1,x:side*2,lane:side,boost:2});
  sim.layout.treats=[{id:999,s:gate.s+.56,lane:0,y:.65}];
  sim.input(side<0?'right':'left');sim.step(.1);
  assert.equal(sim.treatCount,0,'a pickup across the wall is out of reach');
  assert.equal(p.hits,1);assert.equal(p.lane,side);assert(Math.abs(p.x)>1.9);
 }
});

test('all five results use finish-line crossing times even when the player wins', () => {
 const dt=1/60;
 for(const id of ['park','beach','forest']){
  const leader=new RaceSimulation(id), spectator=new RaceSimulation(id);
  leader.start();spectator.start();
  // The second player waits at a turn while the four identical rivals run to the finish.
  // Move the first player close to the finish to exercise rivals still racing behind it.
  leader.player.s=leader.layout.length-2;
  for(let i=0;i<9000&&spectator.cpus.some(dog=>dog.finishTime===null);i++){
   if(leader.status!=='finished')leader.step(dt);
   spectator.step(dt);
  }
  const expected=[{id:'player',time:leader.player.finishTime},...spectator.cpus.map(({id,finishTime})=>({id,time:finishTime}))].sort((a,b)=>a.time-b.time);
  assert.equal(leader.result.rank,1);
  assert(expected.every(dog=>dog.time>0));
  assert.deepEqual(leader.result.standings,expected);
  assert(leader.cpus.every(dog=>dog.finishTime===null));
 }
});
````

### `tests/race-turns.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation,RACE,buildParkRace} from '../dist/race-sim.js';
import {PARK_TURNS,TURN_WINDOW,cornerAt,routePoint} from '../dist/race-route.js';
import {makeRaceTrack,roadRibbon} from '../dist/race-track.js';
const close=(a,b,e=1e-5)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
const run=()=>{const s=new RaceSimulation();s.start();for(let i=0;i<61;i++)s.step(.05);return s};
const advance=(s,seconds,dt=.02)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
test('four real 90-degree bends have continuous positions, tangents and lane spacing',()=>{
 assert.deepEqual(PARK_TURNS.map(t=>t.direction),['right','left','left','right']);
 for(const t of PARK_TURNS){
  const a=routePoint(t.start),b=routePoint(t.end);close(b.heading-a.heading,(t.direction==='right'?1:-1)*Math.PI/2);
  for(const at of [t.start,t.end]){const before=routePoint(at-.000001),after=routePoint(at+.000001);assert(Math.hypot(after.x-before.x,after.z-before.z)<.000003);assert(Math.abs(after.heading-before.heading)<.000001)}
 }
 for(let s=-10;s<=510;s+=.75){const p=routePoint(s),right=routePoint(s,2),left=routePoint(s,-2);close(Math.hypot(right.x-left.x,right.z-left.z),4);assert([p.x,p.z,p.heading].every(Number.isFinite))}
 assert(Math.abs(routePoint(160).x)>50,'course must move in world X, not just sway the camera');
});
test('straight swipes move lanes; early directional swipes queue one turn without lane changes',()=>{
 const s=run(),t=PARK_TURNS[0];assert(s.input('right'));assert.equal(s.player.lane,1);
 s.player.s=t.start-TURN_WINDOW-.1;assert(s.input('left'));assert.equal(s.player.lane,0);assert(!s.armedTurns.has(t.id));
 s.player.s=t.start-TURN_WINDOW;assert.equal(s.input('left'),false);assert.equal(s.player.lane,0);assert(s.input('right'));assert(s.armedTurns.has(t.id));assert.equal(s.input('right'),false);
 advance(s,4.1);assert(s.player.s>t.end);assert.equal(s.passedTurns.size,1);assert.equal(s.missedTurns.size,0);assert(s.input('left'));assert.equal(s.player.lane,-1);
});
test('missing a turn stops at the corner while CPU racers continue; correct swipe resumes',()=>{
 const s=run(),t=PARK_TURNS[0];s.player.s=t.start-.2;advance(s,.1);close(s.player.s,t.start);assert.equal(s.waitingTurn,t.id);
 const cpu=s.cpus[0].s;advance(s,2);close(s.player.s,t.start);assert(s.cpus[0].s>cpu);assert.equal(s.missedTurns.size,1);
 assert.equal(s.input('left'),false);assert.equal(s.input('jump'),false);s.gauge=20;assert.equal(s.input('dash'),false);assert.equal(s.gauge,20);
 assert(s.input('right'));assert.equal(s.waitingTurn,null);advance(s,.2);assert(s.player.s>t.start);
 assert.equal(s.drainEvents().filter(e=>e.type==='turn-missed').length,1);
});
test('each direction is required independently; turn state survives pause and clears on retry',()=>{
 const s=run();for(const t of PARK_TURNS){s.player.s=t.start-2;assert.equal(s.input(t.direction==='right'?'left':'right'),false);assert(s.input(t.direction));s.pause();const d=s.player.s;advance(s,2);assert.equal(s.player.s,d);assert(s.armedTurns.has(t.id));s.resume();advance(s,2);assert(s.passedTurns.has(t.id))}
 assert.equal(s.passedTurns.size,4);s.reset();assert.equal(s.armedTurns.size,0);assert.equal(s.passedTurns.size,0);assert.equal(s.missedTurns.size,0);assert.equal(s.waitingTurn,null);
});
test('dash cannot skip unconfirmed turns, including large supported frame steps',()=>{
 for(const dt of [1/120,1/60,.05,.1]){const s=run(),t=PARK_TURNS[0];s.player.s=t.start-.05;s.gauge=20;s.input('dash');s.step(dt);close(s.player.s,t.start);assert.equal(s.waitingTurn,t.id);assert(s.input(t.direction));advance(s,1.2,dt);assert(s.player.s>t.end);assert.equal(s.passedTurns.size,1)}
});
test('turn approaches have no obstacles and the treat trail follows the middle of each corner',()=>{
 const {obstacles,treats}=buildParkRace();assert(obstacles.some(o=>o.type==='tunnel'));assert(obstacles.some(o=>o.type==='hurdle'));
 for(const o of obstacles)assert(!cornerAt(o.s,TURN_WINDOW+6,9));
 for(const t of PARK_TURNS){const inside=treats.filter(b=>b.s>=t.start&&b.s<=t.end);assert(inside.length>=6);assert(inside.every(b=>b.lane===0&&b.y===.65))}
});
test('rendered road, obstacles, treats and finish gate share the physics route',()=>{
 const layout=buildParkRace(),track=makeRaceTrack(layout),root=track.root;root.updateMatrixWorld(true);
 const ribbon=roadRibbon(0,7.6,.015);for(const y of ribbon.attributes.normal.array.filter((_,i)=>i%3===1))assert(y>.99);
 root.traverse(o=>{if(o.geometry)assert(o.geometry.attributes.position.array.every(Number.isFinite));if(o.name==='race-obstacle'){const ob=layout.obstacles.find(x=>x.id===o.userData.obstacleId),p=routePoint(ob.s,ob.lane*2);close(o.position.x,p.x);close(o.position.z,p.z);close(o.rotation.y,-p.heading)}});
 const matrix=new T.Matrix4(),v=new T.Vector3();for(const t of layout.treats){track.treatMesh.getMatrixAt(t.id,matrix);v.setFromMatrixPosition(matrix);const p=routePoint(t.s,t.lane*2);close(v.x,p.x,.0001);close(v.z,p.z,.0001);close(v.y,t.y,.0001)}
 const end=routePoint(RACE.length),gate=root.getObjectByName('finish-gate');close(gate.position.x,end.x);close(gate.position.z,end.z);
 track.collectTreat(0);track.treatMesh.getMatrixAt(0,matrix);assert.equal(matrix.elements[0],0);track.resetTreats();track.treatMesh.getMatrixAt(0,matrix);assert.equal(matrix.elements[0],1);
 const geometries=new Set(),materials=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());ribbon.dispose();
});
````

### `tests/scarf-colors.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import {breeds} from '../dist/breeds.js';
import {scarfOption,scarfOptions} from '../dist/scarf-colors.js';
import {makeCompanion} from '../dist/companions.js';

test('only the six named colors are offered and legacy automatic preferences resolve to blue',()=>{
  assert.deepEqual(scarfOptions.map(o=>o.id),['blue','red','yellow','green','purple','pink']);
  for(const id of [undefined,'auto',null,'outdated'])assert.equal(scarfOption(id).id,'blue');
  for(const option of scarfOptions)assert.equal(scarfOption(option.id),option);
});

test('explicit colors cover both cloth and knot',()=>{
  for(const breed of breeds){
    for(const choice of scarfOptions){
      const dog=makeCompanion(breed,1,choice.color);
      const scarf=dog.getObjectByName('neck-scarf');
      assert(scarf.getObjectByName('scarf-band')&&scarf.getObjectByName('scarf-knot'));
      scarf.traverse(part=>{
        if(part.isMesh)assert.equal('#'+part.material.color.getHexString(),choice.color);
      });
    }
  }
});
````

### `tests/zigzag.test.mjs`

````javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {AgilitySimulation,AGILITY,buildAgilityCourse} from '../dist/agility-sim.js';
import {SLALOM,slalomPoleS,slalomSide,slalomStart,slalomEnd} from '../dist/slalom.js';
import {FIELD_SEGMENTS} from '../dist/agility-route.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
const advance=(s,seconds,dt=1/60)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
const running=()=>{const s=new AgilitySimulation('zigzag');s.start();advance(s,3.1);return s};
const enter=()=>{const sim=running(),obstacle=sim.layout.obstacles[1];sim.player.s=slalomStart(obstacle)+.1;return {sim,obstacle}};
test('a single swipe targets either slalom side; repeated swipes do not move out of the row',()=>{
 const {sim,obstacle}=enter();sim.input('left');advance(sim,.25);assert(sim.player.x<-.85);sim.input('right');advance(sim,.3);assert(sim.player.x>.85);assert.equal(sim.player.lane,obstacle.lane);
 for(let i=0;i<6;i++)sim.input('right');assert.equal(sim.targetX,SLALOM.offset);assert.equal(sim.input('jump'),false);assert.equal(sim.input('dash'),false);
 sim.input('brake');const s=sim.player.s,time=sim.time,index=sim.activeSlalom.state.index;advance(sim,1);assert.equal(sim.player.s,s);assert(sim.time>time+.9);assert.equal(sim.activeSlalom.state.index,index);sim.pause();const t=sim.time;advance(sim,1);assert.equal(sim.time,t);assert.equal(sim.input('left'),false);sim.resume();assert(sim.stopped);assert(sim.input('dash'));advance(sim,.1);assert(sim.player.s>s);
});
test('both six-pole rows can be cleared in order in a full run, including varied frame times',()=>{
 for(const dt of [1/120,1/60,.05,.1]){
  const sim=running();for(let frame=0;frame<7000&&sim.status==='running';frame++){
   const p=sim.player,o=sim.nextObstacle,slalom=sim.activeSlalom;
   if(slalom){if(slalom.state.index<SLALOM.count)sim.input(slalomSide(o,slalom.state.index)<0?'left':'right')}
   else if(o){if(o.lane<p.lane)sim.input('left');if(o.lane>p.lane)sim.input('right');if(['hoop','hurdle'].includes(o.type)&&o.s-p.s<3.8&&o.s>p.s&&p.jumpElapsed===null)sim.input('jump')}
   sim.step(dt);
  }
  assert.equal(sim.status,'finished');assert.equal(sim.cleared,6);assert.equal(sim.faults,0);assert.equal(sim.result.total,sim.result.time);assert([...sim.slaloms.values()].every(s=>s.passed.length===6&&s.passed.every(Boolean)));assert.equal(sim.layout.treats.length,0);assert.equal(sim.cpus.length,0);
  sim.reset();assert.equal(sim.results.size,0);assert.equal(sim.activeSlalom,null);assert([...sim.slaloms.values()].every(s=>s.index===0&&s.side===0&&s.passed.length===0&&!s.failed));
 }
});
test('wrong side, centre-line running and outside bypass all add only one fault per row',()=>{
 for(const strategy of ['centre','one-side','outside']){
  const {sim,obstacle}=enter();if(strategy==='one-side')sim.input('left');
  for(let i=0;i<500&&!sim.results.has(obstacle.id);i++){if(strategy==='outside')sim.player.x=3;sim.step(1/60)}
  const state=sim.slaloms.get(obstacle.id);assert.equal(state.index,6);assert(state.failed);assert.equal(sim.results.get(obstacle.id),false);assert.equal(sim.faults,1);assert.equal(sim.player.hits,1);advance(sim,.5);assert.equal(sim.faults,1);
 }
});
test('a late swipe is judged at the pole crossing rather than the end of the frame',()=>{
 const {sim,obstacle}=enter();sim.player.s=slalomPoleS(obstacle,0)-.01;sim.player.x=.9;sim.input('left');sim.step(.1);assert.equal(sim.slaloms.get(obstacle.id).passed[0],false);assert(sim.player.x<0,'end-of-frame position alone would allow the wrong side');
});
test('a jump started before entry cannot skip the first pole; row exit restores normal speed and lane input',()=>{
 const {sim,obstacle}=enter();sim.player.s=slalomStart(obstacle)-.05;assert(sim.input('jump'));advance(sim,.02);assert.equal(sim.input('jump'),false);sim.input('left');
 while(sim.slaloms.get(obstacle.id).index===0)sim.step(1/60);assert.equal(sim.slaloms.get(obstacle.id).passed[0],false);
 while(sim.player.s<=slalomEnd(obstacle)+1)sim.step(1/60);assert.equal(sim.activeSlalom,null);sim.player.slow=0;const s=sim.player.s;advance(sim,.1);assert(Math.abs(sim.player.s-s-AGILITY.speed*.1)<1e-8);sim.input('right');assert.equal(sim.player.lane,1);assert.equal(sim.targetX,2);
});
test('poles align with the scoring gates, target follows the next side, and camera stays centred',()=>{
 const sim=new AgilitySimulation('zigzag'),field=makeAgilityField(sim.layout);field.root.updateMatrixWorld(true);const poles=[];field.root.traverse(o=>{if(o.name==='slalom-pole')poles.push(o)});assert.equal(poles.length,12);
 for(const pole of poles){const o=sim.layout.obstacles.find(o=>o.id===pole.userData.obstacleId),s=slalomPoleS(o,pole.userData.poleIndex),expected=sim.layout.point(s,o.lane*2),world=pole.getWorldPosition(new T.Vector3()),seg=FIELD_SEGMENTS.find(t=>s>=t.start&&s<=t.end);assert.equal(seg.turn,0);assert(Math.abs(world.x-expected.x)<1e-8);assert(Math.abs(world.z-expected.z)<1e-8)}
 sim.results.set(0,true);const o=sim.nextObstacle,state=sim.slaloms.get(o.id),marker=field.root.getObjectByName('next-obstacle-marker');
 for(let i=0;i<6;i++){field.update(sim);const p=sim.layout.point(slalomPoleS(o,i),o.lane*2+slalomSide(o,i)*SLALOM.offset);assert(marker.visible);assert(Math.abs(marker.position.x-p.x)<1e-9);assert(Math.abs(marker.position.z-p.z)<1e-9);state.index++;state.passed.push(true)}field.update(sim);assert(!marker.visible);
 for(const aspect of [390/844,844/390]){let baseline;const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);for(let s=slalomStart(o);s<=slalomEnd(o);s+=.2){const p=sim.layout.point(s,Math.sin(s*2)*.9),pose=chaseCameraPose(p);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const dog=new T.Vector3(p.x,.75,p.z).project(camera);assert(Math.abs(dog.x)<1e-9);baseline??=dog.y;assert(Math.abs(dog.y-baseline)<1e-9)}}
 sim.reset();field.resetTreats();assert(!marker.visible);assert.equal(marker.scale.x,1);const geometries=new Set(),materials=new Set();field.root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());
});
````

