# 第10章　配信設定と開発履歴（1）

### `.openai/hosting.json`

````json
{
  "project_id": "appgprj_6afc36d61dfc8191bb8b70bccc6de993",
  "static": {
    "directory": "dist"
  }
}
````

### `PROJECT_NOTES.md`

````markdown
# わんラン — decisions and scope

## Scope of this version
Dog/coat, mode, and course selection are implemented. The user asked to proceed after accepting the dog-selection screen. Trial flow is dog → mode, but the permanent selection order is still undecided. Do not add an order chooser. User wants staged review with stops between decisions. The park race is playable; other race courses and agility remain selection previews.

## Dog selection
Eight proposed breeds: Shiba, corgi, toy poodle, dachshund, golden retriever, border collie, Pomeranian, Chihuahua. Three selectable coat palettes per breed. These are provisional stylized models and colors for review, not finalized assets. Equal performance irrespective of breed or coat. Interactive 3D preview with drag/keyboard rotation, reset, slight idle movement, reduced-motion support. Local storage saves breed and coat. “この犬にする” confirms the dog/color and opens mode selection. No navigation to unfinished course/game pages.

## Confirmed future game direction
- Portrait mobile web app, two modes: simultaneous race against CPU dogs, and solo agility time/accuracy challenge.
- Both use close behind-dog chase cameras; no overhead agility camera.
- Stylized coherent matte 3D with careful rigid obstacle geometry; avoid warped AI-looking geometry and oversaturated UI.
- Swipe left/right to move, up to jump. Agility swipe down stops, tap resumes.
- Race: numerous regularly spaced treats build a dash gauge. Full gauge enables TAP to activate. Do not auto-activate.
- Proposed threshold 20 treats and duration 3 seconds are provisional and need playtesting.
- Hurdles are jumped, not crawled under. Never place treats under an impassable hurdle: use reachable jump trajectories. Tunnels may contain reachable treats.
- Several courses intended per mode. Course selection, gameplay and mode-selection order remain future work.
- No action buttons during gameplay; selection screens can have accessible buttons.
- At completion, user wants a summary of actual finalized features and differences between the modes. Keep this file updated.

## Selection revision — 2026-11-17
- Added Pomeranian (orange, cream, black) and Chihuahua (fawn, chocolate/tan, cream): eight breeds, three coats each. Existing choices are preserved.
- Pomeranian has a broad fluffy mane, compact body and curled plume over its back. Chihuahua has larger ears and a smaller body.
- Three interactive layout proposals, selected via a temporary comparison strip: A inline 4×2 breed grid; B native dialog/bottom sheet (default recommendation); C previous/next buttons plus direct breed dots.
- All proposals share the selected breed and coat, confirmation, and local persistence. Comparison is independent of future mode-selection order.
- Fixed dynamic viewport layout with safe-area padding; flexible 3D stage takes remaining height, controls stay visible. Compact portrait and landscape rules. Dialog uses native modal focus/escape behavior and 4×2 grid without an internal scrolling list.
- Runtime browser QA remains limited by unavailable managed preview relay and production sign-in in the assistant browser; do not claim visual/device tests passed.

## Accepted B / popup behavior — 2026-11-17
- User chose B. Removed the A/B/C comparison switch; the screen always uses the popup picker, including old layout query links.
- Popup dog taps are tentative. They update the preview/highlight only and never overwrite the committed breed, coat, final confirmation flag, or local storage.
- “この犬に決定” applies the candidate. A changed breed starts with its first coat; reconfirming the existing breed retains its selected coat and confirmation state.
- ×, Escape, backdrop dismissal, and any other non-apply close discard the candidate and restore the committed breed, coat, and confirmation state. Opening again starts from the committed choice.
- Commit shows a short success notice; discarding a changed candidate shows “変更を取り消しました”. No extra confirmation dialog is needed for this reversible action.

## Mode selection — 2026-11-18
- Added two selectable cards: レース (CPU competition, treats fill a gauge, tap to dash) and アジリティ (solo time/accuracy, swipe down stops, tap resumes).
- Dog selection advances to #mode. Back-to-dog and browser history preserve the committed dog and coat; the popup still has independent apply/cancel behavior.
- Mode selection is tentative until “このモードに決定”, which saves a separate local preference and displays a success notice. Selecting a card does not overwrite the saved mode.
- The selected dog remains visible; the ground color subtly follows the mode. Short mode descriptions and gesture hints explain the differences.
- Stops at mode selection for user review. No course-selection or race gameplay in this increment.

## Course selection — 2026-11-18
- User approved six starting courses and wants more later. Race: park, beach, forest. Agility: first field, zigzag, balance.
- courses.js contains stable IDs, mode, names, difficulty, text, feature tags, theme, route and obstacle preview placements. The renderer creates previews from this data. Preview route placement and difficulty remain proposals for future playtesting.
- Course UI displays three choices at a time; additional groups use previous/next buttons without vertical scrolling. There are no artificial locked/upcoming slots.
- Mode confirmation now advances to #course. Selections are saved independently for each mode only on course confirmation, with dog and coat carried through all screens. Back navigation preserves choices and history records the mode.
- Selection-only 3D overview previews show the course scenery and obstacles. The future gameplay camera remains close behind the dog.
- Rigid seesaw: three contiguous painted cuboids have identical thickness and one rotation. Treat previews skip obstacle footprints; gameplay collision/reachability still needs implementation and testing.
- Stops at course selection for review. No start-race button or playable race added in this increment.

## First playable race — 2026-11-18
- Scope is park race only, for user feedback on controls. Other courses remain clearly marked selection previews. Agility gameplay follows after race review.
- Close third-person camera, auto run, 3 lanes, swipe left/right to move, up to jump, down to brake, tap to dash. Keyboard arrows and Space are also supported.
- 480-unit course, player plus 3 CPU dogs. One-time hurdle/tunnel collision checks cause temporary slowdown. Dogs animate legs and tails; the camera lowers approaching a tunnel.
- Dense treat trails; hurdle-adjacent treats arc above the bar, no underneath pickups. Tunnel treats are at ground-running height. 20 treats charge a manually activated 3-second boost. No automatic activation, including while the gauge is full.
- Countdown, pause/resume, hidden-tab auto-pause, goal/rank/time/treat/dash/hit result, course-local best time, retry and return-to-course.
- Race simulation and gesture classification are separate pure modules for deterministic tests. Full browser/device rendering and real gesture feel still require device verification; managed preview relay has been unavailable.
- Validation passed: eight race simulation tests, six course geometry/selection checks, 24 dog/coat rigs, park launch and WebGL fallback cleanup, all breed popup cancel paths, and JavaScript syntax. No rendered-frame or physical touch verification is claimed.

## Park race turns — 2026-11-18
- User approved the playable race but requested real directional turns, at least Temple Run style, because lateral lane changes alone felt too straight.
- Added four 90-degree bends (right, left, left, right). Shared distance-to-world route mapping drives the continuous road, fences, trees, obstacles, treat trail, all dogs, finish line and close rear camera.
- Straight sections retain lane swipes. A direction cue appears 32 units before a bend; the yellow “右/左へスワイプ” cue accepts an early swipe within 20 units. Correct input queues the turn and centres the dog; it does not move the dog to the wrong lane or trigger a dash. HUD and roadside arrows indicate direction.
- Missing a turn holds the player at its entrance while CPU racers continue; only the correct direction swipe resumes. No automatic turn or game-over reset. Wrong-direction input can be corrected. Pause preserves queued turns; retry clears all turn state.
- Removed obstacles from turn approach/exit zones and placed the turn treat trail on the centre lane. Jump, tunnel, brake and manual 20-treat dash rules remain.
- Results include turns completed and missed turns. New course-version best-time key keeps straight-course records separate.
- Validation: 15 deterministic simulation/route/geometry tests pass; existing selection and 24 dog/coat rig checks pass. Managed preview relay is still unavailable, so actual device rendering and gesture feel need user review.
- DOM integration with a mocked renderer also passed: pointer-swipe turn input, waiting cue, camera world movement, all four turns, pause/resume, goal, best-time storage, retry and exit cleanup. This checks frame logic but does not verify GPU rendering.

## Centred camera, cleaner UI, first agility — 2026-11-18
- User accepted turning but reported that the camera lost the dog in bends. Camera position and look target now share the dog's world position and current heading, preserving its screen position through straight sections, all turns, and lane changes. Tunnel camera height/distance still ease down.
- User wants fewer persistent explanations across the whole game. Removed button footnotes, promotional text, repeated selection confirmations and inline control lists from dog, mode, course and start/pause screens. Necessary course availability stays in course-card badges; confirmations remain temporary notices. Detailed controls and dog-selection semantics are available from “遊び方”. Breed popup apply/cancel behavior is unchanged.
- Race dash gauge is wider, with an 18–22 px fill bar, larger labels/count, and one integrated state line. “タップでダッシュ” appears only when ready. Manual activation remains unchanged.
- Next milestone is the first playable agility course, “はじめての広場”: solo close-camera run, six ordered hurdles/hoops/tunnels, lane swipes, up to jump, down to stop, tap to resume. Stopping keeps the clock running; menu/hidden-tab pause freezes it. Each failed obstacle adds 5 seconds to the final record. No race boost, treats or CPU dogs in agility.
- Results show raw time, penalty, cleared obstacles and total time; the best record uses an independent course key. Agility retry, help, pause and return-to-course preserve the selected dog/coat. Only park race and first-field agility are playable in this checkpoint; other courses remain previews.
- Validation: 22 simulation, camera-projection and geometry tests pass. Camera projection checked through the whole route in portrait and landscape. DOM integration with a mocked renderer covers both complete runs, pointer controls, help, stop/resume, pause, results, independent best records, retries and cleanup. Selection/history, all dog-popup cancel paths and 24 dog/coat rigs also pass. GPU/device rendering remains unverified because the managed preview relay is unavailable.

## Open agility arena and five-dog races — 2026-11-18
- User confirmed the centred rear camera works well. Preserve that camera and existing swipe/tap controls; reference image 2 is an arena layout reference, not a requested overhead gameplay camera. The images' old auto-dash/button captions do not replace the agreed controls.
- Agility base speed increased from 7.5 to 11.25 (50% faster). No items, treats, boost mechanic, or CPU dogs were added to agility.
- Replaced the long race-like corridor with a dedicated open-lawn arena renderer. A single rectangular perimeter fence encloses grass, six spatially distributed hurdles/hoops/tunnels, numbered boards and start/finish flags. No road ribbon, lane markings or trackside fences. Trees, hills and a pavilion remain outside the arena. A subtle marker identifies only the next obstacle.
- A compact approximately 243-unit circuit sweeps around the field and returns through its interior, instead of extending down a narrow road. All obstacles are on straight approaches with clearance before/after bends. The selected-course overview now also shows a lawn with distributed equipment; gameplay stays close behind the dog.
- Kept manual stop/tap-resume, jump, per-obstacle penalty and single-dog timing. New arena records use their own key because speed/layout changed.
- Additional user request: race now has five dogs total (player plus four CPUs). CPU lane scheduling handles all four actors, roster rendering follows the simulation count, and start/HUD/results use five participants. Agility stays solo.
- Validation: 27 simulation/camera/geometry tests pass, including fifth-place finishing, retry resets, 50% speed increase, arena fence margins, no road/items, all six obstacles and camera centring throughout the arena. DOM + mocked-renderer full-run checks confirm five rendered race dogs, five-participant HUD/results, and solo agility stop/resume/results. Existing selection/modal/history checks also pass. Actual GPU/device rendering is still unverified; managed preview relay was unavailable in this work session.

## Playable balance challenge — 2026-11-18
- User accepted the arena/five-dog checkpoint and asked to continue. This milestone opens バランスチャレンジ from agility course selection; park race and first-field agility remain playable, while beach, forest and zigzag remain previews.
- The balance course uses the open grass arena and close rear camera, with six ordered obstacles: hoop, seesaw, tunnel, hurdle, hoop, seesaw. Course preview uses the actual layout. Balance feature tags now describe its implemented equipment; slalom remains part of the future zigzag course.
- Each seesaw is a straight rigid board made of three contiguous painted segments under one rotation, with A-frame supports. Shared dimensions drive both rendering and contact physics, so the dog's height and pitch follow the board. Camera height and look target rise together to preserve screen position. No treats, boost or other racers in agility; race still has five dogs total.
- Run onto the board, swipe down near its centre, wait for it to tip, then tap to resume. Board travel slows locally to 4.2 while open-field speed stays 11.25. Tapping during the tipping motion does not skip the wait, and reaching the ground never auto-resumes. Lane changes/jumps are locked only while on the board.
- Early stopping can be corrected with a tap to advance. Missing the stop auto-holds at the centre to let the run continue after tipping; this crossing counts as one miss (+5 seconds) on exit. Bypassing or jumping onto the board also counts as one miss. Ordinary stopping keeps the clock running; menu pause freezes the board and clock. Retry resets angles, height, pending obstacles and stop state.
- Compact contextual prompts appear only as needed. Full seesaw instructions are in 遊び方. Balance has its own best-time key; first-field and race records remain separate. Course identity is carried through launch, hash reload and controller replacement.
- Validation: 33 deterministic simulation/geometry/camera tests pass, including a perfect six-obstacle balance run at three frame intervals, early-stop correction, missed-stop recovery, jumping/bypass penalties, paused tipping, manual restart, rigid segment contact and portrait/landscape camera alignment. DOM + mocked-renderer integration passes full race, first-field and balance runs, UI prompts, raised dog/animated board, pause/retry, independent best records and cleanup. Course selection/fallback/history and 24 dog rigs plus breed-popup cancel/commit checks pass. Old standalone pre-mode-selection harnesses are superseded by the current flow checks. Actual GPU/device rendering and touch feel remain unverified because the managed preview relay is unavailable.

## Playable zigzag challenge — 2026-11-18
- User approved balance and asked for the next milestone. ジグザグチャレンジ is now playable, completing the three initial agility courses. Beach/forest racing remain previews for later work; park race still has five dogs total.
- Six ordered obstacles in the open arena: hurdle, six-pole slalom, tunnel, hurdle, six-pole slalom, hoop. The first pole row starts on the left and the second on the right. Selection overview uses the actual gameplay pole positions. Close rear camera and no-item solo agility rules remain.
- In each slalom approach and row, one horizontal swipe targets that side directly (±0.9), so crossing from left to right takes one swipe, not two lane changes. Repeated swipes cannot move beyond the row. Running is 8 units/second locally for a manageable rhythm, returning to the accepted 11.25 elsewhere. Jumps are disabled within the row; entering airborne cannot bypass the ground-level check. Outside slalom, existing lane, jump, stop and tap-resume controls apply.
- A short left/right cue, pole counter, highlighted pole and one ground marker identify the next passing side. Completed pole bands turn green or muted red. No extra persistent explanation under controls; detailed instructions are in 遊び方.
- Each pole is checked at the actual crossing point using swept position interpolation. Wrong-side passes, centre-line collisions and far outside bypasses invalidate the row. Each failed row adds one miss / 5 seconds at its exit, even if several poles were missed. The run continues without forced restarts. Stop keeps the clock running; menu pause freezes progress. Retry resets pole status, marker and lateral targets.
- Zigzag has its own best-time key and course name in ready/HUD/results; course selection, saved preferences and hash routing support it. Other records are unchanged.
- Validation: 39 simulation/geometry/camera tests pass, covering complete no-miss zigzag runs at 120/60/20/10 Hz, exact pole/model alignment, alternating sides, early jump and late-swipe failures, one-penalty-per-row, stop/pause/retry, restored normal speed and centred portrait/landscape camera. DOM + mocked renderer also passes twelve individual pointer swipes across both rows, stop/pause/resume, no-miss completion, isolated records and retry, alongside full race/first-field/balance regression. Course launch/fallback/history and breed selection checks pass. GPU/device rendering and physical touch feel remain unverified; managed preview relay remains unavailable.

## Playable beach race — 2026-11-18
- 海辺 is the second playable race. The five dogs follow a 472-unit coastal course with four sweeping turns. The rear camera, roadside arrows, CPU movement, models and finish line use the same route.
- Five driftwood sections give a choice: jump the trunk on firm sand or follow a row of 13 treats in the adjacent lane. Softer sand reduces running speed by 20% while grounded within the patch. Treats stay clear of every log. Twenty treats fill the gauge; tapping triggers the three-second dash.
- The shoreline, foam, sails, dunes and parasols distinguish the beach. Both the selection miniature and live course use the actual route and the same alternating treat-side choices. Beach has its own saved best time. Forest is the remaining race preview.
- Four new simulation/geometry tests pass alongside the original 39. DOM integration with a mocked renderer covers five dogs, turn swipes, manual dash, pause, finish, independent record and retry. Course selection, return navigation and miniatures also pass. Physical touch and GPU-rendered appearance still need device review.

## Beach jump reward and playable forest race — 2026-11-18
- User asked to reward the jump route in addition to the 13-treat side route, then continue with the next course.
- All five beach logs have three airborne treats in a low–high–low arc. One well-timed jump can collect all three both at normal speed and during a dash. The existing 13 grounded treats on the slower side path remain. The course miniature shows both lines at different heights. The existing beach record is preserved.
- 森 is a five-dog race through a dirt trail lined by firs, birches, mossy stones and blazed waymarks. Six alternating bends and seven cut logs across different lanes test steering and jump timing. Each log has an arc of three snacks. Treat placement avoids blocked ground and preserves a clear turn-input window. Dash still requires the player's tap after collecting 20 treats.
- Forest has its own modelled course overview, start, help and best record. All six initial courses (three race and three agility) are now playable. The user asked for a feature summary when the game is finished.
- The 46 simulation/geometry tests pass. Tests include every beach arc at normal/boosted speeds, a no-hit forest finish with every jump reward, actual turn and geometry alignment. DOM checks with a mocked renderer cover all six runs, forest launch and selection, five dog models, manual boost, pause/finish/retry and isolated course records. Managed browser preview relay unavailable; device rendering and physical touch feel remain unverified.

## Course records and finish comparison — 2026-11-18
- All six course cards now show their own best or 記録なし. Difficulty, course name and record occupy the three existing lines of each card.
- The result screen shows first finish, time improvement, tie or gap to the course best. Race uses finish time and agility uses total time including penalties. Comparisons use the same hundredths shown on screen. The fastest exact time is still kept.
- Reuse the six original storage keys so returning players keep their saved times. On a storage write failure, the result uses 今回のベスト and a temporary best remains available during the current page session.
- Checks passed: 49 unit/simulation/geometry tests and full-run DOM checks for all six courses with a mocked renderer. Verified existing times on the cards, fresh/updated/slower results, agility's penalty-inclusive score, retry, independent persistence and rounding ties. Smartphone rendering has not been visually verified because the managed preview relay is unavailable.

## Next course from the finish — 2026-11-18
- The finish panel pairs もう一度 with a named next-course button. Race progresses 公園 → 海辺 → 森, and agility progresses はじめての広場 → ジグザグチャレンジ → バランスチャレンジ. Final courses offer retry and course selection.
- Continuing opens the next start screen with the same breed and coat. The course selection follows the player, and one Back action still returns to that selection. Each course starts with fresh counters and keeps its own best.
- Checked both full sequences via the app's normal controls using a mocked renderer, including history, keyboard focus, retry, course records and cleanup. Managed visual preview unavailable.

## Beach overtaking lines and pack positions — 2026-11-18
- The five beach logs use centre, right, left, right, left. Firm-sand treats lead into each jump lane. The alternative soft-sand rows stay clear of the logs, and the main line returns to the centre ahead of turn inputs. The selection miniature samples the new beach trail.
- Two beach rivals collect their own treats and spend 20 on a three-second dash. Their pickups leave the player's trail intact. In complete comparison runs the centre-only line ranked third even with jumps, turns and manual boosts. Both the jumping and sand routes could win. Previous course records use the same keys.
- All three races show a gold player pin and four light rival markers on the existing progress bar, driven by the dogs' distances. Agility keeps its solo progress indicator.
- 51 simulation and geometry tests pass. DOM runs with a mocked renderer covered pack movement, finish, retry, all six courses and progression. The managed visual preview relay was unavailable; phone rendering and touch feel are unverified.

## Hill Field agility — 2026-11-18
- A fourth solo agility course, 丘の広場, uses a 196-unit open-field route. Its six obstacles are an A-frame, hurdle, tunnel, A-frame, hoop and hurdle. Two rigid painted ramps have yellow contact zones and fixed footholds. Each ridge looks ahead along a straight to the next obstacle.
- A grounded approach at the yellow entrance carries the dog up and down at the usual running pace. Down-swipe stops, tap resumes. Missing the entrance or taking it airborne costs one five-second fault on exit. The rear camera follows the dog's height. There are no pickups.
- The course is available directly on agility page two or from the balance finish. Paging previews the first visible course and only confirming play saves the change. Hill records are independent. Retry resets ramp contact and all obstacle results.
- 55 tests pass, including four frame intervals, exact footing on rendered panel geometry and projecting the next obstacle at each ridge in portrait and landscape. DOM integration with a mocked renderer completed a six-clear swipe/tap run with hill stop/resume, record and retry, plus all seven course transitions. Managed visual preview unavailable; physical-phone rendering and feel remain unverified.

## Smartphone playtest, first pass — 2026-11-18
- Kept the first play-feel trial to 海辺 and 丘の広場. Each accepts a quick, clearly directed 20 px flick within 210 ms, alongside the existing 28 px swipe. A drag that moves away and comes back cannot trigger a dash or resume. One pointer can produce at most one action, and cancellation of another finger does not discard the active gesture.
- On the beach the turn cue now changes on the simulation frame that opens turn input. On the hill the rear camera eases vertically into and out of the A-frame ridge and aims slightly lower to keep the following obstacle in view. The dog still follows the exact rigid panel and remains horizontally centred.
- The two playtest links use ?play=beach and ?play=hill-field. Each opens the course ready screen with the saved breed and coat, remembering the linked course and mode as a normal selection. Detailed device feedback is the next sign-off before balancing all seven.
- 57 tests passed. Full simulated pointer runs verified all four beach turns, manual dash and hill six-clear finishes. The dog and following obstacles projected inside the viewport throughout both inclined passages at 320×568, 390×844 and 844×390. Normal navigation, retry, and all seven course transitions passed. Device rendering and physical touch feel await phone review; managed browser relay unavailable.

## Release balance pass — 2026-11-18
- Compared centre-line and treat-trail play on all three races with the same jump and manual boost strategy. The introductory park allows either to win. Beach keeps its two snack-collecting outer rivals. Forest now has two opponents earning boosts with their own pickups, including a centre runner. In the 60 Hz sample, centre scored second at 36.67 s (184 treats); the log route won at 33.80 s (213 treats). Player pickups and best-time keys are preserved.
- Race collisions and all four agility courses sample the dog's actual lateral position and jump height at the gate. Applied the same footing check to hurdle and hoop planes, tunnel entry and exit, slalom poles, seesaw and A-frame entrances. Ordinary slow render frames advance in smaller simulation steps so the race clock stays consistent. Menu pause and background handling are preserved.
- Agility uses the existing transient feedback to pair each five-second fault with its cause. Slalom identifies the first missed pole; entries, jumping and the seesaw stop have distinct feedback.
- 59 unit, geometry and simulation tests passed. Full-run DOM checks with a mocked renderer passed for all seven courses, saved records, course transitions, pause and retry. Additional checks covered late/early jumps and tunnel entry at 10/20/60/120 Hz, forest rankings, and the live fault cue and clock at 10/20/60 Hz. Physical-phone visual and touch review remains open; the managed preview relay is unavailable.

## 引き継ぎ — プラン③の確認版
- 最新の進行状況はこの欄を優先する。①・②は確認済み。③の犬の動き、器具、選択画面の仕上げを実装・自動検証済み。次はスマホで見た感想を確認し、了承後に④の通し点検へ進む。⑤で仕上げと両モードの特徴をまとめる。
- 8犬種・3毛色。レースは自分＋CPU4匹、おやつ20個で手動ダッシュ、3コース。アジリティは1匹、アイテムなし、広場4コース。後方カメラと各コースの記録を維持。
- 走行では踏み込む足を路面に合わせ、脚を戻す区間で足を上げる。ジャンプは前後で異なる脚の姿勢。Aフレームの頂上とシーソーの傾きは足先ごとに扱う。選択中は台に立つ。
- シーソーの板と車軸の中心を一致させ、輪に金具を追加。ミニチュアと実コースのトンネルは両端が開いた連続した布壁にした。
- 犬種の仮選択は×で元の犬と毛色に戻り、「この犬に決定」で反映する。「モード選択へ」「コース選択へ」で進む。操作説明は「遊び方」で確認。小さい画面で一覧の文字を読みやすくし、操作のタップ範囲を拡張。
- 検証は62項目成功。描画を置き換えた操作テストでも、犬種の確定・取り消し、全7コースのゴール・記録・再挑戦・コース移動が成功。海辺のダッシュと曲がり角、丘の斜面での追従を縦画面想定で確認。丘は横画面想定でも確認。スマホ実機での見た目、画面への収まり、指で触れた感触は未確認。
- 「続けて」と言われたら、この欄と最新のサイト版・ソースの差分を照合する。③の直前は v19（089e545）。③の版が未反映なら反映と動作確認から、反映済みなら返ってきた実機の感想または④から再開する。作業中に中断した場合は、完了項目、未確認項目、次の操作をここに追記する。

## プラン③再開 — 赤柴の犬選び・公園レース、最初の画面比較
- 2026-11-20。公開済みの v20 とソース 6667510 が一致。前の「③完了」はユーザーの再開指示で更新。③は途中。
- A「ころころ3D」の赤柴と、C「すっきりポリゴン」の公園が今回の試遊対象。頬・眉・耳の内側の毛色、まばたき、足運びに合わせて弾む巻き尾、後ろから見える青いスカーフの結び目を実装。公園の一部のハードルを、同じジャンプ判定の丸太で描画。競技のルール、スワイプ、後方追従、記録キーは v20 と同じ。
- 犬選びは ?trial=shiba 、公園スタートは ?play=park&trial=shiba 。通常の入口はこれまでどおり保存済みの相棒を復元。試遊リンクを開くだけでは犬・毛色の保存値を変更しない。
- /review/index.html で変更前後を表示。赤柴・赤毛、同じ公園と定時入力を使用。比較対象は犬選び、最初のジャンプ障害直前、最初の右カーブ。確認用フレーム内の保存先はメモリだけで、通常プレイから独立。
- 65テスト成功。赤柴の足の接地、縮小モーション、固定入力の最初の右折合図、および丸太手前での5匹・丸太・おやつの投影位置（320×568、390×780、390×844）を含む。ブラウザーでの最終表示・スマホ実機の操作は未確認。モデルと同じ配置の別レンダーも目視比較済み。
- 次はこの確認版で赤柴の顔、後ろ姿、5匹での進路の読みやすさをユーザーと確認。「続けて」はこの地点から。好みが合った後にほかの犬種・全7コース・モード選択から結果までのUIへ広げる。プラン④はその後。

## プラン③ — 公園の骨型ビスケットと後方カメラの視界
- v21（073494c）のスマホ実機画像2枚で、公園中盤で道と赤柴が丘に隠れる場面と、トンネルで赤柴の背中が大きく映る場面を確認。おやつはユーザーの希望どおり骨型。公園のビスケットは両端に切れ込みのある連続した生地の形にし、焼き色と肉球のくぼみを追加。おやつ数・ダッシュゲージの絵も同じ輪郭にした。
- 中盤は遠景の丘が折り返し後の直線にも重なっていたため、公園の全区間とカメラ通路から丘を離した。公園のトンネルでは普段の追従距離を保ち、犬とカメラの間に入る屋根を手前から区画ごとに透かす。おやつの当たり判定・得点・操作は共通のまま。
- 実装比較は /review/index.html?scene=snack （骨型。拡大イメージも掲載）、?scene=midpark （中盤の直線）、?scene=tunnel （最後のトンネル）。同じ赤柴に同じ入力を再生し、v21と修正版を切り替える。犬選び、丸太、最初のカーブの比較元は引き続きv20。試遊入口は /?play=park&trial=shiba 。
- 自動テスト68件成功。3レーン、公園の全周と後方カメラの通り道、2つのトンネルでの犬への視線、ビスケットの輪郭と刻印を検査。拡大イメージはモデルを別の照明で描画したもの。比較ページはゲーム本体を直接描画する。v22のスマホ実機表示・タッチ操作はユーザーの再試遊待ち。
- 「続けて」はこの公園版から。次は赤柴の見え方と骨型おやつをユーザーと確認し、方向が決まれば他の犬種・全7コースと残りのUIへ進む。プラン③は途中。

## プラン③ — 赤柴と一緒にくぐる公園のトンネル
- v22（5994d63）から再開。公園の2本のトンネルは、入口から出口まで不透明な布とアーチがつながる。カメラは入る前に低くなり、赤柴が通ったレーンを背後からたどる。横を通る場合は通常の背後カメラ。出口で横に移動してもカメラは赤柴の軌跡を追って抜ける。スワイプ、通過・ジャンプ判定、記録の条件は従来どおり。
- 公園を走る柴犬のモデルを0.94倍から0.86倍にして、しっぽと前方の道を同時に見やすくした。犬選びのモデルはそのまま。
- /review/index.html?scene=tunnel に同じ赤柴の v22・v23 を用意。「入口から出口まで再生」で同じ入力の通過シーンを再生できる。スマホ縦では版を切り替える。試遊は /?play=park&trial=shiba 。
- 全69テスト成功。公園の両トンネルで犬とカメラが一緒に屋根の下を進む距離、足・背中・耳への視線、画面内の位置、出口直後の横移動、横を通る場合、再スタートを確認した。比較動画は実装モデルとカメラの別レンダー。スマホ実機でのv23の見え方は未確認。
- プラン③は途中。「続けて」はv23のトンネル確認から。実際の走行で方向が合った後にほかの犬種・コース・UIへ広げる。
- v24はv23と同じトンネル・赤柴。比較ページの再生時計を録画の固定ステップに合わせた。ミリ秒から秒への丸めでゲージ満タンとダッシュ入力がずれ、最後のトンネルに到達できなかった現象を修正。実際のレースの時計は端末の経過時間で従来どおり進む。次回の確認版はv24。
- v24で全69テスト成功。描画先を置き換えたゲーム本体の試験でも、v22・v24の静止比較が同じ428.74mに到達し、両方の通過リプレイが約414.27mから443.32mまで進むことを確認した。

## プラン③ — 実機の入口写真に合わせた公園の比率、v25
- v24（b5afb10）のスマホ写真2枚から、アーチの高さが半幅の2倍を超え、入口と出口の側面を大きく切り上げたことで布の一部が消えたように見えることを確認。
- v25は元の青い半円筒に戻し、縦だけ1.10倍。半幅1.70、高さ1.87、全長7.6。両端の縁と側壁は最後まで地面に接する。赤柴は走行時0.86から0.63、他の公園の犬は0.76から0.62。犬の影とコースのおやつも縮小。犬選びは従来の大きさを維持。
- 公園の背後カメラは通過時に高さ1.26、追従距離4.85。トンネルを描いたまま赤柴とカメラが中を進む。操作、当たり判定、記録は共通。比較ページの入口・通過中・5匹と丸太は提供写真のゲーム領域相当（393×639）で同じ入力をv24とv25に再生する。
- 全69件のテスト成功。両方のトンネルの壁が地面近くまであることを入口から出口まで検査。ブレーキ・通常・ダッシュの各速度で、出口直後に左右へ移動しても足・胴・頭への視線が保たれることを別途確認。ゲーム本体の描画先を差し替え、両方の版が同じ地点を通って出口の先まで再生することも確認。静止比較はゲームのモデルとカメラを取り出した別レンダー。
- 次は /review/index.html?scene=entrance か /?play=park&trial=shiba でv25を実機確認。プラン③は途中。比率と通り抜け方が合ったところで他の犬種・全コース・全体UIへ進む。

## プラン③ — 公園のアップ中も常に真後ろから追う v26
- v25（a2c110a）の実機写真で、トンネル手前のレーン移動の最初にカメラが斜めになった。旧版は犬の以前の横位置へカメラを残し、移動中の犬に向けて首を振っていた。
- カメラと注視点は同じフレームの犬の横位置に置き、進路の接線に合わせる。トンネル出口で壁に近づく場合は前後の距離と画角で逃がす。犬・おやつ・トンネルの比率と入力判定はv25と同じ。
- /review/index.html?scene=swipe でv25とv26の同じ地点・同じ赤柴の比較。「左右スワイプを再生」でトンネル前後の切り返しを見る。試遊は /?play=park&trial=shiba 。
- 実装したゲームの入力処理に左右のポインター操作を送り、描画先を置き換えてカメラを計測。対象直線の109フレームで横向きのずれはv25が最大約22度、v26は0度。トンネル通過、通常・減速・ダッシュでの出口の視界も検証。比較画像はゲームのモデルとカメラから作った別レンダー。実機写真はv25、v26の実機再確認はまだ。
- プラン③は途中。「続けて」はv26で左右にスワイプした感触の確認から。

## プラン③ — 公園のトンネル側壁と一時停止の現在地マーカー
- v26（693bcce）の背後カメラはユーザー確認済み。実機でトンネル内の横スワイプが減速しないことと、一時停止中に現在地マーカーだけが浮いて見えることが報告された。
- v27は2本の公園トンネルの入口・出口と半径を描画と当たり判定で共有。1フレーム内に移動した範囲を検査し、内壁に触れると元のレーンに戻って「トンネルの壁で減速」と表示。外から壁を横切る場合も通り抜けず、連続接触は同じ障害物のミス1回。減速は丸太・バーと同じ1.15秒。直進、外側の迂回、出口通過後のレーン移動は可能。トンネルの寸法・カメラ・犬の大きさはv26を維持。
- 一時停止メニューをHUDより前に表示し、現在地のピンを隠す。「遊び方」を閉じても停止中は非表示。「続ける」で現在位置、「最初から」でスタート位置に表示する。
- /review/index.html?scene=wall で壁への接触を固定入力で再生。/review/index.html?scene=paused は実装の一時停止メニューでv26とv27を比較。赤柴の試遊は /?play=park&trial=shiba 。
- 全72テスト成功。公園の両トンネル・左右両壁を10〜120Hzで検証。描画先を置き換えたゲーム本体でも、スワイプによる「トンネルの壁で減速」、一時停止・遊び方・再開・画面離脱・やり直し時のピンの状態を確認。v27のスマホ実機の操作感は再確認待ち。
- プラン③は途中。「続けて」はv27の試遊の続きから。

## 引き継ぎ — プラン③ v28 全コースの確認版

- v20（6667510）を基準にして進めた赤柴と公園は、v27のトンネル側壁と一時停止までユーザーが試遊し了承。v28ではレースで衝突した際に「ぶつかった！」と表示。ブレーキとアジリティのミス理由は別に扱う。
- 8犬種・各3毛色の相棒モデルを犬選び、モード選択、コース模型、レース、アジリティで共用。ほかの7犬種は耳と目、脚・胴の比率、しっぽとその揺れ方を犬種ごとに調整。公園・赤柴のカメラはv27の設定。
- 海辺の灯台・浅瀬、森の稜線と小径、競技広場ごとの芝・樹形・東屋を調整。走行HUDを上下に収め、モード選択、コース選択、出走前、停止、遊び方、結果まで配色を合わせた。
- 実装画面の比較は /review/index.html?scene=dog&breed=corgi 。犬種を切り替えて同じ毛色の変更前後を表示。/review/index.html?scene=wall は衝突時の実装画面の比較。/?play=beach&trial=poodle や /?play=hill-field&trial=collie から試遊。
- 72テスト成功。描画先を置き換えたゲーム本体でも7コースの開始・一時停止・再開・結果、24通りの足運びとモデル座標、公園トンネルの衝突メッセージと現在地ピンの復帰を確認。モデル比較画像は実装ジオメトリの別レンダー。ブラウザーのプレビューは接続できず、今回の実機結果は未確認。
- プラン③は途中。「続けて」はv28の全犬種・全コースの実画面レビューから。ユーザーと仕上がりの確認後に③の完了報告、最新版の情報源、④を新チャットで始めるプロンプトを渡す。

## 引き継ぎ — プラン③ v29 相棒の首元

- v28（c1488e3）の全体をユーザーが試遊して了承。実機の犬選びで、オレンジのポメラニアンの首毛にスカーフがほぼ埋まり、青い点だけが見える例を確認。
- v29で8犬種のスカーフを胴・胸・頭の形に沿わせた。前は三角の布、右肩の後ろは結び目と2枚の端。ポメラニアンは首の毛をまとめ、胸に毛量を残した。ダックスとプードルは耳の下に帯が見える高さに合わせた。
- トイプードルは頭頂を一続きの巻き毛にし、頬に沿う垂れ耳を1枚ずつの曲面で造形。3毛色とも共用し、走行時は耳の付け根から揺れる。
- 実装比較 /review/index.html?scene=dog&breed=poodle または breed=pomeranian 。変更前v28を保存し、正面寄り・横・後ろの同じ向きで比較できる。/review/scarves-v29.webp は実装モデルの別レンダー。
- 自動テスト73件。8犬種の待機と走行で胸・左右の肩から見える布を検証。7コースを描画先を置き換えて結果まで確認。v29のスマホ実機確認は次回。
- プラン③は途中。「続けて」はv29のプードル・スカーフの実画面確認から。ユーザーの仕上がり確認後、完了報告、情報源、④へのプロンプトを渡す。

## 引き継ぎ — プラン③ v30 スカーフの色選び

- v29のプードル・スカーフの仕上がりをユーザーが了承。v30では犬選びの毛色欄に「スカーフ」の選択を追加。従来の「犬種の色」に加え、青・赤・黄・緑・紫・ピンクから選べる。
- 色を変えると帯、結び目、布の端をその場で着せ替える。明示した色は犬種と毛色を変えても引き継ぐ。「犬種の色」に戻すと犬種固有の色になる。既存の犬・毛色の保存データも利用できる。
- 相棒のプレビュー、サムネイル、コース模型、レース・アジリティのプレイヤーに反映。ライバルはそれぞれの犬種の標準色。通常の入口は / 。
- 全74テスト成功。描画を置き換えた操作確認では、旧保存データ、色選択、犬種変更の取り消し・確定、毛色変更、再読み込み、両モードへの持ち越しと他の4匹の色を確認。
- プラン③は途中。8犬種・各3毛色、全7コース、選択から結果までの実装は反映済み。残りはv30の色選択と走行中の見え方をユーザーとスマホの実画面で確認し、必要な手直しをすること。確認後、完了報告と最新版の情報源、プラン④開始用のプロンプトを渡す。全7コースの通し点検は④。

## 引き継ぎ — プラン③ v31 スカーフの色メニュー

- v30の色の反映をユーザーが実機で確認。黄色を選択してもメニューが画面に残ったため、v31でゲーム内の6色ボタンに変更。どの色も押した時点で閉じ、選択中の色を押し直した場合も同じ。
- 「犬種の色」を選択肢と遊び方から削除。旧版で選んだ6色は引き継ぎ、未選択・旧自動は青から始める。
- 75件の自動テスト成功。描画先を置き換えた通常の犬選びでも6色表示、黄の選択と再選択で閉じること、×と枠外での取り消し、再読み込み、両モードへの反映を確認。v31のiPhone実機操作は未確認。
- プラン③は途中。次はv31のメニューがスマホでも選択と同時に閉じるか、ユーザーと実画面で確認する。了承後、完了報告・最新版情報源・プラン④開始プロンプトを渡す。

## プラン④　犬選びから全7コースの通し点検（2026-11-21）

- プラン③はユーザー了承済み。開始時の公開履歴v31と取得したソースはともに `27819bedcd349742d739ee5bd214248998a14294`。
- 通常入口のHTMLとアプリを読み込む自動操作で、ポメラニアンからトイプードルへの仮変更を×で取り消した後、確定。ホワイトの毛色と黄のスカーフ、黄を押し直して閉じる動作、戻る、モード選択、丘の広場の2ページ目からの開始を確認した。
- 7コースとも「走る」→ゴール→「もう一度」→ゴール。レース3コース・アジリティ4コースの結果、自己ベスト、名前付きの次コース、森・丘からコース選択に戻る動作を照合。各コースで一時停止・続ける、非表示とフォーカス喪失の通知による停止を確認。アジリティの下スワイプでは時計だけが進み、タップで再開。全走行で相棒モデルの犬種・毛色・スカーフを照合した。
- 修正1。はじめての広場で下スワイプして1分まで待つと、59.95秒付近が「00:60.0」になる。時計全体を0.1秒に丸めてから分・秒に分割し、同じ手順で「00:59.9 → 01:00.0 → 01:00.1」を確認。
- 修正2。公園・海辺・森を完走しても、画面には自分の順位・タイムだけで、残る4匹のタイムを見比べられなかった。結果に「5匹の順位とタイム」を追加。相棒より後のライバルも同じレースの走行規則でゴールまで計算する。各レースで再挑戦まで行い、5行の着順・タイムと相棒の順位を照合。相棒が先着する場合は別テストで独立走行のCPU記録と照合した。
- 修正後の通し点検14走と別プロセスでの相棒・全7コースの自己ベスト復元を確認。回帰テスト77件成功（開始時のv31は75件）。UIイベントとフレームを入力してゲームを動かす自動点検であり、画面描画・スマホ実機タップ・OSの実際のアプリ切替は対象外。公開URLは担当ブラウザでログイン画面まで。実機での最終試遊はプラン⑤に引き継ぐ。

## プラン⑤　公園の結果画面（2026-11-21）

- v32（5231091）、iPhone／Safariでユーザーが実機試遊。ポメラニアン・オレンジで黄のスカーフを選び、選び直したときも1タップで閉じた。公園で1位・33.55秒。5匹の順位とタイムの一覧を開閉できた。画像の自己ベストは33.55秒、1.05秒短縮。
- 不具合の再現手順は、公園を完走し、5匹の一覧を閉じて自己ベスト欄を見る。期待は記録の上下に均等な余白があること。v32の画面では記録が帯の下端に寄っており、CSSの上余白は9px（画面高680px以下で6px）、下余白は0だった。
- 両モードで共用する自己ベスト欄の上下に8px（画面高680px以下で6px）の余白を設け、左右に12pxを確保した。5種類の画面高でスタイル指定を照合し、回帰テスト77件成功。プレビューは接続できず、修正後の実機確認は次の公園の完走時に行う。
````

以上で全てです
