# 第10章　開発用比較画面と旧実装（1）

### `dist/review/after.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/before.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-sim.js":"./v26/race-sim.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("./v20/app.js"));</script></body></html>
````

### `dist/review/clock.js`

````javascript
import {lastFrame, recordedKey} from './replay.js';
// The dedicated viewing documents replay identical inputs through each shipped game.
// No saved partner, course, record or timer in a normal play session is touched.
export async function compareFrame(loadGame) {
  const params=new URL(location.href).searchParams,scene=params.get('scene')||'dog';
  const replay=['tunnel','swipe','wall'].includes(scene)&&params.get('replay');
  const values=new Map([['wan-run-dog',JSON.stringify({breed:scene==='dog'?(params.get('breed')||'shiba'):'shiba',coat:0})],['wan-run-mode','race'],['wan-run-courses','{"race":"park"}']]);
  Object.defineProperty(window,'localStorage',{value:{
    getItem:key=>values.get(key)??null, setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)
  }});
  const finalFrame=replay?2212:(lastFrame[scene]??lastFrame.dog);
  const queue=new Map(),timers=new Map(),nativeRAF=window.requestAnimationFrame.bind(window);
  let id=0,now=1000;
  window.parkReview={skipDraw:true};
  window.requestAnimationFrame=callback=>{queue.set(++id,callback);return id};
  window.cancelAnimationFrame=key=>queue.delete(key);
  window.setTimeout=(callback,ms=0)=>{timers.set(++id,{callback,at:now+ms});return id};
  window.clearTimeout=key=>timers.delete(key);
  if(scene!=='dog')history.replaceState(null,'','#race');
  await loadGame();
  await new Promise(nativeRAF);
  if(scene==='dog'){
    const turns={side:7,back:20}[params.get('view')]??0;
    const viewer=document.getElementById('dogCanvas');
    for(let i=0;i<turns;i++)viewer.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true}));
  }
  const start=document.getElementById('startRun');
  if(scene!=='dog' && !start){document.body.inert=true;return}
  const canvas=document.getElementById('raceCanvas');
  const input=key=>canvas.dispatchEvent(new KeyboardEvent('keydown',{key,bubbles:true}));
  if(start)start.click();
  const draw=t=>{
    const pending=[...queue.values()];queue.clear();pending.forEach(fn=>fn(t));
  };
  function step(frame,show){
    now=1000+frame*(1000/60);
    for(const [key,timer] of timers)if(timer.at<=now){timers.delete(key);timer.callback()}
    const key=recordedKey(frame,scene);
    if(scene!=='dog'&&key)input(key);
    // Match the recorded inputs to exact simulation steps, including full-gauge taps.
    window.parkReview.stepSeconds=frame===0?0:1/60;
    window.parkReview.skipDraw=!show;
    draw(now);
  }
  for(let frame=0;frame<=finalFrame;frame++){
    step(frame,frame===finalFrame);
    if(frame>0&&frame%200===0&&frame<finalFrame)await new Promise(nativeRAF);
  }
  if(scene==='paused'){
    window.parkReview.showPause=true;
    document.getElementById('pauseRace').click();
    window.parkReview.showPause=false;
  }
  document.body.inert=true;
  if(replay){
    const start=await new Promise(resolve=>{
      const listen=e=>{
        if(e.origin!==location.origin||e.source!==parent||e.data?.replay!==replay||!Number.isFinite(e.data.start))return;
        window.removeEventListener('message',listen);resolve(e.data.start);
      };
      window.addEventListener('message',listen);
      parent.postMessage({ready:replay},location.origin);
    });
    let frame=finalFrame;
    while(frame<2320){
      const time=performance.timeOrigin+await new Promise(nativeRAF);
      const until=Math.min(2320,finalFrame+Math.floor((time-start)*.06));
      while(frame<until){frame++;step(frame,frame===until)}
    }
  }
  // Resize may change the canvas backing store. Redraw the same instant after layout.
  window.parkReview.stepSeconds=0;
  new ResizeObserver(()=>nativeRAF(()=>draw(now))).observe(document.body);
}
````

### `dist/review/index.html`

````html
<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>わんラン｜相棒と公園の画面比較</title>
<style>
*{box-sizing:border-box}body{margin:0;color:#294a3b;background:#f9f7ed;font:16px/1.5 system-ui,"Hiragino Sans",Meiryo,sans-serif}
main{max-width:930px;padding:18px clamp(12px,3vw,32px) 24px;margin:auto}header{display:flex;align-items:baseline;justify-content:space-between;gap:12px;flex-wrap:wrap}
h1{font-size:clamp(19px,3vw,27px);margin:0}a{color:#295c43;font-weight:700;text-underline-offset:3px}p{font-size:14px;margin:5px 0 12px;color:#516454}
nav,.versions{display:flex;gap:5px;flex-wrap:wrap}button{font:inherit;font-size:14px;font-weight:700;color:#385944;cursor:pointer;border:1px solid #b4c3ad;border-radius:10px;min-height:44px;padding:6px 14px;background:#fffdf4}
button[aria-pressed=true]{color:#fffbed;border-color:#305944;background:#305944}button:focus-visible,a:focus-visible{outline:3px solid #ba853a;outline-offset:2px}
.biscuit-study{margin:12px 0;color:#3d5647;font-size:14px}.biscuit-study summary{cursor:pointer;text-decoration:underline;text-underline-offset:3px}.biscuit-study .pair{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:9px 0;max-width:640px}.biscuit-study img{display:block;width:100%;height:auto;border-radius:9px}.biscuit-study span{display:block;margin-bottom:3px;font-weight:700}.versions{display:none}.screens{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin-top:12px;align-items:start}figure{min-width:0;margin:0}
figcaption{font-weight:700;font-size:14px;margin-bottom:4px}
.window{overflow:hidden;border:1px solid #a6b7a5;border-radius:14px;background:#e1e9d8;position:relative;width:100%;aspect-ratio:390/780}
iframe{display:block;width:390px;height:780px;border:0;transform-origin:top left;pointer-events:none;background:#f8f6ec}
@media(max-width:660px){main{padding-top:10px}.screens{grid-template-columns:1fr;margin-top:7px}.versions{display:flex;margin-top:8px}.versions button{flex:1}figure:not(.shown){display:none}figcaption{position:absolute;clip-path:inset(50%);width:1px;height:1px}.window{max-width:390px;margin:auto}nav button{padding-inline:10px}header a{font-size:14px}}
.screens.phone-sized .window{aspect-ratio:393/639}.screens.phone-sized iframe{width:393px;height:639px}
select{min-height:44px;font:inherit;color:#294a3b;border:1px solid #a6b7a5;border-radius:9px;background:#fffdf4;padding:4px 10px}#dogPicker{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:8px}#dogPicker[hidden]{display:none}</style></head>
<body><main><header><h1>相棒と公園の画面比較</h1><a id="play" href="../?trial=shiba">この赤柴で遊ぶ</a></header>
<div id="dogPicker"><label>相棒 <select id="comparisonDog"></select></label><label>向き <select id="dogView"><option value="front">正面寄り</option><option value="side">横</option><option value="back">後ろ</option></select></label><label>変更前 <select id="dogBaseline"><option value="v28">v28</option><option value="v20">v20</option></select></label></div><p id="description"></p><nav aria-label="比較する場面"><button data-scene="snack">骨型ビスケット</button><button data-scene="midpark">中盤の直線</button><button data-scene="swipe">左右スワイプ</button><button data-scene="group">5匹と丸太</button><button data-scene="entrance">トンネルの入口</button><button data-scene="paused">一時停止</button><button data-scene="wall">トンネルの壁</button><button data-scene="tunnel">トンネルの中</button><button data-scene="dog">犬選び</button><button data-scene="log">最初の丸太の手前</button><button data-scene="turn">最初の右カーブ</button></nav>
<details id="modelStudy" class="biscuit-study" hidden><summary>プードルとポメラニアンの首元を見比べる</summary><img src="scarves-v29.webp" alt="同じ角度から見たv28とv29のトイプードルとポメラニアン" style="width:min(100%,780px);height:auto" loading="lazy" width="880" height="804"><p>実装モデルを別途レンダリングした確認用イメージです。下の犬選びはゲーム本体の画面です。</p></details><details id="biscuitStudy" class="biscuit-study" hidden><summary>骨型ビスケットの拡大イメージを見る</summary><div class="pair"><div><span>変更前 · v21</span><img src="biscuit-before.webp" alt="両端に丸いふくらみのある以前の骨" width="500" height="280"></div><div><span>確認版 · v22</span><img src="biscuit-after.webp" alt="両端に切れ込みが入り、中央に肉球の焼き印がある骨型ビスケット" width="500" height="280"></div></div><p>形を見比べるために、ゲームのモデルを同じ照明で拡大しました。下の走行画面では実際のゲーム内の見え方を確認できます。</p></details>
<details id="parkStudy" class="biscuit-study" hidden><summary>変更前後を画像で見る</summary><img src="park-proportions.webp" alt="左はv24、右はv25。入口、通過中、5匹の隊列を同じ位置から比べた確認用イメージ" width="820" height="1436" loading="lazy" style="max-width:580px;margin-top:8px"></details>
<p id="motionControls" hidden><button id="replayTunnel" type="button">入口から出口まで再生</button></p>
<div class="versions" aria-label="表示する版"><button data-version="before">変更前 · v28</button><button data-version="after">確認版 · v29</button></div>
<div class="screens"><figure data-id="before"><figcaption>変更前 · v28</figcaption><div class="window"></div></figure><figure data-id="after"><figcaption>確認版 · v29</figcaption><div class="window"></div></figure></div>
</main><script type="module">
const scenes={paused:'同じ地点で一時停止した画面です。上の進行バーの現在地マーカーを見比べられます。',wall:'赤柴がトンネル内で左へスワイプした場面です。再生すると、壁に触れて減速し、中央へ戻る様子を確認できます。',swipe:'トンネル手前で左にスワイプした直後です。再生すると、左右に移るときのしっぽと道の向きを比べられます。',snack:'同じ赤柴がおやつに近づく瞬間です。道のおやつと、上下の骨のマークを見比べられます。',midpark:'公園の約半分。v21で遠景の丘が道にかかっていた直線です。',group:'5匹で最初の丸太に近づく場面です。犬の間隔と、丸太やおやつの見え方を比べられます。',entrance:'同じ位置から、入口の丸み、おやつ、走行中の赤柴の大きさを比べられます。',tunnel:'同じ赤柴が公園の最後のトンネルをくぐります。通過中の一歩を表示しています。',dog:'同じ犬種・毛色の犬選び画面です。正面寄り・横・後ろに切り替えて、顔や耳、スカーフの巻き方を見比べられます。',log:'同じ入力で走った公園の直線です。最初のハードルが今回の丸太に当たります。',turn:'同じ走行で、最初の右カーブの予告が出た場面です。'};
import {breeds} from '../breeds.js';
const params=new URL(location.href).searchParams;
const picker=document.getElementById('comparisonDog');
const view=document.getElementById('dogView'),baselinePicker=document.getElementById('dogBaseline');
view.value=['side','back'].includes(params.get('view'))?params.get('view'):'front';
baselinePicker.value=params.get('from')==='v20'?'v20':'v28';
for(const [control,param] of [[view,'view'],[baselinePicker,'from']]){
  control.onchange=()=>{const url=new URL(location.href);url.searchParams.set(param,control.value);history.replaceState(null,'',url);render()};
}
for(const breed of breeds)picker.add(new Option(breed.name,breed.id));
picker.value=breeds.find(b=>b.id===params.get('breed'))?.id??'shiba';
picker.onchange=()=>{const url=new URL(location.href);url.searchParams.set('breed',picker.value);history.replaceState(null,'',url);render()};
let scene=Object.hasOwn(scenes,params.get('scene'))?params.get('scene'):'dog',version='after';
let replay=0,playing=false;
const narrow=matchMedia('(max-width:660px)');
function render(){
  const compareProportions=['tunnel','entrance','group'].includes(scene);
  const phoneSized=compareProportions||['swipe','wall','paused'].includes(scene);
  document.querySelector('.screens').classList.toggle('phone-sized',phoneSized);
  const beforePage=scene==='dog'&&baselinePicker.value==='v28'?'v28':['wall','paused'].includes(scene)?'v26':scene==='swipe'?'v25':compareProportions?'v24':['snack','midpark'].includes(scene)?'v21':'before';
  const baseline='変更前 · '+(beforePage==='before'?'v20':beforePage);
  document.getElementById('parkStudy').hidden=!compareProportions;
  const canReplay=['tunnel','swipe','wall'].includes(scene);
  document.getElementById('motionControls').hidden=!canReplay;
  document.getElementById('replayTunnel').textContent=scene==='wall'?'壁に当たる場面を再生':scene==='swipe'?'左右スワイプを再生':'入口から出口まで再生';
  document.querySelector('button[data-version="before"]').textContent=baseline;
  document.querySelector('figure[data-id="before"] figcaption').textContent=baseline;
  document.getElementById('description').textContent=scenes[scene];
  document.getElementById('biscuitStudy').hidden=scene!=='snack';
  document.getElementById('dogPicker').hidden=scene!=='dog';
  document.getElementById('modelStudy').hidden=scene!=='dog';
  const dogID=scene==='dog'?picker.value:'shiba';
  const game=document.getElementById('play');game.href=scene==='dog'?'../?trial='+dogID:'../?play=park&trial=shiba';
  game.textContent=scene==='dog'?'この相棒で遊ぶ':'赤柴で公園を走る';
  document.querySelectorAll('[data-scene]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.scene===scene));
  document.querySelectorAll('[data-version]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.version===version));
  document.querySelectorAll('figure').forEach(f=>{
    const v=f.dataset.id,visible=!narrow.matches||v===version;
    f.classList.toggle('shown',v===version);
    const box=f.querySelector('.window');
    if(!visible){box.replaceChildren();return}
    const src=(v==='before'?beforePage:'after')+'.html?scene='+scene+'&breed='+dogID+'&view='+view.value+(canReplay&&playing?'&replay='+replay:'');
    let frame=box.firstElementChild;
    if(!frame||frame.getAttribute('src')!==src){
      frame=document.createElement('iframe');frame.src=src;frame.tabIndex=-1;
      frame.title=f.querySelector('figcaption').textContent+'・'+document.querySelector('[data-scene="'+scene+'"]').textContent;
      box.replaceChildren(frame);
    }
    frame.style.transform='scale('+box.clientWidth/(phoneSized?393:390)+')';
  });
}
document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>{playing=false;scene=b.dataset.scene;const url=new URL(location.href);url.searchParams.set('scene',scene);history.replaceState(null,'',url);render()});
document.querySelectorAll('[data-version]').forEach(b=>b.onclick=()=>{version=b.dataset.version;playing=false;render()});
new ResizeObserver(render).observe(document.querySelector('.screens'));narrow.addEventListener('change',()=>{playing=false;render()});render();
document.getElementById('replayTunnel').onclick=()=>{replay++;playing=true;render()};
window.addEventListener('message',e=>{
  if(!playing||e.origin!==location.origin||e.data?.ready!==String(replay))return;
  const frames=[...document.querySelectorAll('.window iframe')];
  const source=frames.find(f=>f.contentWindow===e.source);
  if(!source)return;
  source.dataset.ready=String(replay);
  if(frames.every(f=>f.dataset.ready===String(replay))){
    const start=performance.timeOrigin+performance.now()+120;
    frames.forEach(f=>f.contentWindow.postMessage({start,replay:String(replay)},location.origin));
  }
});
</script></body></html>
````

### `dist/review/replay.js`

````javascript
export const lastFrame={dog:100,log:401,group:401,turn:740,snack:403,midpark:1404,entrance:2227,tunnel:2268,swipe:2240,wall:2261,paused:1404};

// A single recording drives both versions, including the bends and manual dashes
// that take the Shiba to the two places identified during the phone playtest.
const keys=new Map([
  [183,'ArrowDown'],[213,'ArrowDown'],[243,'ArrowDown'],[273,'ArrowDown'],
  [401,'ArrowRight'],[408,'ArrowLeft'],[431,'ArrowUp'],
  [741,'ArrowRight'],[742,' '],[977,' '],[1126,'ArrowLeft'],[1238,' '],
  [1444,' '],[1521,'ArrowLeft'],[1678,' '],[2032,'ArrowRight'],[2084,' '],[2265,' ']
]);
const swipeKeys=new Map([[2232,'ArrowLeft'],[2241,'ArrowRight'],[2288,'ArrowRight'],[2305,'ArrowLeft']]);
export function recordedKey(frame,scene){
 if(scene==='wall' && frame===2256)return 'ArrowLeft';
 if(scene==='wall' && frame===2265)return null;
 return (scene==='swipe'?swipeKeys.get(frame):null)??keys.get(frame)??null;
}
````

### `dist/review/v20/app.js`

````javascript
import * as THREE from '../../assets/three.module.js';
import { courses, coursesFor, coursePage, canPlay } from '../../courses.js';
import { courseBest, formatTime } from '../../course-records.js';
import { makeCourseScene } from '../../course-scene.js';
import { mountRace } from './race-game.js';
import { helpContent } from '../../help-content.js';
import { modes } from '../../modes.js';
import { breeds } from '../../breeds.js';
import { makeDog } from '../../dog-model.js';
const safeLoad=()=>{try{const s=JSON.parse(localStorage.getItem('wan-run-dog')||'{}');return s&&typeof s==='object'?s:{}}catch{return {}}};
const saved=safeLoad();let selected=breeds.find(x=>x.id===saved.breed)||breeds.find(x=>x.id==='pomeranian'),coatIndex=Number.isInteger(saved.coat)&&saved.coat>=0&&saved.coat<3?saved.coat:0;
document.body.dataset.layout='sheet';
let draftBreed=null,noticeTimer,raceController=null;
const loadMode=()=>{try{const value=localStorage.getItem('wan-run-mode');return modes.some(m=>m.id===value)?value:null}catch{return null}};
let committedMode=loadMode(),activeMode=committedMode||'race';
const loadCourses=()=>{try{const value=JSON.parse(localStorage.getItem('wan-run-courses')||'{}');return value&&typeof value==='object'?value:{}}catch{return {}}};
const coursePrefs=loadCourses(),activeCourses={},confirmedCourses={},coursePages={};
for(const m of modes){const options=coursesFor(m.id),valid=options.find(c=>c.id===coursePrefs[m.id]);activeCourses[m.id]=valid?.id||options[0].id;if(valid)confirmedCourses[m.id]=valid.id;coursePages[m.id]=Math.floor(options.findIndex(c=>c.id===activeCourses[m.id])/3)}
const isPlaying=screen=>screen==='race'||screen==='agility';
function screenFromHash(){if(location.hash==='#agility')return committedMode==='agility'&&canPlay('agility',activeCourses.agility)?'agility':committedMode?'course':'mode';if(location.hash==='#race')return committedMode==='race'&&canPlay('race',activeCourses.race)?'race':committedMode?'course':'mode';return location.hash==='#course'?(committedMode?'course':'mode'):location.hash==='#mode'?'mode':'dog'}
function confirmMode(mode){
 committedMode=activeMode=mode;
 try{localStorage.setItem('wan-run-mode',mode);return true}
 catch{return false}
}
const entryUrl=new URL(location.href);
const linkedCourse=courses.find(course=>course.id===entryUrl.searchParams.get('play')&&canPlay(course.mode,course.id));
if(linkedCourse){
 confirmMode(linkedCourse.mode);
 confirmCourse(linkedCourse.id);
 entryUrl.searchParams.delete('play');
 entryUrl.hash=linkedCourse.mode;
 history.replaceState({},'',entryUrl);
}
let currentScreen=screenFromHash();
history.replaceState({...history.state,wanScreen:currentScreen,mode:activeMode},'',location.href);
const panel=document.getElementById('panel'),dialog=document.getElementById('breedDialog');
let coursePreview,courseAngle=0;
let scene,camera,renderer,model,tail,pedestal,angle=.48,dragging=false,lastX=0,thumbs={};const canvas=document.getElementById('dogCanvas');const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const mat=color=>new THREE.MeshStandardMaterial({color,roughness:1,metalness:0});
function initScene(){
 try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
 scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(34,1,.1,30);camera.position.set(3.1,2.2,4.2);camera.lookAt(0,.85,0);
 scene.add(new THREE.HemisphereLight('#fff8e6','#b1c0a1',2.4));const sun=new THREE.DirectionalLight('#fff7e5',3.0);sun.position.set(-3,6,5);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-3;sun.shadow.camera.right=3;sun.shadow.camera.top=3;sun.shadow.camera.bottom=-3;sun.shadow.normalBias=.025;sun.shadow.bias=-.0001;scene.add(sun);
 const stage=new THREE.Mesh(new THREE.CylinderGeometry(1.48,1.38,.14,64),mat('#c4d2af'));stage.position.y=-.075;stage.receiveShadow=true;scene.add(stage);pedestal=stage;
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.ShadowMaterial({color:'#475740',opacity:.14}));floor.rotation.x=-Math.PI/2;floor.position.y=-.15;floor.receiveShadow=true;scene.add(floor);
 for(const b of breeds){const dog=makeDog(b,0);dog.rotation.y=.42;scene.add(dog);renderer.setSize(220,150,false);camera.aspect=220/150;camera.updateProjectionMatrix();renderer.render(scene,camera);thumbs[b.id]=canvas.toDataURL('image/png');scene.remove(dog);disposeModel(dog)}
 updateModel();new ResizeObserver(resize).observe(document.getElementById('viewer'));resize();requestAnimationFrame(tick);
 }catch(e){console.error('3D preview unavailable',e);canvas.hidden=true;document.getElementById('webglFallback').hidden=false;document.querySelector('.viewer-help').hidden=true;document.getElementById('resetView').hidden=true}}
function disposeModel(obj){const materials=new Set();obj.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material)materials.add(o.material)});materials.forEach(m=>m.dispose())}
function resize(){
 if(!renderer)return;const box=document.getElementById('viewer').getBoundingClientRect();if(box.width<1||box.height<1)return;
 renderer.setSize(box.width,box.height,false);camera.aspect=box.width/Math.max(box.height,1);
 if(currentScreen==='course'){const distance=Math.max(1,1.05/camera.aspect);camera.position.set(10.5*distance,11*distance,15.5*distance);camera.lookAt(0,.1,0)}
 else{const distance=Math.max(1,.9/camera.aspect);camera.position.set(3.1*distance,2.1*distance,4.2*distance);camera.lookAt(0,.85,0)}
 camera.updateProjectionMatrix();
}
function updateModel(breed=selected,coat=coatIndex){if(!scene)return;if(model){scene.remove(model);disposeModel(model)}model=makeDog(breed,coat);model.rotation.y=angle;model.position.y=-.005;tail=model.userData.tail;scene.add(model)}
function tick(t){if(isPlaying(currentScreen)){requestAnimationFrame(tick);return}if(model){model.rotation.y=angle;if(tail&&!reduced)tail.rotation.y=Math.sin(t*.003)*.13}if(coursePreview)coursePreview.rotation.y=courseAngle;if(!window.parkReview?.skipDraw)renderer.render(scene,camera);requestAnimationFrame(tick)}
canvas.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(dragging){rotatePreview((e.clientX-lastX)*.012);lastX=e.clientX}});for(const ev of ['pointerup','pointercancel'])canvas.addEventListener(ev,()=>dragging=false);canvas.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();rotatePreview(e.key==='ArrowLeft'?-.15:.15)}});function rotatePreview(delta){if(currentScreen==='course')courseAngle+=delta;else angle+=delta}
document.getElementById('resetView').addEventListener('click',()=>{if(currentScreen==='course')courseAngle=0;else angle=.48});
function persist(){try{localStorage.setItem('wan-run-dog',JSON.stringify({breed:selected.id,coat:coatIndex}));return true}catch{return false}}
function fullName(b){return b.id==='retriever'?'ゴールデンレトリバー':b.name}
function updateCaption(breed=selected,coat=coatIndex){document.getElementById('dogTitle').textContent=fullName(breed);document.getElementById('dogEnglish').textContent=breed.en;document.getElementById('coatPill').textContent=breed.coats[coat][0];document.getElementById('dogDescription').textContent=breed.desc;document.getElementById('breedNumber').textContent=`${String(breeds.indexOf(breed)+1).padStart(2,'0')} / 08`}
function breedButtons(){return breeds.map(b=>`<button class="breed" data-breed="${b.id}" aria-pressed="${b.id===draftBreed?.id}" aria-label="${fullName(b)}">${thumbs[b.id]?`<img src="${thumbs[b.id]}" alt="" width="220" height="150">`:'<div class="image-fallback" aria-hidden="true">●</div>'}<span>${b.name}</span></button>`).join('')}
function pickerMarkup(){return `<button id="openPicker" class="open-picker" aria-haspopup="dialog" aria-controls="breedDialog" aria-label="犬種の一覧を開く。選択中：${fullName(selected)}">${thumbs[selected.id]?`<img src="${thumbs[selected.id]}" alt="">`:''}<strong>${fullName(selected)}</strong><span class="picker-action">犬種を変更 <span aria-hidden="true">›</span></span></button>`}
function render(){
 document.body.dataset.screen=currentScreen;
 if(isPlaying(currentScreen)){
  const courseId=activeCourses[activeMode];
  if(raceController&&(raceController.mode!==currentScreen||raceController.courseId!==courseId)){
   raceController.dispose();
   raceController=null;
  }
  if(!raceController)raceController=mountRace({
   container:document.getElementById('raceRoot'),breed:selected,coat:coatIndex,mode:currentScreen,courseId,
   onExit:()=>goBack('course'),onNextCourse:advanceCourse
  });
  return;
 }
 if(raceController){raceController.dispose();raceController=null}

 document.querySelector('.header h1').textContent=currentScreen==='course'?'コースを選ぶ':currentScreen==='mode'?'モードを選ぶ':'犬と毛色を選ぶ';
 document.querySelector('.version').textContent=currentScreen==='course'?`${coursesFor(activeMode).length}コース`:currentScreen==='mode'?'2つの遊び方':'8犬種 · 3色ずつ';
 panel.setAttribute('aria-label',currentScreen==='course'?'コースの選択':currentScreen==='mode'?'モードの選択':'犬種と毛色の選択');
 updateCaption();
 if(currentScreen==='course'){renderCourse();return}
 if(coursePreview)coursePreview.visible=false;if(model)model.visible=true;if(pedestal)pedestal.visible=true;
 document.querySelector('.showcase').setAttribute('aria-label','選んだ犬の立体プレビュー');document.querySelector('.showcase-top span').textContent='いっしょに走る相棒';
 document.querySelector('.viewer-help').textContent='↔ ドラッグで回転';canvas.setAttribute('aria-label','犬の3Dモデル。ドラッグまたは矢印キーで回転できます');document.getElementById('resetView').setAttribute('aria-label','犬の向きを元に戻す');
 document.getElementById('webglFallback').textContent='この端末では3D表示を利用できません。犬種と毛色は選択できます。';
 resize();
 if(currentScreen==='mode'){renderMode();return}
 if(pedestal)pedestal.material.color.set('#c4d2af');
 panel.innerHTML=`${pickerMarkup()}<div class="coat-picker"><div class="swatch-label">毛色<span id="colorLabel">${selected.coats[coatIndex][0]}</span></div><div class="swatches" role="group" aria-label="毛色">${selected.coats.map((c,i)=>`<button class="swatch" data-coat="${i}" title="${c[0]}" aria-label="${c[0]}" aria-pressed="${i===coatIndex}" style="--swatch:linear-gradient(135deg,${c[1]} 55%,${c[2]} 55%)"></button>`).join('')}</div></div><div class="confirm-area"><button class="primary" id="choose">モード選択へ<span aria-hidden="true">→</span></button></div>`;
 panel.querySelectorAll('[data-coat]').forEach(btn=>btn.addEventListener('click',()=>{coatIndex=Number(btn.dataset.coat);updateModel();persist();render();panel.querySelector(`[data-coat="${coatIndex}"]`).focus({preventScroll:true})}));
 document.getElementById('choose').addEventListener('click',()=>{const stored=persist();navigate('mode');if(!stored)showNotice('犬の選択は引き継ぎました。端末への保存は利用できません。')});
 document.getElementById('openPicker').addEventListener('click',openBreedPicker);
}
function navigate(screen,{replace=false}={}){
 if(screen===currentScreen)return;
 const url=new URL(location.href);url.hash=screen==='dog'?'':screen;
 history[replace?'replaceState':'pushState']({wanScreen:screen,mode:activeMode,fromScreen:currentScreen},'',url.pathname+url.search+url.hash);
 displayScreen(screen);
}
function displayScreen(screen){
 clearTimeout(noticeTimer);document.getElementById('notice').hidden=true;
 currentScreen=screen;render();
 if(isPlaying(screen))return;const title=document.querySelector('.header h1');title.setAttribute('tabindex','-1');title.focus({preventScroll:true});
}
function goBack(screen){if(history.state?.fromScreen===screen||(screen==='dog'&&history.state?.fromDog))history.back();else navigate(screen,{replace:true})}
function backToDog(){goBack('dog')}
window.addEventListener('popstate',()=>{if(modes.some(m=>m.id===history.state?.mode))activeMode=history.state.mode;displayScreen(screenFromHash())});
function renderMode(){
 const mode=modes.find(m=>m.id===activeMode);
 if(pedestal)pedestal.material.color.set(mode.color);
 panel.innerHTML=`<div class="mode-topline"><button id="backToDog" class="back-link">← 犬を選び直す</button></div><div class="mode-options" role="group" aria-label="遊び方">${modes.map(m=>`<button class="mode-option" data-mode="${m.id}" aria-pressed="${m.id===activeMode}" aria-label="${m.name}：${m.subtitle}"><span class="mode-art">${m.art}</span><span class="mode-copy"><strong>${m.name}</strong><span class="mode-subtitle">${m.subtitle}</span></span><span class="mode-check" aria-hidden="true">${m.id===activeMode?'✓':''}</span></button>`).join('')}</div><div class="confirm-area"><button class="primary" id="chooseMode">コース選択へ<span aria-hidden="true">→</span></button></div>`;
 document.getElementById('backToDog').addEventListener('click',backToDog);
 panel.querySelectorAll('[data-mode]').forEach(button=>button.addEventListener('click',()=>{activeMode=button.dataset.mode;history.replaceState({...history.state,mode:activeMode},'',location.href);renderMode();panel.querySelector(`[data-mode="${activeMode}"]`).focus({preventScroll:true})}));
 document.getElementById('chooseMode').addEventListener('click',()=>{const stored=confirmMode(activeMode);navigate('course');if(!stored)showNotice('モードは引き継ぎました。端末への保存は利用できません。')});
}
function updateCoursePreview(course){
 if(!scene)return;
 const key=`${course.id}:${selected.id}:${coatIndex}`;
 if(coursePreview?.userData.previewKey!==key){if(coursePreview){scene.remove(coursePreview);disposeModel(coursePreview)}coursePreview=makeCourseScene(course,selected,coatIndex);coursePreview.userData.previewKey=key;scene.add(coursePreview)}
 if(model)model.visible=false;if(pedestal)pedestal.visible=false;coursePreview.visible=true;resize();
}
function courseButton(course, selectedId){
 const playable=canPlay(course.mode,course.id);
 const best=courseBest(course.id);
 const record=best===null?'記録なし':formatTime(best);
 const detail=playable?(best===null?record:'自己ベスト '+record):'プレビュー';
 const recordText=best===null?record:'<span>ベスト</span> '+record;
 return `<button class="course-choice" data-course="${course.id}" aria-pressed="${course.id===selectedId}"
  aria-label="${course.name}、${course.difficulty}、${detail}" style="--course-color:${course.color}">
  <span class="course-level">${course.difficulty}</span><strong>${course.shortName}</strong>
  <span class="course-record" data-has-best="${best!==null}">${playable?recordText:'プレビュー'}</span></button>`;
}
function confirmCourse(courseId){
 activeCourses[activeMode]=confirmedCourses[activeMode]=courseId;
 const index=coursesFor(activeMode).findIndex(course=>course.id===courseId);
 coursePages[activeMode]=Math.floor(index/3);
 try{localStorage.setItem('wan-run-courses',JSON.stringify(confirmedCourses));return true}
 catch{return false}
}
function advanceCourse(courseId){
 confirmCourse(courseId);
 render();
}
function renderCourse(){
 const list=coursesFor(activeMode),mode=modes.find(m=>m.id===activeMode),course=list.find(c=>c.id===activeCourses[activeMode])||list[0];
 const pages=Math.ceil(list.length/3);coursePages[activeMode]=Math.min(Math.max(0,coursePages[activeMode]),pages-1);
 const page=coursePages[activeMode],visible=coursePage(activeMode,page),isConfirmed=confirmedCourses[activeMode]===course.id,playable=canPlay(activeMode,course.id);
 document.querySelector('.showcase').setAttribute('aria-label','選んだコースの立体プレビュー');document.querySelector('.showcase-top span').textContent='コースのプレビュー';
 document.getElementById('dogTitle').textContent=course.name;document.getElementById('dogEnglish').textContent=mode.name;
 document.getElementById('coatPill').textContent=course.difficulty;document.getElementById('dogDescription').textContent=course.description;
 document.getElementById('breedNumber').textContent=`${String(list.indexOf(course)+1).padStart(2,'0')} / ${String(list.length).padStart(2,'0')}`;
 document.querySelector('.viewer-help').textContent='↔ ドラッグでコースを回転';canvas.setAttribute('aria-label',`${course.name}の立体プレビュー。ドラッグまたは矢印キーで回転できます`);document.getElementById('resetView').setAttribute('aria-label','コースの向きを元に戻す');
 document.getElementById('webglFallback').textContent='この端末では3D表示を利用できません。コースの説明を見て選べます。';
 updateCoursePreview(course);
 panel.innerHTML=`<div class="mode-topline"><button id="backToMode" class="back-link">← モードを選び直す</button><span class="current-mode">${mode.name}</span>${pages>1?`<div class="course-pager"><button id="previousCourses" ${page===0?'disabled':''} aria-label="前のコース一覧">←</button><span>${page+1} / ${pages}</span><button id="nextCourses" ${page===pages-1?'disabled':''} aria-label="次のコース一覧">→</button></div>`:''}</div><div class="course-choices" role="group" aria-label="${mode.name}のコース">${visible.map(c=>courseButton(c,course.id)).join('')}</div><div class="course-info" aria-live="polite"><div class="course-features">${course.features.map(f=>`<span>${f}</span>`).join('')}</div></div><div class="course-partner"><span>今回の相棒</span><strong>${fullName(selected)}</strong><span>${selected.coats[coatIndex][0]}</span></div><div class="confirm-area"><button class="primary" id="chooseCourse">${playable?'このコースで走る':isConfirmed?'このコースを選択済み':'このコースに決定'}<span>${isConfirmed?'✓':'→'}</span></button></div>`;
 document.getElementById('backToMode').addEventListener('click',()=>goBack('mode'));
 panel.querySelectorAll('[data-course]').forEach(button=>button.addEventListener('click',()=>{activeCourses[activeMode]=button.dataset.course;renderCourse();panel.querySelector(`[data-course="${activeCourses[activeMode]}"]`).focus({preventScroll:true})}));
 if(pages>1)for(const [id,step]of [['previousCourses',-1],['nextCourses',1]])document.getElementById(id).addEventListener('click',()=>{coursePages[activeMode]+=step;activeCourses[activeMode]=coursePage(activeMode,coursePages[activeMode])[0].id;renderCourse();document.getElementById(step>0?'previousCourses':'nextCourses').focus({preventScroll:true})});
 document.getElementById('chooseCourse').addEventListener('click',()=>{const stored=confirmCourse(course.id);if(playable){navigate(activeMode)}else{renderCourse();document.getElementById('chooseCourse').focus({preventScroll:true});showNotice(`${course.name}を選びました${stored?'':'（端末への保存は利用できません）'}`)}});
}
function showNotice(message){clearTimeout(noticeTimer);const notice=document.getElementById('notice');notice.textContent=message;notice.hidden=false;noticeTimer=setTimeout(()=>{notice.hidden=true;notice.textContent=''},3500)}
function openBreedPicker(){
 clearTimeout(noticeTimer);document.getElementById('notice').hidden=true;
 draftBreed=selected;renderDialog();dialog.showModal();dialog.querySelector(`[data-breed="${draftBreed.id}"]`).focus({preventScroll:true});
}
function renderDialog(){
 document.getElementById('dialogBreeds').innerHTML=breedButtons();
 document.getElementById('dialogSelection').textContent=`候補：${fullName(draftBreed)}`;
 document.getElementById('dialogBreeds').querySelectorAll('[data-breed]').forEach(btn=>btn.addEventListener('click',()=>{
  draftBreed=breeds.find(b=>b.id===btn.dataset.breed);
  const previewCoat=draftBreed.id===selected.id?coatIndex:0;
  updateModel(draftBreed,previewCoat);updateCaption(draftBreed,previewCoat);renderDialog();
  dialog.querySelector(`[data-breed="${draftBreed.id}"]`).focus({preventScroll:true});
 }));
}
function cancelBreedPicker(){
 if(!draftBreed)return;
 const changed=draftBreed.id!==selected.id;draftBreed=null;
 updateModel();render();if(dialog.open)dialog.close();
 if(changed)showNotice('変更を取り消しました');
}
function commitBreedPicker(){
 if(!draftBreed)return;
 const changed=draftBreed.id!==selected.id;
 if(changed){selected=draftBreed;coatIndex=0}
 draftBreed=null;const stored=persist();updateModel();render();dialog.close();
 showNotice(`${fullName(selected)}${changed?'に変更しました':'を選択しました'}${stored?'':'（端末への保存は利用できません）'}`);
}
document.getElementById('closeDialog').addEventListener('click',cancelBreedPicker);
document.getElementById('doneDialog').addEventListener('click',commitBreedPicker);
dialog.addEventListener('cancel',e=>{e.preventDefault();cancelBreedPicker()});
dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)cancelBreedPicker()});
dialog.addEventListener('close',()=>{if(draftBreed)cancelBreedPicker();document.getElementById('openPicker')?.focus({preventScroll:true})});
const helpDialog=document.getElementById('helpDialog');
document.getElementById('openHelp').addEventListener('click',()=>{document.getElementById('helpTitle').textContent=currentScreen==='dog'?'犬選び':'遊び方';document.getElementById('helpContent').innerHTML=helpContent(activeMode,currentScreen==='dog'?'dog':'game',activeCourses[activeMode]);helpDialog.showModal();document.getElementById('closeHelp').focus({preventScroll:true})});
document.getElementById('closeHelp').addEventListener('click',()=>helpDialog.close());
helpDialog.addEventListener('cancel',e=>{e.preventDefault();helpDialog.close()});
helpDialog.addEventListener('click',e=>{if(e.target!==helpDialog)return;const r=helpDialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)helpDialog.close()});
helpDialog.addEventListener('close',()=>document.getElementById('openHelp').focus({preventScroll:true}));
initScene();render();
````

### `dist/review/v20/race-game.js`

````javascript
import * as T from '../../assets/three.module.js';
import {makeDog} from '../../dog-model.js';
import {footingFor,poseLegs} from '../../dog-gait.js';
import {breeds} from '../../breeds.js';
import {RACE,RaceSimulation,gestureAction} from '../../race-sim.js';
import {routePoint,cornerAt} from '../../race-route.js';
import {AgilitySimulation,AGILITY} from '../../agility-sim.js';
import {courses,nextPlayableCourse} from '../../courses.js';
import {makeRaceTrack} from './race-track.js';
import {makeAgilityField} from '../../agility-field.js';
import {chaseCameraPose} from '../../chase-camera.js';
import {helpContent} from '../../help-content.js';
import {A_FRAME,aFrameCameraLift} from '../../a-frame.js';
import {SEESAW} from '../../seesaw.js';
import {SLALOM,slalomPoleS,slalomSide} from '../../slalom.js';
import {finishRecord,formatTime as seconds} from '../../course-records.js';
const boneIcon='<svg viewBox="0 0 32 18" aria-hidden="true"><path d="M7 5C3-2-4 7 3 9c-7 2 0 11 4 4h18c4 7 11-2 4-4 7-2 0-11-4-4Z" fill="currentColor"/></svg>';
function faultText(event,sim){
 if(event.reason==='off-line')return sim.layout.obstacles.find(o=>o.id===event.id)?.type==='hoop'?'輪っかの横を通過':'ハードルの横を通過';
 if(event.reason==='slalom'){
  const firstMiss=sim.slaloms.get(event.id).passed.indexOf(false);
  return firstMiss>=0?`ポール${firstMiss+1}本目をミス`:'ポールの通過ミス';
 }
 const labels={'jump-low':'ジャンプが届かず','tunnel-entry':'トンネルの入口を外れた','tunnel-exit':'トンネルの出口を外れた',
  'board-entry':'シーソーに乗れず','board-stop':'停止位置を通過','ramp-entry':'坂の入口を外れた','ramp-jump':'坂の入口でジャンプ'};
 return labels[event.reason]??'ミス';
}
export function mountRace({container,breed,coat,onExit,onNextCourse,mode='race',courseId=mode==='agility'?'first-field':'park'}){
 const agility=mode==='agility',beach=mode==='race'&&courseId==='beach',forest=mode==='race'&&courseId==='forest',sim=agility?new AgilitySimulation(courseId):new RaceSimulation(courseId),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const allowShortFlick=beach||courseId==='hill-field';
 const point=sim.layout.point||routePoint,length=sim.layout.length||RACE.length,obstacleCount=sim.layout.obstacles.length,courseName=courses.find(course=>course.id===courseId)?.name||(agility?'はじめての広場':'公園');
 let renderer,scene,camera,light,dogs=[],track,frameId,last=0,uiTime=0,disposed=false,pointer=null,messageTimer,helpReturn=null;
 let countdownLabel='',turnLabel='',cameraOffset=6;
 const rivals=agility?'':sim.cpus.map((_,i)=>`<i class="rival-marker" style="--row:${i}" aria-hidden="true"></i>`).join('');
 const playerMarker=agility?'':'<i class="player-marker" aria-hidden="true"></i>';
 container.hidden=false;container.dataset.mode=mode;container.className='race-root';container.setAttribute('aria-label',courseName);
 container.innerHTML=`<canvas id="raceCanvas" tabindex="0" aria-label="${agility?'アジリティ。左右スワイプで移動、上でジャンプ、下で停止、タップで再開。':courseName+'レース。左右スワイプで移動と右左折、上でジャンプ、下でブレーキ、ゲージ満タン時にタップでダッシュ。'}"></canvas>
 <div class="race-hud"><div class="race-top"><div class="race-rank"><strong id="raceRank">${agility?'0':'1'}</strong><span>${agility?`/ ${obstacleCount} クリア`:`位 / ${sim.cpus.length+1}匹`}</span></div><div class="race-treats">${agility?'<span class="fault-label">ミス</span>':boneIcon}<span id="raceTreats">0</span></div><button id="pauseRace" aria-label="一時停止">Ⅱ</button></div><div class="race-progress" role="progressbar" aria-label="コースの進み具合" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="raceProgressFill"></div>${rivals}${playerMarker}</div><div class="race-course-label"><span>${courseName}</span><span id="raceClock">00:00.0</span></div></div>
 <div id="raceTurnCue" class="race-turn-cue" role="status" hidden></div><div id="raceCount" class="race-count" aria-live="polite"></div><div id="raceFeedback" class="race-feedback" role="status"></div>
 ${agility?`<div class="agility-bottom"><div class="agility-steps" aria-label="障害物の結果">${sim.layout.obstacles.map((o,i)=>`<span data-step="${o.id}" aria-label="障害物${i+1} 未通過">${i+1}</span>`).join('')}</div><div id="agilityStopped" class="agility-stopped" role="status" hidden>停止中 <span>タップで再開</span></div></div>`:`<div class="race-bottom"><div class="race-gauge-label"><span>${boneIcon}<b id="raceDashHint">ダッシュ</b></span><strong id="raceGaugeCount">0 / 20</strong></div><div id="raceGauge" class="race-gauge" role="meter" aria-label="ダッシュゲージ" aria-valuemin="0" aria-valuemax="20" aria-valuenow="0"><div id="raceGaugeFill"></div></div></div>`}
 <div id="raceOverlay" class="race-overlay" role="dialog" aria-modal="true" aria-label="ゲームのメニュー"></div>`;
 const canvas=container.querySelector('#raceCanvas'),overlay=container.querySelector('#raceOverlay'),q=id=>container.querySelector('#'+id);
 const rivalMarkers=container.querySelectorAll('.rival-marker'),playerPin=container.querySelector('.player-marker');
 function setup(){
  renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const skyColor=forest?'#c1cfb0':beach?'#b5dce4':agility?'#bad7e3':'#c5ddd7';
  scene=new T.Scene();scene.background=new T.Color(skyColor);scene.fog=new T.Fog(skyColor,agility||beach?85:42,agility||beach?175:110);camera=new T.PerspectiveCamera(60,1,.1,180);
  scene.add(new T.HemisphereLight('#fff8e8','#8d9f75',2.5));light=new T.DirectionalLight('#fff0d7',2.7);light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:45});light.shadow.bias=-.0003;light.shadow.normalBias=.03;scene.add(light,light.target);
  track=agility?makeAgilityField(sim.layout):makeRaceTrack(sim.layout);scene.add(track.root);
  const roster=agility?[breed]:[breed,...breeds.filter(b=>b.id!==breed.id).slice(0,sim.cpus.length)];
  dogs=roster.map((b,i)=>{const dog=makeDog(b,i===0?coat:0);dog.scale.setScalar(.76);dog.rotation.y=Math.PI;dog.traverse(o=>{if(o.isMesh)o.castShadow=i===0});scene.add(dog);const shadow=new T.Mesh(new T.CircleGeometry(.8,24),new T.MeshStandardMaterial({color:'#536848',transparent:true,opacity:.15}));shadow.rotation.x=-Math.PI/2;scene.add(shadow);return {dog,shadow}});
  camera.position.set(0,2.8,6);resize();
 }
 function resize(){if(!renderer)return;const r=container.getBoundingClientRect();if(r.width<1||r.height<1)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.fov=r.width>r.height?54:60;camera.updateProjectionMatrix()}
 function message(text){clearTimeout(messageTimer);q('raceFeedback').textContent=text;messageTimer=setTimeout(()=>q('raceFeedback')&&(q('raceFeedback').textContent=''),1300)}
 function ready(){
  helpReturn=null;q('pauseRace').hidden=true;overlay.hidden=false;
  overlay.innerHTML=`<div class="race-modal race-ready"><span class="race-overline">${agility?'アジリティ':'レース'}</span><h2>${courseName}</h2><div class="start-summary"><span>${breed.name}</span><span>${agility?`${obstacleCount}つの障害物`:`${sim.cpus.length+1}匹で競走`}</span></div><button id="startRun" class="primary">走る <span>→</span></button><div class="race-menu-links"><button id="readyHelp" class="race-secondary">遊び方</button><button id="readyExit" class="race-secondary">コース選択</button></div></div>`;
  q('startRun').onclick=begin;q('readyExit').onclick=onExit;q('readyHelp').onclick=()=>showHelp(ready);q('startRun').focus({preventScroll:true});
 }
 function showHelp(returnTo){
  helpReturn=returnTo;overlay.hidden=false;overlay.innerHTML=`<div class="race-modal game-help"><div class="help-heading"><h2>遊び方</h2><button id="closeGameHelp" class="close" aria-label="遊び方を閉じる">×</button></div>${helpContent(mode,'game',courseId)}</div>`;
  q('closeGameHelp').onclick=closeHelp;q('closeGameHelp').focus({preventScroll:true});
 }
 function closeHelp(){const back=helpReturn;helpReturn=null;back?.()}
 function begin(){pointer=null;helpReturn=null;overlay.hidden=true;q('pauseRace').hidden=false;sim.start();updateHUD();canvas.focus({preventScroll:true})}
 function pause(){
  if(window.parkReview)return;
  pointer=null;sim.pause();if(sim.status!=='paused')return;helpReturn=null;overlay.hidden=false;
  overlay.innerHTML='<div class="race-modal"><h2>一時停止</h2><button id="resumeRun" class="primary">続ける <span>→</span></button><button id="restartRun" class="race-secondary">最初から</button><div class="race-menu-links"><button id="pauseHelp" class="race-secondary">遊び方</button><button id="pauseExit" class="race-secondary">コース選択</button></div></div>';
  q('resumeRun').onclick=()=>{overlay.hidden=true;sim.resume();last=performance.now();updateHUD();canvas.focus({preventScroll:true})};q('restartRun').onclick=restart;q('pauseExit').onclick=onExit;q('pauseHelp').onclick=()=>showHelp(pause);q('resumeRun').focus({preventScroll:true});updateHUD();
 }
 function restart(){sim.reset();track.resetTreats();camera.position.set(0,2.8,6);cameraOffset=6;last=performance.now();q('raceFeedback').textContent='';begin()}
 function result(){
  const r=sim.result,record=finishRecord(courseId,agility?r.total:r.time);
  const recordLabel=record.temporary?'今回のベスト':'自己ベスト';
  const recordRow=`<div class="result-record" data-record-state="${record.state}">
   <span class="record-pair">${recordLabel} <strong>${seconds(record.best)}</strong></span>
   <span class="record-delta">${record.label}</span></div>`;
  q('pauseRace').hidden=true;overlay.hidden=false;
  const stats=agility?`<div><span>走行タイム</span><strong>${seconds(r.time)}</strong></div><div><span>ペナルティ</span><strong>+${r.penalty}秒</strong></div><div><span>クリア</span><strong>${r.cleared} / ${obstacleCount}</strong></div><div><span>ミス</span><strong>${r.faults}回</strong></div>`:`<div><span>タイム</span><strong>${seconds(r.time)}</strong></div><div><span>おやつ</span><strong>${r.treats}個</strong></div><div><span>ダッシュ</span><strong>${r.dashes}回</strong></div><div><span>障害物のミス</span><strong>${r.hits}回</strong></div>`;
  const next=onNextCourse&&nextPlayableCourse(mode,courseId);
  const nextButton=next?`<button id="nextCourseRun" class="primary result-next" aria-label="次のコース「${next.name}」へ">${next.shortName}へ <span aria-hidden="true">→</span></button>`:'';
  overlay.innerHTML=`<div class="race-modal race-result"><span class="race-overline">${courseName}</span>${agility?`<div class="result-score">${r.total.toFixed(2)}<span>秒</span></div>`:`<div class="result-rank">${r.rank}<span>位 / ${sim.cpus.length+1}匹</span></div>`}<h2>${agility?(r.faults===0?'ノーミスで完走！':'完走！'):(r.rank===1?'いちばんでゴール！':'完走！')}</h2><div class="race-stats">${stats}</div>${agility?'':`<p class="race-turn-result">曲がり損ね ${r.turnMisses}回</p>`}${recordRow}<div class="result-actions"><button id="retryRun" class="primary">もう一度 <span aria-hidden="true">↻</span></button>${nextButton}</div><button id="resultExit" class="race-secondary">コース選択</button></div>`;
  if(next)q('nextCourseRun').onclick=()=>{if(!disposed)onNextCourse(next.id)};
  q('retryRun').onclick=restart;q('resultExit').onclick=onExit;q('retryRun').focus({preventScroll:true});
 }
 function updateHUD(){
  q('raceRank').textContent=agility?sim.cleared:sim.rank;q('raceTreats').textContent=agility?sim.faults:sim.treatCount;
  const progress=Math.min(100,sim.player.s/length*100);q('raceProgressFill').style.width=progress+'%';container.querySelector('.race-progress').setAttribute('aria-valuenow',Math.round(progress));q('raceClock').textContent=`${String(Math.floor(sim.time/60)).padStart(2,'0')}:${(sim.time%60).toFixed(1).padStart(4,'0')}`;
  if(agility){
   track?.update(sim);
   for(const o of sim.layout.obstacles){const el=container.querySelector(`[data-step="${o.id}"]`),done=sim.results.has(o.id),clear=sim.results.get(o.id);el.dataset.state=done?(clear?'clear':'miss'):'pending';el.textContent=done?(clear?'✓':'−'):o.id+1;el.setAttribute('aria-label',`障害物${o.id+1} ${done?(clear?'クリア':'ミス'):'未通過'}`)}
   q('agilityStopped').hidden=!(sim.stopped&&sim.status==='running'&&!sim.activeSeesaw);updateObstacleCue();
  }else{
   playerPin.style.left=progress+'%';
   sim.cpus.forEach((dog,i)=>{rivalMarkers[i].style.left=Math.max(0,Math.min(100,dog.s/length*100))+'%'});
   const boost=sim.player.boost>0,ready=sim.gauge===RACE.gaugeMax&&!boost;
   q('raceGaugeCount').textContent=boost?`${sim.player.boost.toFixed(1)}秒`:`${sim.gauge} / 20`;
   q('raceGaugeFill').style.width=sim.gauge/RACE.gaugeMax*100+'%';q('raceGauge').setAttribute('aria-valuenow',sim.gauge);
   container.classList.toggle('dash-ready',ready);container.classList.toggle('boosting',boost);q('raceDashHint').textContent=boost?'ダッシュ中':ready?'タップでダッシュ':'ダッシュ';updateTurnCue();
  }
  const label=sim.status==='countdown'?String(Math.ceil(sim.countdown)):'';if(label!==countdownLabel){countdownLabel=label;q('raceCount').textContent=label}
 }
 function updateTurnCue(){
  const cue=sim.status==='running'?sim.turnCue:null,el=q('raceTurnCue');el.hidden=!cue;container.classList.toggle('turn-visible',!!cue);if(!cue){turnLabel='';return}
  const right=cue.direction==='right',direction=right?'右':'左';
  const state=cue.waiting?'waiting':cue.armed?'armed':cue.active?'active':'ahead';
  const label=cue.waiting?`${direction}へスワイプ`:cue.armed?(sim.player.s>=cue.start?`${direction}カーブ`:`${direction}折 OK`):cue.active?`${direction}へスワイプ`:`この先 ${direction}カーブ`;
  const key=`${cue.id}:${state}:${label}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=state;
  el.innerHTML=`<strong aria-hidden="true">${right?'↱':'↰'}</strong><span><small>${cue.id+1} / ${sim.layout.turns.length}</small><b>${label}</b></span>${cue.armed?'<span class="turn-check" aria-hidden="true">✓</span>':''}`;
 }
 function updateObstacleCue(){
  const o=sim.status==='running'?sim.nextObstacle:null,el=q('raceTurnCue');el.hidden=!o;container.classList.toggle('turn-visible',!!o);if(!o){turnLabel='';return}
  const names={'a-frame':'Aフレーム',hurdle:'ハードル',hoop:'輪っか',tunnel:'トンネル',seesaw:'シーソー',slalom:'スラローム'},lane=o.lane<0?'左':o.lane>0?'右':'中央';
  const aligned=Math.abs(sim.player.x-o.lane*2)<(o.type==='seesaw'?.48:o.type==='a-frame'?A_FRAME.entryTolerance:.72),near=(o.type==='slalom'?slalomPoleS(o,0):o.type==='a-frame'?o.s-A_FRAME.run:o.s)-sim.player.s<8,board=sim.activeSeesaw,slalom=sim.activeSlalom;
  let icon=!aligned?(o.lane*2<sim.player.x?'←':'→'):o.type==='tunnel'?'∩':['seesaw','slalom','a-frame'].includes(o.type)?'◇':near?'↑':'◇',label=names[o.type],detail=`${o.id+1} / ${obstacleCount} · ${lane}`;
  if(o.type==='a-frame'){
   if(sim.rampPass){icon='◇';label=sim.rampPass.onBoard?'坂を駆け抜けよう':'坂の横を通過中'}
   else if(near&&aligned){icon='◇';label='黄色い入口へ'}
  }
  if(board){const phase=board.state.phase;label=phase==='hold'||phase==='tipping'?'板が下がるまで待つ':phase==='ready'?'タップで再開':sim.stopped?'タップで再開':phase==='exit'?'そのまま進もう':sim.player.s-o.s>=SEESAW.stopFrom?'下スワイプで停止':'中央へ進もう';icon=phase==='hold'||phase==='tipping'?'…':phase==='ready'||sim.stopped?'●':phase==='exit'?'✓':sim.player.s-o.s>=SEESAW.stopFrom?'↓':'◇'}
  if(slalom){const index=slalom.state.index,done=index>=SLALOM.count,right=slalomSide(o,index)>0;icon=done?'✓':right?'→':'←';label=done?'出口へ':right?'右を通る':'左を通る';detail=`${o.id+1} / ${obstacleCount} · ポール ${Math.min(index+1,SLALOM.count)} / ${SLALOM.count}`}
  const key=`${o.id}:${icon}:${label}:${detail}`;if(key===turnLabel)return;turnLabel=key;el.dataset.state=near?'active':'ahead';
  el.innerHTML=`<strong aria-hidden="true">${icon}</strong><span><small>${detail}</small><b>${label}</b></span>`;
 }
 function frame(t){
  if(disposed)return;
  const dt=window.parkReview?.stepSeconds??(last?Math.max(0,Math.min(.2,(t-last)/1000)):0);last=t;
  // Keep ordinary slow frames on the game clock without skipping whole obstacles.
  const steps=Math.max(1,Math.ceil(dt/.05));
  for(let step=0;step<steps;step++)sim.step(dt/steps);
  track.animate?.(sim);
  for(const e of sim.drainEvents()){
   if(e.type==='treat')track.collectTreat(e.id);if(e.type==='hit')message('減速');if(e.type==='dash')message('ダッシュ！');if(e.type==='go')message('スタート！');
   if(e.type==='turn-wrong')message(e.direction==='right'?'右へ':'左へ');if(e.type==='turn-missed')message('ストップ');
   if(e.type==='obstacle-clear')message('クリア！');if(e.type==='obstacle-miss')message(`${faultText(e,sim)}　+${AGILITY.penalty}秒`);if(e.type==='finish')result();
   if(e.type==='seesaw-recover')message('止まり損ね');
  }
  const footing=footingFor(sim,agility);
  [sim.player,...sim.cpus].forEach((a,i)=>{
   if(sim.status==='paused')return;
   const {dog,shadow}=dogs[i],held=i===0&&(agility?sim.stopped:sim.waitingTurn!==null),run=sim.status==='running'&&a.finishTime===null&&!held,p=point(a.s,a.x),corner=agility?null:cornerAt(a.s,0,0,sim.layout.turns);
   dog.position.set(p.x,a.y+(run&&!reduced&&!a.surfaceY?Math.abs(Math.cos(a.phase*1.85))*.025:0),p.z);dog.rotation.order='YXZ';dog.rotation.x=a.pitch||0;dog.rotation.y=Math.PI-p.heading;
   dog.rotation.z=run&&!reduced?((agility?sim.targetX:a.lane*RACE.lanewidth)-a.x)*.07+(corner?(corner.direction==='right'?.08:-.08):0):0;
   poseLegs(dog,a.phase,run,a.jumpElapsed!==null,footing);
   dog.userData.tail.rotation.y=reduced?0:Math.sin(t*.006+i)*.15;shadow.position.set(p.x,.035,p.z);shadow.scale.setScalar(a.jumpElapsed!==null?.7:1);shadow.visible=!a.surfaceY;
  });
  const p=sim.player,nearTunnel=sim.layout.obstacles.some(o=>o.type==='tunnel'&&o.s-p.s<9&&o.s-p.s>-6&&Math.abs(p.x-o.lane*RACE.lanewidth)<.8);
  const surface=p.surfaceY||0,onRamp=sim.rampPass?.onBoard;
  const lift=onRamp?aFrameCameraLift(surface):surface;
  const height=surface?2.8+lift:camera.position.y+((nearTunnel?1.15:2.8+(reduced?0:p.y*.18))-camera.position.y)*(1-Math.exp(-dt*6));
  cameraOffset+=((nearTunnel?4:6)-cameraOffset)*(1-Math.exp(-dt*5));
  const anchor=point(p.s,p.x),pose=chaseCameraPose(anchor,{distance:cameraOffset,height,lookHeight:nearTunnel?.65:1+lift*(onRamp ? .65 : 1)});
  camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);
  light.position.set(anchor.x-7,12,anchor.z+6);light.target.position.set(anchor.x,0,anchor.z);
  uiTime+=dt;
  if(uiTime>.08||sim.status==='countdown'){updateHUD();uiTime=0}
  else if(beach&&sim.status==='running')updateTurnCue();
  if(!window.parkReview?.skipDraw)renderer.render(scene,camera);frameId=requestAnimationFrame(frame);
 }
 function pointerDown(e){
  if(!e.isPrimary||sim.status!=='running'||pointer)return;
  pointer={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),used:false,tapEligible:true};
  canvas.setPointerCapture(e.pointerId);
 }
 function readPointer(e,isRelease){
  if(!pointer||pointer.id!==e.pointerId||pointer.used)return;
  const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
  if(Math.hypot(dx,dy)>=12)pointer.tapEligible=false;
  const action=gestureAction(dx,dy,performance.now()-pointer.time,allowShortFlick);
  if(!action||(action==='dash'&&(!isRelease||!pointer.tapEligible)))return;
  pointer.used=true;
  sim.input(action);
 }
 function pointerMove(e){readPointer(e,false)}
 function cancelPointer(e){if(pointer?.id===e.pointerId)pointer=null}
 function pointerUp(e){readPointer(e,true);cancelPointer(e)}
 function key(e){if(e.target?.tagName==='BUTTON')return;const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',ArrowDown:'brake',' ':'dash'};if(e.key==='Escape'){e.preventDefault();pause()}else if(map[e.key]){e.preventDefault();if(!e.repeat)sim.input(map[e.key])}}
 function visibility(){if(document.hidden)pause()}
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'&&helpReturn){e.preventDefault();closeHelp();return}if(e.key!=='Tab'||overlay.hidden)return;const buttons=[...overlay.querySelectorAll('button')],first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',cancelPointer);canvas.addEventListener('lostpointercapture',cancelPointer);canvas.addEventListener('keydown',key);q('pauseRace').onclick=pause;document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',pause);window.addEventListener('resize',resize);
 const observer=new ResizeObserver(resize);observer.observe(container);
 try{setup();ready();frameId=requestAnimationFrame(frame)}catch(e){console.error('Race rendering unavailable',e);overlay.hidden=false;overlay.innerHTML='<div class="race-modal"><h2>3D表示を開始できませんでした</h2><button id="errorExit" class="primary">コース選択</button></div>';q('errorExit').onclick=onExit;q('pauseRace').hidden=true;q('errorExit').focus({preventScroll:true})}
 return {mode,courseId,pause,dispose(){disposed=true;cancelAnimationFrame(frameId);clearTimeout(messageTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',pause);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());light?.dispose();renderer?.dispose();renderer?.forceContextLoss();container.innerHTML='';container.hidden=true}};
}
````

### `dist/review/v20/race-track.js`

````javascript
import * as T from '../../assets/three.module.js';
import {addTunnel} from '../../tunnel.js';
import {routePoint as parkPoint} from '../../race-route.js';
import {addForestScenery,addForestLog} from '../../forest-scene.js';
import {addBeachScenery,addDriftwood} from '../../beach-scene.js';
import {RACE} from '../../race-sim.js';
const mat=color=>new T.MeshStandardMaterial({color,roughness:1});

// One continuous ribbon keeps every lane connected through the 90-degree bends.
export function roadRibbon(lateral,width,y,from=-15,to=510,point=parkPoint){
 const vertices=[],indices=[],steps=Math.ceil(to-from);
 for(let i=0;i<=steps;i++){
  const s=from+(to-from)*i/steps;
  for(const side of [-1,1]){const p=point(s,lateral+side*width/2);vertices.push(p.x,y,p.z)}
  if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2)}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function makeRaceTrack(layout){
 const root=new T.Group();root.name=(layout.theme||'park')+'-race-track';const routePoint=layout.point||parkPoint,length=layout.length||RACE.length,end=length+30,field=layout.theme==='field';
 function mesh(geo,color,x=0,y=0,z=0,parent=root){const m=new T.Mesh(geo,mat(color));m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,c,x,y,z,parent=root){return mesh(new T.BoxGeometry(w,h,d),c,x,y,z,parent)}
 function groupAt(s,lateral=0){const p=routePoint(s,lateral),g=new T.Group();g.position.set(p.x,0,p.z);g.rotation.y=-p.heading;root.add(g);return g}
 function pose(s,lateral,y,sx=1,sy=1,sz=1){const p=routePoint(s,lateral);return [p.x,y,p.z,sx,sy,sz,-p.heading]}
 function instances(geo,color,poses,name){const m=new T.InstancedMesh(geo,mat(color),poses.length),dummy=new T.Object3D();m.name=name;for(let i=0;i<poses.length;i++){const p=poses[i];dummy.position.set(p[0],p[1],p[2]);dummy.scale.set(p[3]??1,p[4]??1,p[5]??1);dummy.rotation.set(0,p[6]??0,0);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix)}m.receiveShadow=true;root.add(m);return m}
 if(layout.theme==='beach'){
  addBeachScenery(layout,{mesh,box,pose,instances,groupAt,ribbon:roadRibbon});
 }else if(layout.theme==='forest'){
  addForestScenery(layout,{mesh,box,pose,instances,ribbon:roadRibbon});
 }else{
  box(800,.12,800,'#9fb681',50,-.12,-200);
  mesh(roadRibbon(0,7.6,.015,-15,end,routePoint),field?'#b4c49a':'#cfbc95').name='continuous-road';
  for(const x of [-3.7,3.7])mesh(roadRibbon(x,.08,.025,-15,end,routePoint),'#e6d7b6');
  const lines=[];for(let s=-12;s<end;s+=5)for(const x of [-1,1])lines.push(pose(s,x,.025));
  instances(new T.BoxGeometry(.035,.015,1.5),'#e3d5b5',lines,'lane-markings');
  const trunks=[],crowns=[],caps=[],posts=[],rails=[];
  for(let s=-12;s<end;s+=4)for(const side of [-1,1])posts.push(pose(s,side*4.4,.6));
  for(let s=-12;s<end;s+=2)for(const side of [-1,1]){
   const a=routePoint(s,side*4.4),b=routePoint(s+2,side*4.4);
   rails.push([(a.x+b.x)/2,.75,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.04,-Math.atan2(b.x-a.x,a.z-b.z)]);
  }
  for(let s=-10;s<end;s+=11)for(const side of [-1,1]){
   const lateral=side*(7+(Math.abs(s)%4)*.6);
   trunks.push(pose(s,lateral,1));crowns.push(pose(s,lateral,2.5,1.3,1.5,1.3));caps.push(pose(s+.4,lateral+.45,3.2,1,1.2,1));
  }
  instances(new T.CylinderGeometry(.13,.17,2,7),'#8e7c54',trunks,'tree-trunks');
  instances(new T.SphereGeometry(1,10,7),'#79985f',crowns,'tree-crowns');
  instances(new T.SphereGeometry(1,10,7),'#8caa6a',caps,'tree-caps');
  instances(new T.BoxGeometry(.10,1.2,.10),'#d7c6a2',posts,'fence-posts');
  instances(new T.BoxGeometry(.07,.12,1),'#d7c6a2',rails,'fence-rails');
 }
 for(const t of layout.turns){
  for(const lead of [23,6]){
   const side=t.direction==='right'?-1:1,g=groupAt(t.start-lead,side*4.7);g.name='turn-sign';g.userData.turnId=t.id;
   box(.12,2.2,.12,'#778566',0,1.1,0,g);box(2.5,1.2,.12,'#315b49',0,2.2,0,g);
   const shape=new T.Shape();[[-.8,.14],[.12,.14],[.12,.43],[.8,0],[.12,-.43],[.12,-.14],[-.8,-.14]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
   const arrow=mesh(new T.ShapeGeometry(shape),'#f5df9f',0,2.2,.071,g);arrow.material.side=T.DoubleSide;if(t.direction==='left')arrow.scale.x=-1;
  }
 }
 for(const o of layout.obstacles){
  const g=groupAt(o.s,o.lane*RACE.lanewidth);g.name='race-obstacle';g.userData.obstacleId=o.id;
  if(o.type==='log'){
   if(layout.theme==='forest')addForestLog(g,mesh);else addDriftwood(g,mesh);
  }else if(o.type==='hurdle'){
   for(const x of [-.8,.8]){box(.10,1.1,.12,'#72929b',x,.55,0,g);box(.42,.08,.6,'#72929b',x,.04,0,g)}
   for(let j=0;j<8;j++)box(.20,.11,.10,j%2?'#c78465':'#f6edda',-.70+j*.20,.74,0,g);
  }else if(o.type==='hoop'){
   mesh(new T.TorusGeometry(1.2,.09,10,40),'#d6b35a',0,1.7,0,g);
   for(const x of [-1.35,1.35]){box(.1,2.6,.12,'#72929b',x,1.3,0,g);box(.18,.08,.08,'#78909a',x*.945,1.7,0,g);box(.5,.08,.7,'#72929b',x,.04,0,g)}
  }else{
   addTunnel(g,mesh);
   box(.12,.10,6,'#6a97a2',-1.58,.05,0,g);box(.12,.10,6,'#6a97a2',1.58,.05,0,g);
  }
 }
 const treatMesh=new T.InstancedMesh(boneGeometry(),mat('#dca644'),layout.treats.length);treatMesh.name='treat-trail';treatMesh.visible=layout.treats.length>0;root.add(treatMesh);
 function resetTreats(){const dummy=new T.Object3D();for(const t of layout.treats){const p=routePoint(t.s,t.lane*RACE.lanewidth);dummy.position.set(p.x,t.y,p.z);dummy.rotation.set(0,-p.heading,0);dummy.updateMatrix();treatMesh.setMatrixAt(t.id,dummy.matrix)}treatMesh.instanceMatrix.needsUpdate=true;if(layout.treats.length)treatMesh.computeBoundingSphere()}
 function collectTreat(id){treatMesh.setMatrixAt(id,new T.Matrix4().makeScale(0,0,0));treatMesh.instanceMatrix.needsUpdate=true}
 resetTreats();
 const finish=groupAt(length);finish.name='finish-gate';
 for(const x of [-3.6,3.6])box(.18,4,.18,'#607e6c',x,2,0,finish);
 for(let j=0;j<16;j++)for(let row=0;row<2;row++)box(.45,.35,.06,(j+row)%2?'#f6efda':'#486f59',-3.375+j*.45,3.3+row*.35,0,finish);
 const tiles=[];for(let j=0;j<16;j++)for(let k=0;k<2;k++)if((j+k)%2===0)tiles.push(pose(length-k*.5,-3.75+j*.5,.03));
 instances(new T.BoxGeometry(.5,.012,.5),'#f6f0dc',tiles,'finish-tiles');
 return {root,treatMesh,resetTreats,collectTreat};
}
function boneGeometry(){
 const items=[new T.BoxGeometry(.30,.12,.14)];
 for(const x of [-.15,.15])for(const z of [-.07,.07]){const g=new T.SphereGeometry(.095,8,6);g.translate(x,0,z);items.push(g)}
 const pos=[],norm=[];for(const g of items){const n=g.index?g.toNonIndexed():g;pos.push(...n.attributes.position.array);norm.push(...n.attributes.normal.array);n.dispose();g.dispose()}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(norm,3));return g;
}
````

### `dist/review/v21.html`

````html
<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4f5ed"><title>わんラン | レース＆アジリティ</title><meta name="description" content="好きな犬と毛色を選んで、レースとアジリティへ。スワイプで跳んで、曲がって、公園を駆けよう。"><link rel="stylesheet" href="../style.css"><link rel="stylesheet" href="../partner-park.css"></head><body><header class="header"><a class="brand" href="./" aria-label="わんラン"><svg viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="22" rx="9" ry="7"/><ellipse cx="6" cy="12" rx="4" ry="5" transform="rotate(-25 6 12)"/><ellipse cx="14" cy="7" rx="4" ry="5"/><ellipse cx="23" cy="9" rx="4" ry="5" transform="rotate(20 23 9)"/><ellipse cx="28" cy="17" rx="3" ry="4" transform="rotate(25 28 17)"/></svg>わんラン</a><h1>犬と毛色を選ぶ</h1><span class="version" hidden>8犬種 · 3色ずつ</span><button id="openHelp" class="help-button" aria-haspopup="dialog" aria-controls="helpDialog"><span aria-hidden="true">?</span>遊び方</button></header><main id="app"><div class="layout"><section class="showcase" aria-label="選んだ犬の立体プレビュー"><div class="showcase-top"><span>いっしょに走る相棒</span><span id="breedNumber">07 / 08</span></div><div id="viewer"><canvas id="dogCanvas" aria-label="犬の3Dモデル。ドラッグまたは矢印キーで回転できます" tabindex="0"></canvas><p id="webglFallback" hidden>この端末では3D表示を利用できません。犬種と毛色は選択できます。</p><div class="viewer-help" hidden>↔ ドラッグで回転</div><button id="resetView" class="reset" aria-label="犬の向きを元に戻す">↻</button></div><div class="dog-caption"><div><span id="dogEnglish" class="eyebrow"></span><h2 id="dogTitle"></h2></div><span id="coatPill" class="coat-pill"></span></div><p id="dogDescription" class="dog-desc" hidden></p></section><section id="panel" class="panel" aria-label="犬種と毛色の選択"></section></div></main><section id="raceRoot" class="race-root" aria-label="公園レース" hidden></section><dialog id="breedDialog" aria-labelledby="dialogTitle" aria-describedby="dialogHint"><div class="sheet-handle" aria-hidden="true"></div><div class="dialog-heading"><div><h2 id="dialogTitle">犬種を選ぶ</h2></div><button id="closeDialog" class="close" aria-label="変更を取り消して閉じる">×</button></div><p id="dialogHint" class="sr-only">確定するまでは候補を試せます。×で元の犬と毛色に戻ります。</p><div id="dialogBreeds" class="breeds" role="group" aria-label="犬種一覧"></div><div class="dialog-bottom"><p id="dialogSelection" class="sr-only" role="status"></p><button id="doneDialog" class="primary">この犬に決定 <span>✓</span></button></div></dialog><dialog id="helpDialog" class="help-dialog" aria-labelledby="helpTitle"><div class="help-heading"><h2 id="helpTitle">遊び方</h2><button id="closeHelp" class="close" aria-label="遊び方を閉じる">×</button></div><div id="helpContent"></div></dialog><div id="notice" class="notice" role="status" aria-live="polite" hidden></div><script type="importmap">{"imports":{"../race-game.js":"./v21/race-game.js","../race-sim.js":"./v26/race-sim.js","../companions.js":"./v28/companions.js","../shiba.js":"./v28/shiba.js"}}</script><script type="module">import {compareFrame} from "./clock.js";await compareFrame(() => import("../app.js"));</script></body></html>
````

### `dist/review/v21/park-art.js`

````javascript
import * as T from '../../assets/three.module.js';

function randomSequence(seed) {
  return () => ((seed = (1664525 * seed + 1013904223) >>> 0) / 4294967296);
}

// The park shares the simulation's centre line. Dressing stays beyond the running surface.
export function dressPark({root, routePoint, end, ribbon, mesh, box, groupAt, instances, pose}) {
  const random=randomSequence(1071);
  box(1300,.15,1300,'#9bc95f',0,-.12,-180);
  mesh(ribbon(0,7.65,.015,-15,end,routePoint),'#edc285').name='continuous-road';
  const flecks=[],grass=[],flowers=[],flowerHearts=[],shrubs=[],deep=[],trunks=[],limbs=[],canopy=[],tops=[],posts=[],rails=[];
  const bankColors=['#bedc77','#a4cc65','#c4df81','#99c461'];
  const verts=[],colors=[];
  // Broad, irregular polygons at the trail edge instead of painted lane lines.
  for(const side of [-1,1]){
    let previous;
    for(let s=-15;s<=end+3;s+=2.8) {
      const width=3.77+random()*.28,outer=5.6+random()*1.2;
      const row=[routePoint(s,width*side),routePoint(s,outer*side)];
      if(previous){
        const color=new T.Color(bankColors[Math.floor(random()*bankColors.length)]);
        for(const v of [previous[0],previous[1],row[0],previous[1],row[1],row[0]]){
          verts.push(v.x,.024,v.z);color.toArray(colors,colors.length);
        }
      }
      previous=row;
    }
  }
  const banks=new T.BufferGeometry();banks.setAttribute('position',new T.Float32BufferAttribute(verts,3));
  banks.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  const verge=new T.Mesh(banks,new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide}));root.add(verge);
  for(let s=-10;s<end;s+=1.3){
    const side=random()<.5?-1:1;
    flecks.push(pose(s,side*(2.44+random()*1.24),.027,.08+random()*.24,.009,.06+random()*.18));
    const lateral=side*(4.1+random()*2.05);
    const g=pose(s,lateral,.13,.10,.26+random()*.22,.15);grass.push(g);
    if(random()>.28)continue;
    for (let j=0;j<3;j++){
      const p=pose(s+random()*.6,lateral+random()*.4,.19+random()*.13,.12,.055,.12);
      flowerHearts.push([p[0],p[1]+.033,p[2],.057,.038,.057]);
      for(let petal=0;petal<5;petal++){const a=petal*2*Math.PI/5;flowers.push([p[0]+Math.cos(a)*.069,p[1],p[2]+Math.sin(a)*.069,.07,.032,.07])}
    }
  }
  instances(new T.DodecahedronGeometry(1,0),'#d8ab76',flecks,'path-grit');
  instances(new T.ConeGeometry(1,1,3),'#75a34c',grass,'grass-tips');
  const bloom=new T.IcosahedronGeometry(1,0);
  instances(bloom,'#fff4d8',flowers,'daisies');instances(bloom,'#efaf31',flowerHearts,'daisy-centres');
  for(const side of [-1,1]){
    // Split rails into short runs with open views between groups of trees.
    for(let s=-11;s<end;s+=3.1){
      if((Math.floor((s+12)/21)+(side+1))%4===2)continue;
      const a=routePoint(s,side*5.72),b=routePoint(s+3.1,side*5.72);
      posts.push(pose(s,side*5.72,.56));
      for(const y of [.46,.89])rails.push([(a.x+b.x)/2,y,(a.z+b.z)/2,1,1,Math.hypot(b.x-a.x,b.z-a.z)+.08,-Math.atan2(b.x-a.x,a.z-b.z)]);
    }
    for(let s=-12+(side+1)*2.9;s<end;s+=9+random()*6) {
      const offset=side*(6.8+random()*3.6),h=2.45+random()*1.35;
      trunks.push(pose(s,offset,h*.48,1,h,1));
      const p=pose(s,offset,h*.89,1,.95,1);limbs.push(p);
      const turn=random()*6,spread=1.65+random()*.91;
      canopy.push([...pose(s,offset,h+.56,spread,1.66+random(),spread*.91).slice(0,6),turn]);
      tops.push([...pose(s+.42,offset-side*.71,h+1.58,spread*.76,1.24+random()*.5,spread*.7).slice(0,6),turn+.71]);
    }
    for(let s=-9;s<end;s+=5+random()*7) {
      const d=6.2+random()*4,scale=.7+random()*.8;
      shrubs.push(pose(s,side*d,scale*.55,scale*1.13,scale,scale*.91));
      deep.push(pose(s+1,side*(d+.65),scale*.44,scale*1.12,scale*.74,scale));
    }
  }
  const faceted = new T.IcosahedronGeometry(1,1);
  function foliage(geom,color,poses,name) {
    const batch=instances(geom,color,poses,name);
    batch.material.flatShading=true;
    for(let i=0;i<poses.length;i++){
      const tone=.80+random()*.20;batch.setColorAt(i,new T.Color().setRGB(tone,Math.min(1,tone+.03),tone*.94));
    }
    return batch;
  }
  foliage(faceted,'#70ae51',canopy,'tree-crowns');foliage(faceted,'#a3ca59',tops,'sunlit-canopies');
  foliage(new T.DodecahedronGeometry(1,0),'#81af4a',shrubs,'shrubs');foliage(faceted,'#589b55',deep,'hedges');
  instances(new T.CylinderGeometry(.22,.34,1,7),'#966745',trunks,'tree-trunks');
  const branch=new T.CylinderGeometry(.10,.18,1.45,6);branch.rotateZ(.53);branch.translate(-.29,0,0);
  instances(branch,'#a5744d',limbs,'tree-branches');
  instances(new T.CylinderGeometry(.099,.111,1.17,5),'#aa7450',posts,'fence-posts');
  instances(new T.BoxGeometry(.085,.13,1),'#bc895d',rails,'fence-rails');
  const treeShadows=trunks.map(p=>[p[0]+.75,.007,p[2]-.37,2.43,1,1.44,p[6]]);
  const shadowPatch=new T.CircleGeometry(1,9);shadowPatch.rotateX(-Math.PI/2);
  instances(shadowPatch,'#8db55f',treeShadows,'tree-shadows');
  const hills=[], clouds=[];
  for(let s=-30;s<end+60;s+=25)for(const side of [-1,1]){
    const d=44+random()*26;
    hills.push(pose(s,side*d,-2,11+random()*13,5+random()*8,15+random()*13));
    if(random()<.5){
      const lateral=side*(13+random()*23),h=12+random()*8;
      for(const [dx,dy,z,w,t] of [[-2,0,-.1,2.1,.82],[0,.67,0,2.35,1.45],[2.1,.12,.3,1.8,.96]]){
        clouds.push(pose(s+z,lateral+dx,h+dy,w,t,1.85));
      }
    }
  }
  foliage(new T.IcosahedronGeometry(1,0),'#83b69b',hills,'far-hills');
  instances(new T.IcosahedronGeometry(1,1),'#fff8df',clouds,'clouds');
  for(const s of [45,162,322]){
    const pavilion=groupAt(s,-11);pavilion.name='park-pavilion';
    mesh(new T.CylinderGeometry(2.3,2.46,.27,8),'#d5b68a',0,.13,0,pavilion);
    for(let j=0;j<8;j++){
      const a=Math.PI*j/4;
      mesh(new T.CylinderGeometry(.083,.10,2.65,6),'#f4e4be',Math.cos(a)*1.9,1.56,Math.sin(a)*1.9,pavilion);
    }
    mesh(new T.ConeGeometry(2.9,1.55,8),'#cf6c50',0,3.65,0,pavilion);
    mesh(new T.CylinderGeometry(2.9,2.81,.15,8),'#8f5542',0,2.88,0,pavilion);
    mesh(new T.SphereGeometry(.16,8,6),'#f3be66',0,4.48,0,pavilion);
  }
}

export function parkLog(group,mesh) {
  const bark=mesh(new T.CylinderGeometry(.365,.345,1.76,11),'#925d38',0,.39,0,group);
  bark.castShadow=true;bark.rotation.z=Math.PI/2;bark.rotation.y=.09;
  for(const side of [-1,1]){
    const x=side*.88,z=-side*.079;
    const end=mesh(new T.CylinderGeometry(.303,.303,.02,11),'#e2ab70',x,.39,z,group);end.rotation.copy(bark.rotation);
    const ring=mesh(new T.TorusGeometry(.195,.014,4,12),'#b57a46',x+side*.017,.39,z,group);ring.rotation.y=Math.PI/2+.09;
  }
  for(const x of [-.51,.32]){
    const seam=mesh(new T.CylinderGeometry(.027,.033,.42,6),'#b7814e',x,.50,.32-x*.09,group);
    seam.rotation.z=Math.PI/2-.08;seam.rotation.y=.09;
  }
  const knot=mesh(new T.CylinderGeometry(.089,.125,.22,7),'#99643c',-.41,.67,-.06,group);knot.rotation.z=.54;
  mesh(new T.DodecahedronGeometry(1,0),'#8ca54b',.42,.699,-.04,group).scale.set(.25,.078,.139);
}
````

