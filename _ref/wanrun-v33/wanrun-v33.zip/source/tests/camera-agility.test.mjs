import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {routePoint,PARK_TURNS} from '../dist/race-route.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {AgilitySimulation,AGILITY,fieldPoint,buildFirstField} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
const run=()=>{const s=new AgilitySimulation();s.start();for(let i=0;i<61;i++)s.step(.05);return s};
const advance=(s,seconds)=>{for(let i=0;i<Math.ceil(seconds*60);i++)s.step(1/60)};
test('dog projects to the same screen position on straights and every bend, in both orientations',()=>{
 for(const aspect of [390/844,844/390]){
  const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let baseline;
  for(let s=0;s<=480;s+=.5)for(const lane of [-2,0,2]){
   const anchor=routePoint(s,lane),pose=chaseCameraPose(anchor);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();
   const dog=new T.Vector3(anchor.x,.75,anchor.z).project(camera);assert(Math.abs(dog.x)<1e-10);baseline??=dog.y;assert(Math.abs(dog.y-baseline)<1e-10);assert(Math.abs(dog.y)<.85);
  }
 }
});
test('camera keeps a constant rear offset and heading through all turn boundaries',()=>{
 for(const t of PARK_TURNS)for(const s of [t.start-.01,t.start,t.start+.01,t.end-.01,t.end,t.end+.01]){
  const p=routePoint(s),c=chaseCameraPose(p);assert(Math.abs(Math.hypot(c.position.x-p.x,c.position.z-p.z)-6)<1e-9);
  const dx=p.x-c.position.x,dz=p.z-c.position.z;assert(Math.abs(dx*Math.cos(p.heading)+dz*Math.sin(p.heading))<1e-9);
 }
});
test('agility stop holds position while time runs; tap resumes and menu pause freezes time',()=>{
 const s=run();advance(s,1);s.input('brake');const distance=s.player.s,time=s.time;advance(s,2);assert.equal(s.player.s,distance);assert(s.time>time+1.9);assert.equal(s.input('jump'),false);assert(s.input('dash'));assert.equal(s.input('dash'),false);advance(s,.2);assert(s.player.s>distance);
 s.input('brake');s.pause();const paused=s.time;advance(s,2);assert.equal(s.time,paused);assert.equal(s.input('dash'),false);s.resume();assert(s.stopped);s.input('dash');assert(!s.stopped);
});
test('jumped hurdles clear once; walking into or bypassing one adds one fault',()=>{
 const good=run();good.player.s=good.layout.obstacles[0].s-AGILITY.speed*.45;good.input('jump');advance(good,.6);assert.equal(good.cleared,1);assert.equal(good.faults,0);
 for(const lane of [0,1]){const s=run();s.player.s=s.layout.obstacles[0].s-.2;s.player.lane=lane;s.player.x=lane*2;advance(s,.3);assert.equal(s.faults,1);advance(s,.5);assert.equal(s.faults,1);assert.equal(s.results.get(0),false)}
});
test('tunnel clearance requires correct ground-level entry and exit; jumping or cutting in fails',()=>{
 const t=buildFirstField().obstacles.find(o=>o.type==='tunnel');
 for(const correct of [true,false]){const s=run();s.player.s=t.s-3.2;s.player.lane=correct?t.lane:0;s.player.x=s.player.lane*2;advance(s,.06);if(correct){assert.equal(s.input('jump'),false);assert.equal(s.input('left'),false)}else{s.player.x=t.lane*2;s.player.lane=t.lane}advance(s,1);assert.equal(s.results.get(t.id),correct)}
});
test('all six agility obstacles are playable, with score and retry state kept separate from racing',()=>{
 const s=run();for(let i=0;i<4000&&s.status==='running';i++){
  const o=s.nextObstacle,p=s.player;if(o){if(o.lane<p.lane)s.input('left');if(o.lane>p.lane)s.input('right');if(o.type!=='tunnel'&&o.s-p.s<3.5&&o.s>p.s&&p.jumpElapsed===null)s.input('jump')}s.step(1/60);
 }
 assert.equal(s.status,'finished');assert.equal(s.result.cleared,6);assert.equal(s.result.faults,0);assert.equal(s.result.total,s.result.time);assert.equal(s.cpus.length,0);
 s.reset();assert.equal(s.results.size,0);assert.equal(s.tunnelEntries.size,0);assert.equal(s.faults,0);assert.equal(s.status,'ready');assert.equal(s.stopped,false);
 const missed=run();advance(missed,80);assert.equal(missed.status,'finished');assert.equal(missed.result.total,missed.result.time+missed.result.faults*AGILITY.penalty);assert.equal(missed.results.size,6);
});
test('agility track positions and hoops match its own route, without race treats or turn signs',()=>{
 const layout=buildFirstField(),track=makeAgilityField(layout);track.root.updateMatrixWorld(true);let hoops=0;
 track.root.traverse(o=>{if(o.geometry)assert(o.geometry.attributes.position.array.every(Number.isFinite));if(o.name==='race-obstacle'){const ob=layout.obstacles.find(x=>x.id===o.userData.obstacleId),p=fieldPoint(ob.s,ob.lane*2);assert(Math.abs(o.position.x-p.x)<1e-9);assert(Math.abs(o.position.z-p.z)<1e-9);if(ob.type==='hoop')hoops++}});
 assert.equal(hoops,2);assert(!track.root.getObjectByName('treat-trail'));assert(!track.root.getObjectByName('continuous-road'));assert(!track.root.getObjectByName('lane-markings'));assert(!track.root.getObjectByName('turn-sign'));const end=fieldPoint(AGILITY.length),gate=track.root.getObjectByName('finish-gate');assert.equal(gate.position.x,end.x);assert.equal(gate.position.z,end.z);
 const geometries=new Set(),materials=new Set();track.root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());
});

test('hurdles, hoops and tunnel mouths are judged at passage across different frame rates',()=>{
 for(const dt of [1/120,1/60,.05,.1]){
  for(const type of ['hurdle','hoop']){
   for(const [lead,expected] of [[.12,false],[.18,true],[.75,true],[.82,false]]){
    const s=run(),o=s.layout.obstacles.find(o=>o.type===type);
    s.player.lane=o.lane;s.player.x=o.lane*2;s.player.s=o.s-AGILITY.speed*lead;
    s.input('jump');while(!s.results.has(o.id))s.step(dt);
    assert.equal(s.results.get(o.id),expected,type+' lead '+lead+' dt '+dt);
    if(!expected)assert.equal(s.drainEvents().find(e=>e.type==='obstacle-miss').reason,'jump-low');
   }
  }
  for(const [lead,expected] of [[.04,false],[.09,true]]){
   const s=run(),o=s.layout.obstacles.find(o=>o.type==='tunnel');
   s.player.lane=o.lane;s.player.x=0;s.player.s=o.s-3-AGILITY.speed*lead;
   while(!s.results.has(o.id))s.step(dt);
   assert.equal(s.results.get(o.id),expected,'tunnel entry dt '+dt);
   if(!expected)assert.equal(s.drainEvents().find(e=>e.type==='obstacle-miss').reason,'tunnel-entry');
  }
 }
});
