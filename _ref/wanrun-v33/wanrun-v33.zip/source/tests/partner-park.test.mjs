import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {parkBiscuitGeometry} from '../dist/park-biscuit.js';
import {makeShiba,poseShiba} from '../dist/shiba.js';
import {poseLegs} from '../dist/dog-gait.js';
import {RaceSimulation} from '../dist/race-sim.js';
import {routePoint} from '../dist/race-route.js';
import {makeParkCamera} from '../dist/park-camera.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {lastFrame,recordedKey} from '../dist/review/replay.js';

function sample(frame) {
  const actions={ArrowRight:'right',ArrowLeft:'left',ArrowDown:'brake',ArrowUp:'jump',' ':'dash'};
  const sim=new RaceSimulation();sim.start();
  for(let i=0;i<=frame;i++){
    const key=recordedKey(i);
    if(key)sim.input(actions[key]);
    sim.step(i===0?0:1/60);
  }
  return sim;
}
test('the Shiba plants both diagonal paws and can rest its face and tail with reduced motion',()=>{
  for(let coat=0;coat<3;coat++){
    const dog=makeShiba(coat);
    dog.scale.setScalar(.94);dog.rotation.set(0,Math.PI,.06,'YXZ');
    for(const phase of [.2,1,2.5,4.7]){
      poseLegs(dog,phase,true,false,()=>.015);dog.updateMatrixWorld(true);
      const heights=dog.userData.legs.map(leg=>leg.userData.paw.localToWorld(new T.Vector3(0,-1,0)).y);
      assert.equal(heights.filter(y=>Math.abs(y-.015)<1e-5).length,2);
      assert(heights.every(y=>y>.01499));
    }
    poseShiba(dog,3.61,true,false);assert(dog.userData.expression.eyes[0].scale.y<.15);
    poseShiba(dog,6,false,true);assert.equal(dog.userData.tail.rotation.y,0);
    assert.equal(dog.userData.expression.eyes[0].scale.y,1);
  }
});
test('the viewing frames show the first jump, turn, mid-course clipping location and final tunnel',()=>{
  const log=sample(lastFrame.log),turn=sample(lastFrame.turn);
  assert.equal(log.layout.obstacles[0].type,'hurdle');
  assert(log.layout.obstacles[0].s-log.player.s>6 && log.layout.obstacles[0].s-log.player.s<10);
  assert.equal(log.rank,5);assert.equal(log.cpus.length,4);
  assert.equal(turn.turnCue.direction,'right');assert.equal(turn.turnCue.active,true);
  const mid=sample(lastFrame.midpark),tunnel=sample(lastFrame.tunnel);
  assert(mid.player.s>237&&mid.player.s<239);
  const gate=tunnel.layout.obstacles.filter(o=>o.type==='tunnel').at(-1);
  assert(tunnel.player.s-gate.s>.9 && tunnel.player.s-gate.s<1.8);
  assert(Math.abs(tunnel.player.x-gate.lane*2)<.01);
});
test('all five bodies, the first log and the next biscuits project between the portrait HUD strips in the viewing frame',()=>{
  const sim=sample(lastFrame.log),anchor=routePoint(sim.player.s,sim.player.x);
  for(const [w,h] of [[320,568],[390,780],[390,844]]){
    const distance=Math.max(6,Math.min(8.65,3.58*h/w)),cp=chaseCameraPose(anchor,{distance});
    const cam=new T.PerspectiveCamera(60,w/h,.1,180);
    cam.position.set(cp.position.x,cp.position.y,cp.position.z);cam.lookAt(cp.target.x,cp.target.y,cp.target.z);cam.updateMatrixWorld();
    const points=[];
    for(const a of [sim.player,...sim.cpus])for(const dx of [-.38,.38])for(const y of [0,1.88]){
      const p=routePoint(a.s,a.x+dx);points.push(new T.Vector3(p.x,y,p.z+.4));
    }
    const gate=sim.layout.obstacles[0];
    for(const dx of [-.9,.9]){const p=routePoint(gate.s,dx);points.push(new T.Vector3(p.x,.39,p.z))}
    for(const t of sim.layout.treats.filter(t=>t.s>sim.player.s&&t.s<gate.s+3)){
      const p=routePoint(t.s,t.lane*2);points.push(new T.Vector3(p.x,t.y,p.z));
    }
    for(const point of points){const p=point.project(cam),pixelY=(1-p.y)*h/2;
      assert(Math.abs(p.x)<1);assert(pixelY>110&&pixelY<h-60);
    }
  }
});

test('distant hills clear the three lanes and the chase-camera sweep throughout the folded park',()=>{
  const track=makeRaceTrack(new RaceSimulation().layout);
  const hills=track.root.getObjectByName('far-hills');
  hills.updateMatrixWorld();
  const ray=new T.Raycaster(),down=new T.Vector3(0,-1,0);
  for(let s=0;s<=480;s+=.5){
    for(const lane of [-2,0,2]){
      const path=routePoint(s,lane),camera=chaseCameraPose(path,{distance:8.65}).position;
      for(const p of [path,camera]){
        ray.set(new T.Vector3(p.x,35,p.z),down);
        assert(!ray.intersectObject(hills).some(hit=>hit.point.y>0),'hill above course at '+s);
      }
    }
  }
});

test('park tunnels retain their opaque roof as the camera and dog enter and leave through the two open ends',()=>{
  const sim=new RaceSimulation(),track=makeRaceTrack(sim.layout),ray=new T.Raycaster();
  track.root.updateMatrixWorld(true);
  for(const gate of sim.layout.obstacles.filter(o=>o.type==='tunnel')){
    const group=track.root.children.find(child=>child.name==='race-obstacle'&&child.userData.obstacleId===gate.id);
    const surfaces=group.getObjectByName('park-tunnel').children;
    const panels=surfaces.filter(o=>o.name==='tunnel-fabric');
    assert.equal(panels.length,1);
    const sleeve=panels[0], localRay=new T.Raycaster();
    const start=new T.Vector3(), direction=new T.Vector3();
    // Sample both hems at ankle height all the way to the mouths.
    for(const z of [-3.78,-3,-1.5,0,1.5,3,3.78])for(const side of [-1,1]){
      sleeve.parent.localToWorld(start.set(0,.07,z));
      direction.set(side,0,0).transformDirection(sleeve.parent.matrixWorld);
      localRay.set(start,direction);
      const hit=localRay.intersectObject(sleeve)[0];
      assert(hit && Math.abs(hit.distance-1.70)<.03,'side opening at '+z);
    }
    sleeve.parent.localToWorld(start.set(0,0,0));localRay.set(start,direction.set(0,1,0));
    const rise=localRay.intersectObject(sleeve)[0].distance;
    assert(rise/1.70>=1 && rise/1.70<=1.12,'arched profile relative to the original semicircle');
    assert(surfaces.every(o=>o.visible&&o.material.opacity===1&&!o.material.transparent));
    for(const [w,h] of [[320,568],[393,639],[390,780],[390,844],[844,390]]){
      const base=Math.max(6,Math.min(8.65,3.58*h/w));
      for(const offset of [-.52,0,.52]){
        const follow=makeParkCamera(sim.layout.obstacles);
        let shared=0;
        for(let s=gate.s-25;s<=gate.s+26;s+=.20){
          const x=gate.lane*2+offset,pose=follow({s,x},base,2.8);
          const from=new T.Vector3().copy(pose.position);
          const cam=new T.PerspectiveCamera(w>h?54:60,w/h,.1,180);
          cam.position.copy(from);cam.lookAt(new T.Vector3().copy(pose.target));cam.updateMatrixWorld();
          for(const [y,dz] of [[.10,-.35],[.80,-.5],[1.40,.35]]){
            const point=routePoint(s+dz,x),target=new T.Vector3(point.x,y,point.z);
            const dir=target.clone().sub(from);ray.far=dir.length();ray.set(from,dir.normalize());
            assert.equal(ray.intersectObjects(surfaces,false).length,0,'blocked at '+s);
            const screen=target.project(cam);
            const pixelY=(1-screen.y)*h/2;
            assert(Math.abs(screen.x)<.01&&pixelY>60&&pixelY<h-58,'the dog overlaps the HUD at '+s);
          }
          ray.far=8;
          const dog=routePoint(s,x);
          const roofAt=(x,y,z)=>{ray.set(new T.Vector3(x,y,z),new T.Vector3(0,1,0));return ray.intersectObjects(panels).length>0};
          if(roofAt(from.x,from.y,from.z)&&roofAt(dog.x,1.40,dog.z)){
            shared+=.20;
            const exit=routePoint(gate.s+7,gate.lane*2),target=new T.Vector3(exit.x,1.0,exit.z);
            const dir=target.clone().sub(from);ray.far=dir.length();ray.set(from,dir.normalize());
            assert.equal(ray.intersectObjects(surfaces).length,0);
          }
        }
        assert(shared>2.5,'dog and camera must travel together inside the shorter sleeve');
      }
    }
  }
});

test('the park camera can bypass a tunnel, follow a late exit swipe, then restart on the normal chase view',()=>{
  const sim=new RaceSimulation(),gate=sim.layout.obstacles.filter(o=>o.type==='tunnel').at(-1);
  const follow=makeParkCamera(sim.layout.obstacles),distance=7.16;
  for(let s=gate.s-28;s<gate.s+25;s+=.2){
    const pose=follow({s,x:2},distance,2.8);
    assert.deepEqual(pose,chaseCameraPose(routePoint(s,2),{distance}));
  }
  const track=makeRaceTrack(sim.layout);
  track.root.updateMatrixWorld(true);
  const group=track.root.children.find(o=>o.name==='race-obstacle'&&o.userData.obstacleId===gate.id);
  const surfaces=group.getObjectByName('park-tunnel').children;
  const ray=new T.Raycaster();
  for(const speed of [6.05,9.6,16.2])for(const side of [-1,1]){
    for(let s=gate.s-26;s<gate.s+23;s+=.10){
      const lateral=s<gate.s+3.4?0:side*2*(1-Math.exp(-13*(s-gate.s-3.4)/speed));
      const pose=follow({s,x:lateral},distance,2.8),point=routePoint(s,lateral);
      const from=new T.Vector3().copy(pose.position);
      for(const location of [pose.position,pose.target]){
        const dx=location.x-point.x,dz=location.z-point.z;
        assert(Math.abs(dx*Math.cos(point.heading)+dz*Math.sin(point.heading))<1e-8);
      }
      for(const [height,lead] of [[.10,-.25],[.75,0],[1.32,.25]]){
        const dog=routePoint(s+lead,lateral);
        const dir=new T.Vector3(dog.x,height,dog.z).sub(from);
        ray.far=dir.length();ray.set(from,dir.normalize());
        assert.equal(ray.intersectObjects(surfaces).length,0,'exit swipe at '+s);
      }
    }
  }
  assert.deepEqual(follow({s:0,x:0},distance,2.8),chaseCameraPose(routePoint(0),{distance}));
});

test('every frame of the close-up lane changes shares the dog’s lateral anchor and the road heading',()=>{
  const sim=new RaceSimulation(),follow=makeParkCamera(sim.layout.obstacles);
  const inputs={ArrowRight:'right',ArrowLeft:'left',ArrowDown:'brake',ArrowUp:'jump',' ':'dash'};
  sim.start();
  for(let frame=0;frame<=2320;frame++){
    const key=recordedKey(frame,'swipe');
    if(key)sim.input(inputs[key]);
    sim.step(frame?1/60:0);
    const p=sim.player,anchor=routePoint(p.s,p.x),pose=follow(p,6.05,2.8);
    const side=new T.Vector2(Math.cos(anchor.heading),Math.sin(anchor.heading));
    const forward=new T.Vector2(side.y,-side.x);
    const offset=point=>new T.Vector2(point.x-anchor.x,point.z-anchor.z);
    const rear=offset(pose.position),aim=offset(pose.target);
    assert(Math.abs(rear.dot(side))<1e-8 && Math.abs(aim.dot(side))<1e-8,'camera turned during frame '+frame);
    assert(rear.dot(forward)<0 && aim.dot(forward)>0);
    if(frame===lastFrame.swipe)assert(p.x < -1.6 && p.x > -1.9);
    if(frame===2300)assert(p.x>1.7);
  }
});

test('the baked bone has a broad waist, a notch at each end and a shallow impression in its front face',()=>{
  const geo=parkBiscuitGeometry();geo.rotateX(.38);geo.rotateZ(-.22);
  const biscuit=new T.Mesh(geo,new T.MeshBasicMaterial());
  const ray=new T.Raycaster(),forward=new T.Vector3(0,0,-1);
  function faceAt(x,y){
    ray.set(new T.Vector3(x,y,1),forward);
    return ray.intersectObject(biscuit)[0]?.point.z;
  }
  assert(faceAt(0,.08)>.05);
  assert(Math.abs(faceAt(0,-.027)-.038)<.0001);
  for(const x of [-.325,.325]){
    assert.equal(faceAt(x,0),undefined);
    assert(faceAt(x,.095)>0 && faceAt(x,-.095)>0);
  }
  geo.computeBoundingBox();
  assert(geo.boundingBox.max.z-geo.boundingBox.min.z<.12);
});
