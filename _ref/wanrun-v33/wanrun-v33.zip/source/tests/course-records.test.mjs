import test from 'node:test';
import assert from 'node:assert/strict';
import {courseBest, finishRecord, formatRaceClock} from '../dist/course-records.js';
import {courses} from '../dist/courses.js';

const legacy = {
  park: 'wan-run-best-park-turns-v1', beach: 'wan-run-best-beach-v1', forest: 'wan-run-best-forest-v1',
  'first-field': 'wan-run-best-first-field-arena-v2', zigzag: 'wan-run-best-zigzag-v1', balance: 'wan-run-best-balance-v1'
};
function storage() {
  const data = new Map();
  globalThis.localStorage = {
    getItem: key => data.get(key) ?? null,
    setItem: (key, value) => data.set(key, value)
  };
  return data;
}
test('all six existing records are read without migration and compared independently', () => {
  const data = storage();
  const previousCourses = courses.filter(course => Object.hasOwn(legacy, course.id));
  previousCourses.forEach((course, i) => data.set(legacy[course.id], String(40+i)));
  for(const [i, course] of previousCourses.entries()) {
    assert.equal(courseBest(course.id), 40+i);
    const record = finishRecord(course.id, 39+i);
    assert.deepEqual([record.state, record.label, record.best], ['faster','1.00秒短縮',39+i]);
  }
  assert.equal(data.size, 6);
  assert.equal(courseBest('hill-field'), null);
  assert.equal(finishRecord('hill-field', 24.5).state, 'first');
  assert.equal(data.get('wan-run-best-hill-field-v1'), '24.5');
  assert.equal(courseBest('balance'),44);
});
test('first finish, tie, improvement and gap use the precision of the visible score', () => {
  const data = storage();
  assert.equal(courseBest('beach'), null);
  assert.equal(finishRecord('beach', 38.204).state, 'first');
  assert.equal(finishRecord('beach', 38.201).label, '自己ベストタイ');
  assert.equal(finishRecord('beach', 37.976).label, '0.22秒短縮');
  assert.equal(finishRecord('beach', 39.121).label, 'ベストまで 1.14秒');
  assert.equal(courseBest('beach'), 37.976);
  // Read the current saved record again if another tab updates it during play.
  data.set(legacy.beach, '35.555');
  assert.equal(finishRecord('beach', 36.5).state, 'slower');
  assert.equal(courseBest('beach'), 35.555);
});
test('invalid saved times do not prevent finishing; unavailable storage retains records for this session', () => {
  const data = storage();
  for(const bad of ['', 'nope', '0', '-2', 'Infinity']){
    data.set(legacy.zigzag, bad);
    assert.equal(courseBest('zigzag'),null);
  }
  const set = localStorage.setItem;
  localStorage.setItem = () => {throw Error('quota')};
  assert.equal(finishRecord('zigzag', 56).temporary,true);
  assert.equal(courseBest('zigzag'),56);
  localStorage.getItem = () => {throw Error('private')};
  assert.equal(finishRecord('zigzag', 55).label,'1.00秒短縮');
  localStorage.getItem = key => data.get(key) ?? null;
  localStorage.setItem = set;
  assert.equal(finishRecord('zigzag', 60).temporary,false);
  assert.equal(data.get(legacy.zigzag),'55');
});

test('the running clock carries rounded tenths into the next minute', () => {
  assert.equal(formatRaceClock(0), '00:00.0');
  assert.equal(formatRaceClock(59.94), '00:59.9');
  assert.equal(formatRaceClock(59.96), '01:00.0');
  assert.equal(formatRaceClock(60.06), '01:00.1');
  assert.equal(formatRaceClock(119.95), '02:00.0');
});
