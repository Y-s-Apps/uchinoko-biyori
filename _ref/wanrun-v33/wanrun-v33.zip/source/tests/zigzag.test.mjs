import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {AgilitySimulation,AGILITY,buildAgilityCourse} from '../dist/agility-sim.js';
import {SLALOM,slalomPoleS,slalomSide,slalomStart,slalomEnd} from '../dist/slalom.js';
import {FIELD_SEGMENTS} from '../dist/agility-route.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
const advance=(s,seconds,dt=1/60)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
const running=()=>{const s=new AgilitySimulation('zigzag');s.start();advance(s,3.1);return s};
const enter=()=>{const sim=running(),obstacle=sim.layout.obstacles[1];sim.player.s=slalomStart(obstacle)+.1;return {sim,obstacle}};
test('a single swipe targets either slalom side; repeated swipes do not move out of the row',()=>{
 const {sim,obstacle}=enter();sim.input('left');advance(sim,.25);assert(sim.player.x<-.85);sim.input('right');advance(sim,.3);assert(sim.player.x>.85);assert.equal(sim.player.lane,obstacle.lane);
 for(let i=0;i<6;i++)sim.input('right');assert.equal(sim.targetX,SLALOM.offset);assert.equal(sim.input('jump'),false);assert.equal(sim.input('dash'),false);
 sim.input('brake');const s=sim.player.s,time=sim.time,index=sim.activeSlalom.state.index;advance(sim,1);assert.equal(sim.player.s,s);assert(sim.time>time+.9);assert.equal(sim.activeSlalom.state.index,index);sim.pause();const t=sim.time;advance(sim,1);assert.equal(sim.time,t);assert.equal(sim.input('left'),false);sim.resume();assert(sim.stopped);assert(sim.input('dash'));advance(sim,.1);assert(sim.player.s>s);
});
test('both six-pole rows can be cleared in order in a full run, including varied frame times',()=>{
 for(const dt of [1/120,1/60,.05,.1]){
  const sim=running();for(let frame=0;frame<7000&&sim.status==='running';frame++){
   const p=sim.player,o=sim.nextObstacle,slalom=sim.activeSlalom;
   if(slalom){if(slalom.state.index<SLALOM.count)sim.input(slalomSide(o,slalom.state.index)<0?'left':'right')}
   else if(o){if(o.lane<p.lane)sim.input('left');if(o.lane>p.lane)sim.input('right');if(['hoop','hurdle'].includes(o.type)&&o.s-p.s<3.8&&o.s>p.s&&p.jumpElapsed===null)sim.input('jump')}
   sim.step(dt);
  }
  assert.equal(sim.status,'finished');assert.equal(sim.cleared,6);assert.equal(sim.faults,0);assert.equal(sim.result.total,sim.result.time);assert([...sim.slaloms.values()].every(s=>s.passed.length===6&&s.passed.every(Boolean)));assert.equal(sim.layout.treats.length,0);assert.equal(sim.cpus.length,0);
  sim.reset();assert.equal(sim.results.size,0);assert.equal(sim.activeSlalom,null);assert([...sim.slaloms.values()].every(s=>s.index===0&&s.side===0&&s.passed.length===0&&!s.failed));
 }
});
test('wrong side, centre-line running and outside bypass all add only one fault per row',()=>{
 for(const strategy of ['centre','one-side','outside']){
  const {sim,obstacle}=enter();if(strategy==='one-side')sim.input('left');
  for(let i=0;i<500&&!sim.results.has(obstacle.id);i++){if(strategy==='outside')sim.player.x=3;sim.step(1/60)}
  const state=sim.slaloms.get(obstacle.id);assert.equal(state.index,6);assert(state.failed);assert.equal(sim.results.get(obstacle.id),false);assert.equal(sim.faults,1);assert.equal(sim.player.hits,1);advance(sim,.5);assert.equal(sim.faults,1);
 }
});
test('a late swipe is judged at the pole crossing rather than the end of the frame',()=>{
 const {sim,obstacle}=enter();sim.player.s=slalomPoleS(obstacle,0)-.01;sim.player.x=.9;sim.input('left');sim.step(.1);assert.equal(sim.slaloms.get(obstacle.id).passed[0],false);assert(sim.player.x<0,'end-of-frame position alone would allow the wrong side');
});
test('a jump started before entry cannot skip the first pole; row exit restores normal speed and lane input',()=>{
 const {sim,obstacle}=enter();sim.player.s=slalomStart(obstacle)-.05;assert(sim.input('jump'));advance(sim,.02);assert.equal(sim.input('jump'),false);sim.input('left');
 while(sim.slaloms.get(obstacle.id).index===0)sim.step(1/60);assert.equal(sim.slaloms.get(obstacle.id).passed[0],false);
 while(sim.player.s<=slalomEnd(obstacle)+1)sim.step(1/60);assert.equal(sim.activeSlalom,null);sim.player.slow=0;const s=sim.player.s;advance(sim,.1);assert(Math.abs(sim.player.s-s-AGILITY.speed*.1)<1e-8);sim.input('right');assert.equal(sim.player.lane,1);assert.equal(sim.targetX,2);
});
test('poles align with the scoring gates, target follows the next side, and camera stays centred',()=>{
 const sim=new AgilitySimulation('zigzag'),field=makeAgilityField(sim.layout);field.root.updateMatrixWorld(true);const poles=[];field.root.traverse(o=>{if(o.name==='slalom-pole')poles.push(o)});assert.equal(poles.length,12);
 for(const pole of poles){const o=sim.layout.obstacles.find(o=>o.id===pole.userData.obstacleId),s=slalomPoleS(o,pole.userData.poleIndex),expected=sim.layout.point(s,o.lane*2),world=pole.getWorldPosition(new T.Vector3()),seg=FIELD_SEGMENTS.find(t=>s>=t.start&&s<=t.end);assert.equal(seg.turn,0);assert(Math.abs(world.x-expected.x)<1e-8);assert(Math.abs(world.z-expected.z)<1e-8)}
 sim.results.set(0,true);const o=sim.nextObstacle,state=sim.slaloms.get(o.id),marker=field.root.getObjectByName('next-obstacle-marker');
 for(let i=0;i<6;i++){field.update(sim);const p=sim.layout.point(slalomPoleS(o,i),o.lane*2+slalomSide(o,i)*SLALOM.offset);assert(marker.visible);assert(Math.abs(marker.position.x-p.x)<1e-9);assert(Math.abs(marker.position.z-p.z)<1e-9);state.index++;state.passed.push(true)}field.update(sim);assert(!marker.visible);
 for(const aspect of [390/844,844/390]){let baseline;const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);for(let s=slalomStart(o);s<=slalomEnd(o);s+=.2){const p=sim.layout.point(s,Math.sin(s*2)*.9),pose=chaseCameraPose(p);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const dog=new T.Vector3(p.x,.75,p.z).project(camera);assert(Math.abs(dog.x)<1e-9);baseline??=dog.y;assert(Math.abs(dog.y-baseline)<1e-9)}}
 sim.reset();field.resetTreats();assert(!marker.visible);assert.equal(marker.scale.x,1);const geometries=new Set(),materials=new Set();field.root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());
});
