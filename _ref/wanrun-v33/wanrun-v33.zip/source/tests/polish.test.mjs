import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {breeds} from '../dist/breeds.js';
import {makeDog} from '../dist/dog-model.js';
import {footingFor, poseLegs} from '../dist/dog-gait.js';
import {A_FRAME, aFrameHeight, aFramePitch} from '../dist/a-frame.js';
import {SEESAW, seesawSurface} from '../dist/seesaw.js';
import {AgilitySimulation} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {addTunnel} from '../dist/tunnel.js';

const sole = new T.Vector3();
function clearances(dog, support) {
  dog.updateMatrixWorld(true);
  return dog.userData.legs.map(leg => {
    leg.userData.paw.localToWorld(sole.set(0, -1, 0));
    return sole.y - support(-sole.z);
  });
}
function checkContact(dog, support, running) {
  const gaps = clearances(dog, support);
  assert(Math.min(...gaps) > -.00001, 'sole below surface');
  assert(gaps.filter(gap => Math.abs(gap) < .00001).length >= (running ? 2 : 4));
}

test('all 24 coats plant the diagonal stance pair and lift the opposite paws, including on a banked turn', () => {
  const flat = () => .015;
  for (const breed of breeds) for (const index of breed.coats.keys()) {
    const dog = makeDog(breed, index);
    dog.scale.setScalar(.76);
    dog.rotation.set(0, Math.PI, .16, 'YXZ');
    for (let frame = 0; frame < 32; frame++) {
      const phase = frame / 8;
      dog.position.y = .025 * Math.abs(Math.cos(phase * 1.85));
      poseLegs(dog, phase, true, false, flat);
      checkContact(dog, flat, true);
    }
    poseLegs(dog, 0, true, false, flat);
    assert(Math.max(...clearances(dog, flat)) > .08);
    poseLegs(dog, 1, false, false, flat);
    checkContact(dog, flat, false);
    dog.position.y = 1;
    poseLegs(dog, 1, true, true, () => { throw Error('airborne dog sampled the ground'); });
    assert(Math.min(...clearances(dog, flat)) > .85);
    assert(dog.userData.legs[0].rotation.x * dog.userData.legs[1].rotation.x < 0);
  }
});

test('paws follow each panel at the ridge, the toes of the A-frame, and the rotating seesaw', () => {
  const dog = makeDog(breeds[3], 0), scale = .76;
  dog.scale.setScalar(scale);
  for (const course of ['hill-field', 'balance']) {
    const sim = new AgilitySimulation(course), ramp = course === 'hill-field';
    const obstacle = sim.layout.obstacles.find(o => o.type === (ramp ? 'a-frame' : 'seesaw'));
    const angles = ramp ? [0] : [-SEESAW.angle, 0, SEESAW.angle];
    for (const angle of angles) {
      const end = ramp ? A_FRAME.run : SEESAW.length / 2 * Math.cos(angle);
      const surface = offset => Math.abs(offset) > end ? -.035 :
        ramp ? aFrameHeight(offset) : seesawSurface(offset, angle);
      if (!ramp) sim.seesaws.get(obstacle.id).angle = angle;
      for (const distance of [-end - .1, -end + .15, -1, -.17, 0, .23, 1, end - .15, end + .1]) {
        sim.player.s = obstacle.s + distance;
        sim.player.x = obstacle.lane * 2;
        dog.position.y = surface(distance);
        dog.rotation.set(ramp ? aFramePitch(distance) : -angle, Math.PI, .06, 'YXZ');
        const support = ahead => surface(distance + ahead);
        for (const running of [false, true]) {
          poseLegs(dog, .45, running, false, footingFor(sim, true));
          checkContact(dog, support, running);
        }
      }
    }
  }
});

test('tunnel walls are continuous with an open entrance and exit, and the seesaw axle passes through its pivot', () => {
  for (const [radius, length] of [[1.58, 6], [.43, 1.16]]) {
    const root = new T.Group();
    addTunnel(root, (geo, color, x, y, z, parent) => {
      const part = new T.Mesh(geo, new T.MeshBasicMaterial({color}));
      part.position.set(x, y, z); parent.add(part); return part;
    }, radius, length);
    root.updateMatrixWorld(true);
    const cast = (x,y,z,dx,dy,dz) => new T.Raycaster(new T.Vector3(x,y,z), new T.Vector3(dx,dy,dz)).intersectObject(root,true);
    assert.equal(cast(0,.45*radius,-length,0,0,1).length, 0);
    assert.equal(root.children.filter(c => c.name === 'tunnel-rim').length, 2);
    for (const z of [-.46,-.3,-.1,.1,.3,.46]) {
      assert(cast(0, radius*.45, length*z, .6,.8,0).some(hit => hit.object.name === 'tunnel-fabric'));
    }
  }
  const field = makeAgilityField(new AgilitySimulation('balance').layout);
  for (const group of field.root.children.filter(c => c.getObjectByName('rigid-plank'))) {
    assert(group.getObjectByName('rigid-plank').position.equals(group.getObjectByName('seesaw-axle').position));
  }
});
