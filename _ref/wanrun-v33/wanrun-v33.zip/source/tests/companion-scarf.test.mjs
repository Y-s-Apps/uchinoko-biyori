import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {breeds} from '../dist/breeds.js';
import {makeCompanion,poseCompanion} from '../dist/companions.js';
import {poseLegs} from '../dist/dog-gait.js';

test('the scarf band is visible across the chest and both shoulders in selection and running poses',()=>{
  const ray=new T.Raycaster(),aim=new T.Vector3(),direction=new T.Vector3();
  for(const breed of breeds){
    const dog=makeCompanion(breed,0);
    const scarf=dog.getObjectByName('neck-scarf'),band=scarf.getObjectByName('scarf-band');
    const fabric=band.geometry.attributes.position;
    const center=new T.Box3().setFromObject(band).getCenter(new T.Vector3());
    for(const running of [false,true]){
      poseCompanion(dog,.82,running,false);
      poseLegs(dog,1.2,running,false,()=>0);
      dog.updateMatrixWorld(true);
      for(const angle of [0,-1.15,1.15]){
        const eye=center.clone().add(new T.Vector3(4*Math.sin(angle),.72,4*Math.cos(angle)));
        let visible=0,probes=0;
        // Long ears can cover a shoulder. The front bib should be visible across almost its full width.
        for(let i=0;i<64;i++){
          if(Math.cos(i*Math.PI/32-angle)<.86)continue;
          aim.fromBufferAttribute(fabric,3*64+i);
          ray.set(eye,direction.subVectors(aim,eye).normalize());
          if(ray.intersectObject(dog,true)[0]?.object===band)visible++;
          probes++;
        }
        assert(visible>=probes*(angle===0?.8:1/3),breed.id+' scarf hidden at '+angle+' ('+visible+'/'+probes+')');
      }
    }
  }
});
