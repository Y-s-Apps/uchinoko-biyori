import test from 'node:test';
import assert from 'node:assert/strict';
import {RaceSimulation,RACE,buildParkRace,gestureAction} from '../dist/race-sim.js';
const running=()=>{const s=new RaceSimulation();s.start();for(let i=0;i<181;i++)s.step(1/60);assert.equal(s.status,'running');return s};
const advance=(s,seconds,dt=1/60)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
test('countdown and hidden-page pause never advance race time or distance',()=>{const s=new RaceSimulation();s.start();s.step(.05);s.pause();const count=s.countdown;advance(s,3);assert.equal(s.countdown,count);assert.equal(s.time,0);s.resume();advance(s,3.1);assert.equal(s.status,'running');s.pause();const distance=s.player.s,time=s.time;advance(s,10);assert.equal(s.player.s,distance);assert.equal(s.time,time);assert.equal(s.input('dash'),false);s.resume();s.step(.02);assert(s.player.s>distance)});
test('full gauge waits for a tap; one activation lasts three seconds',()=>{const s=running();s.gauge=20;advance(s,.2);assert.equal(s.player.boost,0);assert.equal(s.dashCount,0);assert(s.input('dash'));assert.equal(s.gauge,0);assert.equal(s.player.boost,3);assert.equal(s.dashCount,1);s.gauge=20;assert.equal(s.input('dash'),false);advance(s,3.1);assert.equal(s.player.boost,0);assert.equal(s.dashCount,1);assert(s.input('dash'))});
test('hurdle collisions occur once, and a sufficiently high jump clears the bar',()=>{const hit=running(),o=hit.layout.obstacles[0];hit.player.s=o.s-.1;hit.player.x=o.lane*2;hit.player.lane=o.lane;hit.step(.03);assert.equal(hit.player.hits,1);advance(hit,.4);assert.equal(hit.player.hits,1);assert(hit.player.slow>0);const clear=running();clear.player.s=o.s-4.1;clear.player.x=o.lane*2;clear.player.lane=o.lane;assert(clear.input('jump'));assert.equal(clear.input('jump'),false);advance(clear,.6);assert(clear.player.s>o.s);assert.equal(clear.player.hits,0)});
test('hurdle treats are above the obstacle; tunnel treats stay at running height',()=>{const {treats,obstacles}=buildParkRace();assert(treats.length>150);for(const o of obstacles){const close=treats.filter(t=>Math.abs(t.s-o.s)<1.2);assert(close.length>0);for(const t of close){assert.equal(t.lane,o.lane);if(o.type==='hurdle')assert(t.y>1.45);else assert.equal(t.y,.65)}}});
test('one treat is collected once and gauge is capped',()=>{const s=running(),t=s.layout.treats[0];s.player.s=t.s-.2;s.player.lane=t.lane;s.player.x=t.lane*2;s.gauge=20;s.step(.02);assert.equal(s.treatCount,1);assert.equal(s.gauge,20);advance(s,.1);assert.equal(s.treatCount,1)});
test('lane bounds, tunnel entry and gesture cancellation thresholds',()=>{const s=running();for(let i=0;i<9;i++)s.input('left');assert.equal(s.player.lane,-1);for(let i=0;i<9;i++)s.input('right');assert.equal(s.player.lane,1);const o=s.layout.obstacles.find(o=>o.type==='tunnel');s.player.s=o.s;s.player.lane=o.lane;s.player.x=o.lane*2;assert.equal(s.input('jump'),false);assert.equal(s.input('left'),true);assert.equal(gestureAction(0,-35,150),'jump');assert.equal(gestureAction(36,2,100),'right');assert.equal(gestureAction(0,35,100),'brake');assert.equal(gestureAction(3,4,130),'dash');assert.equal(gestureAction(15,0,100),null);assert.equal(gestureAction(0,0,800),null)});
test('race finishes with real CPU ranking and reset clears all session state',()=>{const s=running();for(let i=0;i<6000&&s.status==='running';i++){const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);s.step(1/60)}assert.equal(s.status,'finished');assert(s.result.time>30&&s.result.time<90);assert(s.result.rank>=1&&s.result.rank<=5);const time=s.time;advance(s,5);assert.equal(s.time,time);s.reset();assert.equal(s.status,'ready');assert.equal(s.collected.size,0);assert.equal(s.time,0);assert.equal(s.player.hits,0);assert.equal(s.result,null)});
test('good lane choices, jumps and manual boosts can beat the CPUs',()=>{const s=running();for(let i=0;i<7000&&s.status==='running';i++){const p=s.player;const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);const next=s.layout.treats.find(t=>!s.collected.has(t.id)&&t.s>p.s+.3);const obstacle=s.layout.obstacles.find(o=>o.s>p.s&&o.s-p.s<7);
 const lane=obstacle?obstacle.lane:next?.lane??0;if(lane<p.lane)s.input('left');if(lane>p.lane)s.input('right');if(obstacle?.type==='hurdle'&&obstacle.s-p.s<(p.boost>0?6:4.3)&&p.jumpElapsed===null)s.input('jump');if(s.gauge===20)s.input('dash');s.step(1/60)}assert.equal(s.status,'finished');assert(s.result.treats>=60);assert(s.result.dashes>=3);assert.equal(s.result.rank,1)});

test('a quick short flick needs a clear axis and remains separate from a tap',()=>{
 for(const [dx,dy,action] of [[20,5,'right'],[-22,9,'left'],[3,-21,'jump'],[4,22,'brake']]){
  assert.equal(gestureAction(dx,dy,140,true),action);
  assert.equal(gestureAction(dx,dy,260,true),null);
  assert.equal(gestureAction(dx,dy,140),null);
 }
 assert.equal(gestureAction(19,1,80,true),null);
 assert.equal(gestureAction(20,19,100,true),null);
 assert.equal(gestureAction(1,2,200,true),'dash');
 assert.equal(gestureAction(1,2,400,true),null);
 assert.equal(gestureAction(32,5,450,true),'right');
});

test('park tunnel side walls block swipes on either side and apply the normal obstacle penalty once',()=>{
 for(const hz of [10,30,60,120])for(const side of [-1,1]){
  for(const gate of buildParkRace().obstacles.filter(o=>o.type==='tunnel')){
   const sim=running(),p=sim.player,center=gate.lane*RACE.lanewidth;
   Object.assign(p,{s:gate.s-3.8,x:center,lane:gate.lane});
   assert(sim.input(side<0?'left':'right'));
   while(!p.hits && p.s<gate.s+2.55)sim.step(1/hz);
   assert.equal(p.hits,1);assert.equal(p.slow,1.15);
   assert.equal(p.lane,gate.lane);assert(Math.abs(p.x-center)<1.3);
   assert.equal(sim.drainEvents().filter(e=>e.reason==='tunnel-wall').length,1);
   const hitAt=p.s;
   sim.step(1/hz);
   assert(Math.abs(p.s-hitAt-p.speed*.43/hz)<1e-8);
   for(let i=0;i<Math.ceil(.3*hz);i++){
    sim.input(side<0?'left':'right');sim.step(1/hz);
    assert(Math.abs(p.x-center)<1.3);
   }
   assert.equal(p.hits,1);
   sim.reset();assert.equal(sim.player.hits,0);
  }
 }
});

test('park tunnel geometry allows a straight run and an outside bypass, but blocks cutting through the fabric',()=>{
 const gate=buildParkRace().obstacles.filter(o=>o.type==='tunnel').at(-1);
 for(const lane of [-1,0,1]){
  const sim=running(),p=sim.player;
  Object.assign(p,{s:gate.s-6.5,x:lane*2,lane});
  while(p.s<gate.s+2.6)sim.step(.05);
  assert.equal(p.hits,0);
  sim.input(lane===1?'left':'right');advance(sim,.25);
  assert.equal(p.hits,0);
 }
 for(const side of [-1,1]){
  const sim=running(),p=sim.player;
  Object.assign(p,{s:gate.s-1,x:side*2,lane:side,boost:2});
  sim.layout.treats=[{id:999,s:gate.s+.56,lane:0,y:.65}];
  sim.input(side<0?'right':'left');sim.step(.1);
  assert.equal(sim.treatCount,0,'a pickup across the wall is out of reach');
  assert.equal(p.hits,1);assert.equal(p.lane,side);assert(Math.abs(p.x)>1.9);
 }
});

test('all five results use finish-line crossing times even when the player wins', () => {
 const dt=1/60;
 for(const id of ['park','beach','forest']){
  const leader=new RaceSimulation(id), spectator=new RaceSimulation(id);
  leader.start();spectator.start();
  // The second player waits at a turn while the four identical rivals run to the finish.
  // Move the first player close to the finish to exercise rivals still racing behind it.
  leader.player.s=leader.layout.length-2;
  for(let i=0;i<9000&&spectator.cpus.some(dog=>dog.finishTime===null);i++){
   if(leader.status!=='finished')leader.step(dt);
   spectator.step(dt);
  }
  const expected=[{id:'player',time:leader.player.finishTime},...spectator.cpus.map(({id,finishTime})=>({id,time:finishTime}))].sort((a,b)=>a.time-b.time);
  assert.equal(leader.result.rank,1);
  assert(expected.every(dog=>dog.time>0));
  assert.deepEqual(leader.result.standings,expected);
  assert(leader.cpus.every(dog=>dog.finishTime===null));
 }
});
