import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation, RACE} from '../dist/race-sim.js';
import {buildForestRace} from '../dist/forest-layout.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {cornerAt,TURN_WINDOW} from '../dist/race-route.js';
import {courses,canPlay} from '../dist/courses.js';
import {makeCourseScene} from '../dist/course-scene.js';
import {breeds} from '../dist/breeds.js';

function start(course) {
  const sim = new RaceSimulation(course);
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}

test('each beach log rewards one normal or boosted jump at different frame intervals', () => {
  for (const log of start('beach').layout.obstacles) {
    for (const dt of [1/60, .05, .1]) for (const boosted of [true,false]) {
      const sim = start('beach'), p = sim.player;
      const speed = boosted ? RACE.boostSpeed : p.speed;
      p.s = log.s - speed * RACE.jumpDuration * .5;
      p.lane = log.lane; p.x = log.lane * RACE.lanewidth;
      if (boosted) {sim.gauge = 20;assert(sim.input('dash'))}
      assert(sim.input('jump'));
      while (p.s <= log.s+4) sim.step(dt);
      assert.equal(p.hits,0);
      const arc=sim.layout.treats.filter(t=>t.jumpLog===log.id);
      assert.equal(arc.filter(t=>sim.collected.has(t.id)).length,3);
    }
  }
});

test('forest rounds six real bends and allows all seven logs to be jumped in one race', () => {
  for(const dt of [1/60,.05,.1]){
    const sim=start('forest'), p=sim.player;
    assert.equal(sim.cpus.length,4);assert.equal(sim.layout.theme,'forest');
    let jumps=0;
    for(let i=0;i<6500&&sim.status==='running';i++){
      const cue=sim.turnCue;
      if(cue?.active&&!cue.armed)sim.input(cue.direction);
      if(!cue?.active){
        const next=sim.layout.obstacles.find(log=>p.s<log.s+3.4&&log.s-p.s<13);
        const lane=next?.lane??0;
        if(lane!==p.lane)sim.input(lane>p.lane?'right':'left');
        if(next && next.s>p.s && next.s-p.s<4.6 && p.jumpElapsed===null){sim.input('jump');jumps++}
      }
      sim.step(dt);
    }
    assert.equal(sim.status,'finished');assert.equal(sim.result.turns,6);assert.equal(sim.result.turnMisses,0);
    assert.equal(jumps,7);assert.equal(p.hits,0);assert.equal(p.s,510);assert(sim.result.rank>=1&&sim.result.rank<=5);
    assert(sim.layout.treats.filter(t=>t.jumpLog!==undefined).every(t=>sim.collected.has(t.id)));
    sim.reset();assert.equal(sim.gauge,0);assert.equal(sim.collected.size,0);assert.equal(sim.layout.theme,'forest');
  }
});

test('forest obstacles and turns leave space for steering; scenery, preview and rewards follow the playable path', () => {
  const layout=buildForestRace(),track=makeRaceTrack(layout), root=track.root;
  assert(canPlay('race','forest'));assert(root.getObjectByName('birch-trunks'));assert(root.getObjectByName('fir-boughs'));
  assert.equal(layout.turns.length,6);assert.equal(layout.obstacles.length,7);
  const preview=makeCourseScene(courses.find(c=>c.id==='forest'),breeds[0],0);
  assert.equal(preview.children.filter(o=>o.name==='log').length,7);
  assert.equal(preview.children.filter(o=>o.name==='treat'&&o.position.y>.3).length,21);
  for(const log of layout.obstacles){
    assert(!cornerAt(log.s,TURN_WINDOW+2.1,6,layout.turns));
    const mesh=root.children.find(c=>c.name==='race-obstacle'&&c.userData.obstacleId===log.id), p=layout.point(log.s,log.lane*2);
    assert(Math.hypot(mesh.position.x-p.x,mesh.position.z-p.z)<1e-6);
    const arc=layout.treats.filter(t=>t.jumpLog===log.id);assert.equal(arc.length,3);
    for(const treat of arc){const m=new T.Matrix4();track.treatMesh.getMatrixAt(treat.id,m);const v=new T.Vector3().setFromMatrixPosition(m),location=layout.point(treat.s,log.lane*2);assert(Math.hypot(v.x-location.x,v.z-location.z)<.0001);assert(Math.abs(v.y-treat.y)<1e-5)}
  }
  const end=layout.point(layout.length),gate=root.getObjectByName('finish-gate');
  assert(Math.hypot(gate.position.x-end.x,gate.position.z-end.z)<1e-6);
  for(const object of [root,preview])object.traverse(o=>{if(o.geometry){assert(o.geometry.attributes.position.array.every(Number.isFinite));o.geometry.dispose();o.material.dispose()}});
});

test('forest rivals make the jump trail count in the final standings',()=>{
 for(const dt of [1/60,.05,.1]){
  const results=[];
  for(const followLogs of [false,true]){
   const sim=start('forest'),p=sim.player;
   for(let frame=0;frame<8000&&sim.status==='running';frame++){
    const cue=sim.turnCue;
    if(cue?.active&&!cue.armed)sim.input(cue.direction);
    const log=sim.layout.obstacles.find(o=>o.s>p.s-3&&o.s-p.s<13);
    const next=sim.layout.treats.find(t=>t.s>=p.s+1.5);
    const lane=followLogs?(log?.lane??next?.lane??0):0;
    if(!cue?.active&&p.lane!==lane)sim.input(p.lane<lane?'right':'left');
    if(sim.gauge===RACE.gaugeMax)sim.input('dash');
    const apex=RACE.jumpDuration/2+dt/2;
    const lead=p.speed*apex+(RACE.boostSpeed-p.speed)*Math.min(apex,p.boost);
    if(log&&p.lane===log.lane&&log.s>p.s&&log.s-p.s<lead)sim.input('jump');
    sim.step(dt);
   }
   assert.equal(sim.status,'finished');
   assert.equal(sim.result.turnMisses,0);assert.equal(sim.result.hits,0);
   results.push(sim.result);
  }
  const [centre,trail]=results;
  assert(centre.rank>1);assert.equal(trail.rank,1);
  assert(trail.time<centre.time);assert(trail.treats>centre.treats);
 }
});
