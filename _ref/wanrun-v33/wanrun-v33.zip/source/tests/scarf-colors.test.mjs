import test from 'node:test';
import assert from 'node:assert/strict';
import {breeds} from '../dist/breeds.js';
import {scarfOption,scarfOptions} from '../dist/scarf-colors.js';
import {makeCompanion} from '../dist/companions.js';

test('only the six named colors are offered and legacy automatic preferences resolve to blue',()=>{
  assert.deepEqual(scarfOptions.map(o=>o.id),['blue','red','yellow','green','purple','pink']);
  for(const id of [undefined,'auto',null,'outdated'])assert.equal(scarfOption(id).id,'blue');
  for(const option of scarfOptions)assert.equal(scarfOption(option.id),option);
});

test('explicit colors cover both cloth and knot',()=>{
  for(const breed of breeds){
    for(const choice of scarfOptions){
      const dog=makeCompanion(breed,1,choice.color);
      const scarf=dog.getObjectByName('neck-scarf');
      assert(scarf.getObjectByName('scarf-band')&&scarf.getObjectByName('scarf-knot'));
      scarf.traverse(part=>{
        if(part.isMesh)assert.equal('#'+part.material.color.getHexString(),choice.color);
      });
    }
  }
});
