import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation,RACE,buildParkRace} from '../dist/race-sim.js';
import {PARK_TURNS,TURN_WINDOW,cornerAt,routePoint} from '../dist/race-route.js';
import {makeRaceTrack,roadRibbon} from '../dist/race-track.js';
const close=(a,b,e=1e-5)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
const run=()=>{const s=new RaceSimulation();s.start();for(let i=0;i<61;i++)s.step(.05);return s};
const advance=(s,seconds,dt=.02)=>{for(let i=0;i<Math.ceil(seconds/dt);i++)s.step(dt)};
test('four real 90-degree bends have continuous positions, tangents and lane spacing',()=>{
 assert.deepEqual(PARK_TURNS.map(t=>t.direction),['right','left','left','right']);
 for(const t of PARK_TURNS){
  const a=routePoint(t.start),b=routePoint(t.end);close(b.heading-a.heading,(t.direction==='right'?1:-1)*Math.PI/2);
  for(const at of [t.start,t.end]){const before=routePoint(at-.000001),after=routePoint(at+.000001);assert(Math.hypot(after.x-before.x,after.z-before.z)<.000003);assert(Math.abs(after.heading-before.heading)<.000001)}
 }
 for(let s=-10;s<=510;s+=.75){const p=routePoint(s),right=routePoint(s,2),left=routePoint(s,-2);close(Math.hypot(right.x-left.x,right.z-left.z),4);assert([p.x,p.z,p.heading].every(Number.isFinite))}
 assert(Math.abs(routePoint(160).x)>50,'course must move in world X, not just sway the camera');
});
test('straight swipes move lanes; early directional swipes queue one turn without lane changes',()=>{
 const s=run(),t=PARK_TURNS[0];assert(s.input('right'));assert.equal(s.player.lane,1);
 s.player.s=t.start-TURN_WINDOW-.1;assert(s.input('left'));assert.equal(s.player.lane,0);assert(!s.armedTurns.has(t.id));
 s.player.s=t.start-TURN_WINDOW;assert.equal(s.input('left'),false);assert.equal(s.player.lane,0);assert(s.input('right'));assert(s.armedTurns.has(t.id));assert.equal(s.input('right'),false);
 advance(s,4.1);assert(s.player.s>t.end);assert.equal(s.passedTurns.size,1);assert.equal(s.missedTurns.size,0);assert(s.input('left'));assert.equal(s.player.lane,-1);
});
test('missing a turn stops at the corner while CPU racers continue; correct swipe resumes',()=>{
 const s=run(),t=PARK_TURNS[0];s.player.s=t.start-.2;advance(s,.1);close(s.player.s,t.start);assert.equal(s.waitingTurn,t.id);
 const cpu=s.cpus[0].s;advance(s,2);close(s.player.s,t.start);assert(s.cpus[0].s>cpu);assert.equal(s.missedTurns.size,1);
 assert.equal(s.input('left'),false);assert.equal(s.input('jump'),false);s.gauge=20;assert.equal(s.input('dash'),false);assert.equal(s.gauge,20);
 assert(s.input('right'));assert.equal(s.waitingTurn,null);advance(s,.2);assert(s.player.s>t.start);
 assert.equal(s.drainEvents().filter(e=>e.type==='turn-missed').length,1);
});
test('each direction is required independently; turn state survives pause and clears on retry',()=>{
 const s=run();for(const t of PARK_TURNS){s.player.s=t.start-2;assert.equal(s.input(t.direction==='right'?'left':'right'),false);assert(s.input(t.direction));s.pause();const d=s.player.s;advance(s,2);assert.equal(s.player.s,d);assert(s.armedTurns.has(t.id));s.resume();advance(s,2);assert(s.passedTurns.has(t.id))}
 assert.equal(s.passedTurns.size,4);s.reset();assert.equal(s.armedTurns.size,0);assert.equal(s.passedTurns.size,0);assert.equal(s.missedTurns.size,0);assert.equal(s.waitingTurn,null);
});
test('dash cannot skip unconfirmed turns, including large supported frame steps',()=>{
 for(const dt of [1/120,1/60,.05,.1]){const s=run(),t=PARK_TURNS[0];s.player.s=t.start-.05;s.gauge=20;s.input('dash');s.step(dt);close(s.player.s,t.start);assert.equal(s.waitingTurn,t.id);assert(s.input(t.direction));advance(s,1.2,dt);assert(s.player.s>t.end);assert.equal(s.passedTurns.size,1)}
});
test('turn approaches have no obstacles and the treat trail follows the middle of each corner',()=>{
 const {obstacles,treats}=buildParkRace();assert(obstacles.some(o=>o.type==='tunnel'));assert(obstacles.some(o=>o.type==='hurdle'));
 for(const o of obstacles)assert(!cornerAt(o.s,TURN_WINDOW+6,9));
 for(const t of PARK_TURNS){const inside=treats.filter(b=>b.s>=t.start&&b.s<=t.end);assert(inside.length>=6);assert(inside.every(b=>b.lane===0&&b.y===.65))}
});
test('rendered road, obstacles, treats and finish gate share the physics route',()=>{
 const layout=buildParkRace(),track=makeRaceTrack(layout),root=track.root;root.updateMatrixWorld(true);
 const ribbon=roadRibbon(0,7.6,.015);for(const y of ribbon.attributes.normal.array.filter((_,i)=>i%3===1))assert(y>.99);
 root.traverse(o=>{if(o.geometry)assert(o.geometry.attributes.position.array.every(Number.isFinite));if(o.name==='race-obstacle'){const ob=layout.obstacles.find(x=>x.id===o.userData.obstacleId),p=routePoint(ob.s,ob.lane*2);close(o.position.x,p.x);close(o.position.z,p.z);close(o.rotation.y,-p.heading)}});
 const matrix=new T.Matrix4(),v=new T.Vector3();for(const t of layout.treats){track.treatMesh.getMatrixAt(t.id,matrix);v.setFromMatrixPosition(matrix);const p=routePoint(t.s,t.lane*2);close(v.x,p.x,.0001);close(v.z,p.z,.0001);close(v.y,t.y,.0001)}
 const end=routePoint(RACE.length),gate=root.getObjectByName('finish-gate');close(gate.position.x,end.x);close(gate.position.z,end.z);
 track.collectTreat(0);track.treatMesh.getMatrixAt(0,matrix);assert.equal(matrix.elements[0],0);track.resetTreats();track.treatMesh.getMatrixAt(0,matrix);assert.equal(matrix.elements[0],1);
 const geometries=new Set(),materials=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());ribbon.dispose();
});
