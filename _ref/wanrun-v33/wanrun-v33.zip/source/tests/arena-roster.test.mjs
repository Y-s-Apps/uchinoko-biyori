import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {FIELD_SEGMENTS,FIELD_BOUNDS,fieldPoint,FIELD_LENGTH} from '../dist/agility-route.js';
import {AGILITY,AgilitySimulation,buildFirstField} from '../dist/agility-sim.js';
import {RaceSimulation} from '../dist/race-sim.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
import {makeAgilityField} from '../dist/agility-field.js';
test('agility runs 50% faster without adding an item system',()=>{
 assert.equal(AGILITY.speed,7.5*1.5);const s=new AgilitySimulation();s.start();for(let i=0;i<61;i++)s.step(.05);
 const before=s.player.s;for(let i=0;i<60;i++)s.step(1/60);assert(Math.abs(s.player.s-before-11.25)<1e-8);assert.equal(s.input('dash'),false);assert.equal(s.layout.treats.length,0);assert.equal(s.cpus.length,0);
});
test('the course folds through an open arena, with continuous headings and clear perimeter margins',()=>{
 const b=FIELD_BOUNDS;let east=false,west=false,south=false;
 for(let s=0;s<=FIELD_LENGTH;s+=.3)for(const lane of [-2,0,2]){const p=fieldPoint(s,lane),next=fieldPoint(s+.001,lane);assert(p.x>b.minX+6&&p.x<b.maxX-6);assert(p.z>b.minZ+6&&p.z<b.maxZ-6);assert(Math.hypot(next.x-p.x,next.z-p.z)<.002);east||=Math.sin(p.heading)>.9;west||=Math.sin(p.heading)<-.9;south||=Math.cos(p.heading)<-.9}
 assert(east&&west&&south);for(const t of FIELD_SEGMENTS.slice(1)){const a=fieldPoint(t.start-.00001),b=fieldPoint(t.start+.00001);assert(Math.hypot(a.x-b.x,a.z-b.z)<.00003);assert(Math.abs(a.heading-b.heading)<.00001)}
 const obstacles=buildFirstField().obstacles;for(const o of obstacles){const segment=FIELD_SEGMENTS.find(t=>o.s>=t.start&&o.s<=t.end);assert.equal(segment.turn,0);assert(o.s-segment.start>7&&segment.end-o.s>7)}
});
test('rear-camera projection stays centred through the new arena turns in portrait and landscape',()=>{
 for(const aspect of [390/844,844/390]){const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let screenY;
  for(let s=0;s<FIELD_LENGTH;s+=.5){const p=fieldPoint(s,2),pose=chaseCameraPose(p);camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const projected=new T.Vector3(p.x,.75,p.z).project(camera);assert(Math.abs(projected.x)<1e-9);screenY??=projected.y;assert(Math.abs(projected.y-screenY)<1e-9)}
 }
});
test('arena fence encloses the whole lawn; target marker follows only the next obstacle',()=>{
 const s=new AgilitySimulation(),field=makeAgilityField(s.layout),b=FIELD_BOUNDS;
 assert(field.root.getObjectByName('open-lawn'));for(const name of ['continuous-road','lane-markings','fence-rails','treat-trail'])assert(!field.root.getObjectByName(name));
 const posts=field.root.getObjectByName('perimeter-posts'),m=new T.Matrix4(),p=new T.Vector3();for(let i=0;i<posts.count;i++){posts.getMatrixAt(i,m);p.setFromMatrixPosition(m);assert(Math.min(Math.abs(p.x-b.minX),Math.abs(p.x-b.maxX),Math.abs(p.z-b.minZ),Math.abs(p.z-b.maxZ))<.0001)}
 field.update(s);const marker=field.root.getObjectByName('next-obstacle-marker'),first=fieldPoint(s.layout.obstacles[0].s);assert(marker.visible);assert.equal(marker.position.x,first.x);
 s.results.set(0,true);field.update(s);const second=s.layout.obstacles[1],pos=fieldPoint(second.s,second.lane*2);assert.equal(marker.position.x,pos.x);assert.equal(marker.position.z,pos.z);
 for(const o of s.layout.obstacles)s.results.set(o.id,true);field.update(s);assert(!marker.visible);field.resetTreats();assert(!marker.visible);
 const geo=new Set(),mats=new Set();field.root.traverse(o=>{if(o.geometry)geo.add(o.geometry);if(o.material)mats.add(o.material)});geo.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());
});
test('race has four finite CPU actors and correctly awards fifth place, including after retry',()=>{
 const s=new RaceSimulation();assert.equal(s.cpus.length,4);assert.equal(new Set(s.cpus.map(c=>c.id)).size,4);s.start();
 for(let i=0;i<1300;i++)s.step(.05);assert.equal(s.rank,5);assert(s.cpus.every(c=>c.finishTime!==null&&Number.isFinite(c.x)&&Number.isFinite(c.s)));
 for(let i=0;i<1300&&s.status!=='finished';i++){const cue=s.turnCue;if(cue?.active&&!cue.armed)s.input(cue.direction);s.step(.05)}
 assert.equal(s.status,'finished');assert.equal(s.result.rank,5);s.reset();assert.equal(s.cpus.length,4);assert(s.cpus.every(c=>c.finishTime===null));
});
