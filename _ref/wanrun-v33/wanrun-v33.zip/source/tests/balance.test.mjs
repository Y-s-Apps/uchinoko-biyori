import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {AgilitySimulation,AGILITY,buildAgilityCourse} from '../dist/agility-sim.js';
import {SEESAW,seesawHalfSpan,seesawSurface} from '../dist/seesaw.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';
const advance=(sim,seconds)=>{for(let i=0;i<Math.ceil(seconds*60);i++)sim.step(1/60)};
const running=()=>{const sim=new AgilitySimulation('balance');sim.start();advance(sim,3.1);return sim};
const enter=()=>{const sim=running(),o=sim.layout.obstacles.find(o=>o.type==='seesaw');sim.player.s=o.s-seesawHalfSpan()-.2;sim.player.x=o.lane*2;sim.player.lane=o.lane;advance(sim,.1);assert.equal(sim.activeSeesaw.state.phase,'approach');return {sim,o}};
test('seesaw requires stopping near its centre, waiting, and manually tapping to exit',()=>{
 const {sim,o}=enter();assert.equal(sim.input('jump'),false);assert.equal(sim.input('right'),false);
 sim.input('brake');advance(sim,1);assert.equal(sim.activeSeesaw.state.phase,'approach','early stop must not tip the board');sim.input('dash');
 while(sim.player.s<o.s+.1)sim.step(1/60);sim.input('brake');const position=sim.player.s,time=sim.time;assert.equal(sim.activeSeesaw.state.phase,'hold');assert.equal(sim.input('dash'),false);
 advance(sim,.6);assert.equal(sim.activeSeesaw.state.phase,'tipping');assert.equal(sim.input('dash'),false);const angle=sim.activeSeesaw.state.angle;
 sim.pause();advance(sim,2);assert.equal(sim.activeSeesaw.state.angle,angle);sim.resume();advance(sim,1);assert.equal(sim.activeSeesaw.state.phase,'ready');assert.equal(sim.player.s,position);assert(sim.time>time+1.5);assert(sim.stopped);
 advance(sim,1);assert.equal(sim.player.s,position,'board reaching ground never auto-resumes');sim.input('dash');advance(sim,1.3);assert.equal(sim.results.get(o.id),true);assert.equal(sim.cleared,1);assert.equal(sim.player.surfaceY,0);assert.equal(sim.player.pitch,0);
 const s=sim.player.s;advance(sim,.2);assert(Math.abs(sim.player.s-s-AGILITY.speed*.2)<1e-8);
});
test('missing the stop recovers on the board and counts one fault only on exit',()=>{
 const {sim,o}=enter();advance(sim,3);assert.equal(sim.activeSeesaw.state.phase,'ready');assert(sim.stopped);assert(sim.activeSeesaw.state.failed);assert.equal(sim.results.has(o.id),false);sim.input('dash');advance(sim,2);assert.equal(sim.results.get(o.id),false);assert.equal(sim.faults,1);advance(sim,.5);assert.equal(sim.faults,1);
});
test('bypassing or jumping onto a seesaw cannot count as a successful crossing',()=>{
 for(const jump of [true,false]){const sim=running(),o=sim.layout.obstacles[1];sim.player.s=o.s-seesawHalfSpan()-.3;sim.player.lane=jump?o.lane:1;sim.player.x=sim.player.lane*2;if(jump)sim.input('jump');advance(sim,1.3);assert.equal(sim.results.get(o.id),false);assert.equal(sim.faults,1);assert.equal(sim.activeSeesaw,null)}
});
test('all six balance obstacles can be cleared in a continuous run at varied frame intervals',()=>{
 for(const dt of [1/60,.05,.1]){const sim=running();for(let i=0;i<6000&&sim.status==='running';i++){
  const o=sim.nextObstacle,p=sim.player,board=sim.activeSeesaw;
  if(board){if(board.state.phase==='approach'&&p.s>=o.s-.25)sim.input('brake');if(board.state.phase==='ready')sim.input('dash')}
  else if(o){if(o.lane<p.lane)sim.input('left');if(o.lane>p.lane)sim.input('right');if(['hoop','hurdle'].includes(o.type)&&o.s-p.s<3.8&&o.s>p.s&&p.jumpElapsed===null)sim.input('jump')}
  sim.step(dt);
 }
 assert.equal(sim.status,'finished');assert.equal(sim.cleared,6);assert.equal(sim.faults,0);assert.equal(sim.result.total,sim.result.time);assert.equal(sim.cpus.length,0);assert.equal(sim.layout.treats.length,0);
 sim.reset();assert.equal(sim.results.size,0);assert.equal(sim.activeSeesaw,null);assert.equal(sim.player.y,0);assert.equal(sim.player.pitch,0);assert([...sim.seesaws.values()].every(s=>s.phase==='idle'&&s.angle===SEESAW.angle&&!s.failed));
 }
});
test('a tipping board stays rigid and the dog contact point remains on its painted top surface',()=>{
 const {sim,o}=enter(),field=makeAgilityField(sim.layout),plank=field.root.getObjectByName('rigid-plank');
 const parts=plank.children.slice().sort((a,b)=>a.position.z-b.position.z);assert.equal(parts.length,3);
 for(let i=1;i<parts.length;i++)assert(Math.abs(parts[i-1].position.z+parts[i-1].geometry.parameters.depth/2-parts[i].position.z+parts[i].geometry.parameters.depth/2)<1e-9);
 while(sim.player.s<o.s+.2)sim.step(1/60);sim.input('brake');let tipped=false;
 for(let i=0;i<100;i++){sim.step(1/60);field.animate(sim);field.root.updateMatrixWorld(true);const state=sim.seesaws.get(o.id),p=sim.player,anchor=sim.layout.point(p.s,p.x),contact=plank.worldToLocal(new T.Vector3(anchor.x,p.y,anchor.z));assert(Math.abs(contact.y-SEESAW.thickness/2)<1e-8);assert(Math.abs(contact.x)<1e-8);assert.equal(plank.rotation.x,state.angle);assert.equal(p.pitch,-state.angle);tipped||=state.angle<0}
 assert(tipped);sim.reset();field.resetTreats();assert.equal(plank.rotation.x,SEESAW.angle);
 const geo=new Set(),mats=new Set();field.root.traverse(o=>{if(o.geometry)geo.add(o.geometry);if(o.material)mats.add(o.material)});geo.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());
});
test('camera stays centred vertically as either seesaw tips, in portrait and landscape',()=>{
 for(const aspect of [390/844,844/390]){const camera=new T.PerspectiveCamera(aspect>1?54:60,aspect,.1,180);let screenY;
  for(const o of buildAgilityCourse('balance').obstacles.filter(o=>o.type==='seesaw'))for(const angle of [SEESAW.angle,0,-SEESAW.angle]){const p=buildAgilityCourse('balance').point(o.s+.4,o.lane*2),surface=seesawSurface(.4,angle),pose=chaseCameraPose(p,{height:2.8+surface,lookHeight:1+surface});camera.position.set(pose.position.x,pose.position.y,pose.position.z);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld();const dog=new T.Vector3(p.x,surface+.75,p.z).project(camera);assert(Math.abs(dog.x)<1e-9);screenY??=dog.y;assert(Math.abs(dog.y-screenY)<1e-9)}
 }
});
