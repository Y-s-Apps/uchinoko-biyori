import test from 'node:test';
import assert from 'node:assert/strict';
import {courses,nextPlayableCourse} from '../dist/courses.js';

test('continue in the same mode, skipping preview courses and stopping at the end',()=>{
 const preview={id:'preview-only',mode:'race'};
 const index=courses.findIndex(course=>course.id==='park')+1;
 courses.splice(index,0,preview);
 try{
  assert.equal(nextPlayableCourse('race','park')?.id,'beach');
  assert.equal(nextPlayableCourse('race','beach')?.id,'forest');
  assert.equal(nextPlayableCourse('race','forest'),null);
  assert.equal(nextPlayableCourse('agility','first-field')?.id,'zigzag');
  assert.equal(nextPlayableCourse('agility','zigzag')?.id,'balance');
  assert.equal(nextPlayableCourse('agility','balance')?.id,'hill-field');
  assert.equal(nextPlayableCourse('agility','hill-field'),null);
  assert.equal(nextPlayableCourse('agility','park'),null);
 }finally{courses.splice(index,1)}
});
