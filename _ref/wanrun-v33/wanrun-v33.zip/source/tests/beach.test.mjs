import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {RaceSimulation, RACE} from '../dist/race-sim.js';
import {buildBeachRace, touchesSoftSand} from '../dist/beach-layout.js';
import {cornerAt, TURN_WINDOW} from '../dist/race-route.js';
import {makeRaceTrack} from '../dist/race-track.js';
import {courses,canPlay} from '../dist/courses.js';
import {breeds} from '../dist/breeds.js';
import {makeCourseScene} from '../dist/course-scene.js';

function start() {
  const sim = new RaceSimulation('beach');
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}
test('the beach has reachable trails beside all logs and clear turn windows', () => {
  const layout = buildBeachRace();
  assert(canPlay('race','beach'));
  assert.deepEqual(layout.obstacles.map(log=>log.lane),[0,1,-1,1,-1]);
  assert.equal(new Set(layout.treats.map(x=>x.id)).size,layout.treats.length);
  for (const o of layout.obstacles) {
    const row = layout.treats.filter(t=>Math.abs(t.s-o.s)<8 && t.lane===o.snackLane);
    const arc=layout.treats.filter(t=>t.jumpLog===o.id);
    assert.equal(arc.length,3);assert(arc.every(t=>t.lane===o.lane && t.y>.65+.8));
    assert.equal(row.length,13);
    assert(row.every(t=>t.lane===o.snackLane && t.y===.65 && !cornerAt(t.s,TURN_WINDOW,4,layout.turns)));
    assert.notEqual(o.lane,o.snackLane);
    assert(!touchesSoftSand(layout.sand,o.s,o.lane*RACE.lanewidth));
    assert(!layout.treats.some(t=>t.lane===o.lane && t.y===.65 && Math.abs(t.s-o.s)<8));
    assert(touchesSoftSand(layout.sand,o.s,o.snackLane*2));
  }
  for (const turn of layout.turns) {
    const start = layout.point(turn.start), end = layout.point(turn.end);
    assert((end.heading-start.heading)*(turn.direction==='right'?1:-1)>.4);
    const p = layout.point(turn.end-.001), q = layout.point(turn.end+.001);
    assert(Math.hypot(p.x-q.x,p.z-q.z)<.0021);
  }
});
test('the firm line rewards a jump and the soft side awards the whole treat row', () => {
  for(const choice of ['jump','hit','snacks']){
    const sim=start(), log=sim.layout.obstacles[0],p=sim.player;
    p.s=log.s-8.2;
    if(choice==='snacks')sim.input('left');
    let slowSand=false,elapsed=0;
    while(p.s<log.s+8.2){
      if(choice==='jump'&&p.s>=log.s-3.6&&p.s<log.s&&p.jumpElapsed===null)sim.input('jump');
      const before=p.s;sim.step(.025);elapsed+=.025;
      if(Math.abs(p.s-log.s)<3 && p.s-before<RACE.speed*.025*.9)slowSand=true;
    }
    assert.equal(p.hits,choice==='hit'?1:0);
    if(choice==='jump'){assert(elapsed<1.8);assert.equal(sim.treatCount,3)}
    if(choice==='hit')assert.equal(sim.treatCount,0);
    if(choice==='snacks'){assert.equal(sim.treatCount,13);assert(slowSand);assert(elapsed>1.8)}
  }
});
test('a five-dog beach race supports manual boosts, real turns, recovery, finish and retry', () => {
  for(const dt of [.02,.05,.1]){
    const sim=start();let ready=false,recovered=false;
    for(let i=0;i<9000&&sim.status==='running';i++){
      const cue=sim.turnCue,p=sim.player;
      if(cue?.waiting){assert.equal(cue.start,p.s);assert.equal(sim.input(cue.direction==='right'?'left':'right'),false);sim.input(cue.direction);recovered=true}
      else if(cue?.active&&cue.id!==0&&!cue.armed)sim.input(cue.direction);
      else if(!cue?.active){
        const log=sim.layout.obstacles.find(o=>p.s>o.s-11&&p.s<o.s+8);
        const lane=log?.snackLane??0;
        if(p.lane!==lane)sim.input(lane>p.lane?'right':'left');
      }
      if(sim.gauge===20 && !p.boost){assert.equal(p.boost,0);ready=true;sim.input('dash')}
      sim.step(dt);
    }
    assert(ready&&recovered);assert.equal(sim.status,'finished');assert.equal(sim.cpus.length,4);assert.equal(sim.player.s,sim.layout.length);assert(sim.result.dashes>0);
    assert.equal(sim.result.turns,4);assert.equal(sim.result.turnMisses,1);assert(sim.result.rank>=1&&sim.result.rank<=5);
    sim.reset();assert.equal(sim.layout.theme,'beach');assert.equal(sim.collected.size,0);assert.equal(sim.gauge,0);
  }
});
test('beach geometry, log and pickup positions match the physics route', () => {
  const layout=buildBeachRace(),track=makeRaceTrack(layout),preview=makeCourseScene(courses.find(c=>c.id==='beach'),breeds[0],0);
  for(const name of ['ocean','surf-line','soft-sand','beach-stakes','parasols','finish-gate'])assert(track.root.getObjectByName(name),name);
  assert(!track.root.getObjectByName('fence-rails'));
  const logs=track.root.children.filter(c=>c.name==='race-obstacle');
  assert.equal(logs.length,5);assert.equal(preview.children.filter(c=>c.name==='log').length,5);
  for(const obj of logs){const o=layout.obstacles[obj.userData.obstacleId],p=layout.point(o.s,o.lane*2);assert.equal(obj.position.x,p.x);assert.equal(obj.position.z,p.z)}
  const matrix=new T.Matrix4(),v=new T.Vector3();
  for(const t of layout.treats){track.treatMesh.getMatrixAt(t.id,matrix);v.setFromMatrixPosition(matrix);const p=layout.point(t.s,t.lane*2);assert(Math.hypot(v.x-p.x,v.z-p.z)<.0001)}
  const gate=track.root.getObjectByName('finish-gate'),p=layout.point(layout.length);assert.equal(gate.position.x,p.x);assert.equal(gate.position.z,p.z);
  for(const obj of [track.root,preview])obj.traverse(node=>{if(node.geometry){assert(node.geometry.attributes.position.array.every(Number.isFinite));node.geometry.dispose();node.material.dispose()}});
});

test('steering along either beach trail beats staying in the middle even with timely jumps and dashes', () => {
  for (const dt of [1/60, .05, .1]) {
    const results = {};
    for (const route of ['middle', 'logs', 'sand']) {
      const sim = start(), p = sim.player;
      for (let frame = 0; frame < 6500 && sim.status === 'running'; frame++) {
        const turn = sim.turnCue;
        if (turn?.active && !turn.armed) sim.input(turn.direction);
        const log = sim.layout.obstacles.find(o => p.s < o.s + 8.6 && o.s - p.s < 16);
        let lane = 0;
        if (route !== 'middle') {
          const ground = sim.layout.treats.find(t => t.s >= p.s + 1.9 && t.y === .65);
          lane = log ? (route === 'logs' ? log.lane : log.snackLane) : (ground?.lane ?? 0);
        }
        if (!turn?.active && p.lane !== lane) sim.input(p.lane < lane ? 'right' : 'left');
        if (sim.gauge === RACE.gaugeMax) sim.input('dash');
        const toApex = RACE.jumpDuration / 2 + dt / 2;
        const takeoff = p.speed * toApex + (RACE.boostSpeed - p.speed) * Math.min(p.boost, toApex);
        if (log && p.lane === log.lane && p.s < log.s && log.s - p.s < takeoff) sim.input('jump');
        sim.step(dt);
      }
      assert.equal(sim.status, 'finished');
      assert.equal(sim.result.turnMisses, 0);
      assert.equal(sim.result.hits, 0);
      results[route] = sim.result;
      if (route === 'logs') {
        assert(sim.layout.treats.filter(t => t.jumpLog !== undefined).every(t => sim.collected.has(t.id)));
      }
      if (route === 'sand') {
        for (const log of sim.layout.obstacles) {
          const row = sim.layout.treats.filter(t => Math.abs(t.s - log.s) < 8 && t.lane === log.snackLane);
          assert(row.every(t => sim.collected.has(t.id)));
        }
      }
    }
    for (const route of [results.logs, results.sand]) {
      assert(route.treats > results.middle.treats);
      assert(route.time < results.middle.time);
      assert(route.rank < results.middle.rank);
    }
  }
});
