import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from '../dist/assets/three.module.js';
import {A_FRAME, aFrameHeight, aFrameCameraLift} from '../dist/a-frame.js';
import {AgilitySimulation} from '../dist/agility-sim.js';
import {makeAgilityField} from '../dist/agility-field.js';
import {chaseCameraPose} from '../dist/chase-camera.js';

function start() {
  const sim = new AgilitySimulation('hill-field');
  sim.start();
  while (sim.status === 'countdown') sim.step(.05);
  return sim;
}

test('all six hill obstacles are clearable at running speed with the two ramps scored on exit', () => {
  for (const dt of [1/120,1/60,.05,.1]) {
    const sim = start(), p = sim.player, climbed = new Set();
    for (let i=0; i<4000 && sim.status==='running'; i++) {
      const o = sim.nextObstacle;
      if (o && !sim.rampPass) {
        if (p.lane !== o.lane) sim.input(p.lane < o.lane ? 'right' : 'left');
        if (['hurdle','hoop'].includes(o.type) && o.s > p.s && o.s-p.s < 4.4) sim.input('jump');
      }
      sim.step(dt);
      if (sim.rampPass?.onBoard) {
        const ramp = sim.rampPass.obstacle;
        assert(!sim.results.has(ramp.id));
        assert.equal(p.surfaceY,aFrameHeight(p.s-ramp.s));
        if(p.y>A_FRAME.height-.32)climbed.add(ramp.id);
      }
    }
    assert.equal(sim.status,'finished');
    assert.equal(climbed.size,2);
    assert.deepEqual([sim.cleared,sim.faults,sim.result.penalty],[6,0,0]);
    assert.equal(sim.layout.treats.length,0);
  }
});

test('stopping on the slope keeps footing; menu pause freezes time; retry clears the ramp', () => {
  const sim=start(), p=sim.player;
  while(p.surfaceY<1)sim.step(.025);
  const position=[p.s,p.y,p.pitch],time=sim.time;
  assert(sim.input('brake'));assert(!sim.input('jump'));assert(!sim.input('right'));
  for(let i=0;i<20;i++)sim.step(.05);
  assert.deepEqual([p.s,p.y,p.pitch],position);
  assert(sim.time>time+.9);
  sim.pause();const paused=sim.time;sim.step(.1);assert.equal(sim.time,paused);
  sim.resume();assert(sim.input('dash'));
  while(!sim.results.has(0))sim.step(.05);
  assert(sim.results.get(0));assert.equal(p.y,0);assert.equal(p.pitch,0);
  sim.reset();assert.equal(sim.rampPass,null);assert.equal(sim.results.size,0);assert.equal(sim.player.y,0);
});

test('missing the entrance on the ground or airborne costs exactly one fault per ramp', () => {
  for(const action of ['left','jump']){
    const sim=start();
    if(action==='left')sim.input('left');
    while(sim.player.s<12)sim.step(.025);
    if(action==='jump')sim.input('jump');
    while(sim.player.s<28)sim.step(.025);
    assert.equal(sim.results.get(0),false);assert.equal(sim.faults,1);
    assert.equal(sim.player.surfaceY,0);assert.equal(sim.rampPass,null);
  }
});

test('both rigid ramp surfaces match the paws, and both next obstacles project into portrait and landscape views at the ridge', () => {
  const sim=start(), layout=sim.layout, arena=makeAgilityField(layout);
  arena.root.updateMatrixWorld(true);
  for(const ramp of layout.obstacles.filter(o=>o.type==='a-frame')){
    const group=arena.root.children.find(o=>o.name==='race-obstacle' && o.userData.obstacleId===ramp.id);
    const panels=group.children.filter(o=>o.name==='a-frame-panel');
    assert.equal(panels.length,4);
    for(const offset of [-4.6,-3.2,-1,0,1,3.2,4.6]){
      const p=layout.point(ramp.s+offset,ramp.lane*2);
      const pos=new T.Vector3(p.x,aFrameHeight(offset),p.z);
      assert(panels.some(panel=>{
        const local=panel.worldToLocal(pos.clone()),dims=panel.geometry.parameters;
        return Math.abs(local.y-dims.height/2)<1e-6 && Math.abs(local.z)<=dims.depth/2+1e-6;
      }));
    }
    const anchor=layout.point(ramp.s,ramp.lane*2), next=layout.obstacles[ramp.id+1];
    const target=layout.point(next.s,next.lane*2);
    const lift=aFrameCameraLift(A_FRAME.height);
    const pose=chaseCameraPose(anchor,{height:2.8+lift,lookHeight:1+.65*lift});
    for(const [w,h] of [[320,568],[390,844],[844,390]]){
      const camera=new T.PerspectiveCamera(w>h?54:60,w/h,.1,180);
      camera.position.copy(pose.position);camera.lookAt(pose.target.x,pose.target.y,pose.target.z);camera.updateMatrixWorld(true);
      const screen=new T.Vector3(target.x,1,target.z).project(camera);
      assert(Math.abs(screen.x)<.9 && Math.abs(screen.y)<.9 && screen.z>0 && screen.z<1);
      const dog=new T.Vector3(anchor.x,A_FRAME.height+.7,anchor.z).project(camera);
      assert(Math.abs(dog.x)<1e-7 && Math.abs(dog.y)<1);
    }
  }
  arena.root.traverse(o=>{o.geometry?.dispose();o.material?.dispose()});
});

test('the ramp camera eases across both toes and the crest, at the same height on a stopped step',()=>{
  const liftAt = s => aFrameCameraLift(aFrameHeight(s));
  const ds = .01;
  for(const offset of [-A_FRAME.run,0,A_FRAME.run]){
    const fromLeft=(liftAt(offset)-liftAt(offset-ds))/ds;
    const toRight=(liftAt(offset+ds)-liftAt(offset))/ds;
    assert(Math.abs(fromLeft-toRight)<.01);
  }
  assert.equal(liftAt(-A_FRAME.run),0);
  assert(liftAt(0)>1.6 && liftAt(0)<A_FRAME.height);
  for(let i=0;i<48;i++)assert(liftAt(i/10)>=liftAt((i+1)/10));
});
